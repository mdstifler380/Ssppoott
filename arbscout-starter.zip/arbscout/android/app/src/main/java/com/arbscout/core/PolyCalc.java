package com.arbscout.core;

import com.arbscout.core.Model.Settings;
import com.arbscout.core.Poly.*;
import java.util.*;

/** Fee-aware Polymarket math. Nothing here places an order. */
public final class PolyCalc {
    /** Taker fee as a fraction of cost at price p: peaks at 50c and falls toward the edges (0.25 * (p(1-p))^2 at the 1.56% peak). */
    public static double feeRate(double p, double peakPct) { double x = 4 * p * (1 - p); return peakPct / 100 * x * x; }

    public static double normalCdf(double z) { return 0.5 * (1 + erf(z / Math.sqrt(2))); }
    /** Abramowitz and Stegun 7.1.26, absolute error below 1.5e-7. */
    static double erf(double x) {
        double t = 1 / (1 + 0.3275911 * Math.abs(x));
        double y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
        return x >= 0 ? y : -y;
    }

    // ---- buy every outcome ----
    public static final class SetRow {
        public final String title; public final int outcomes; public final double askSum, cost, net;
        SetRow(String title, int outcomes, double askSum, double cost) { this.title = title; this.outcomes = outcomes; this.askSum = askSum; this.cost = cost; this.net = 1 - cost; }
    }
    public static final class SetReport {
        public final List<SetRow> rows; public final int events, exclusive, incomplete, profitable;
        SetReport(List<SetRow> rows, int events, int exclusive, int incomplete, int profitable) { this.rows = rows; this.events = events; this.exclusive = exclusive; this.incomplete = incomplete; this.profitable = profitable; }
    }
    /**
     * In an event where exactly one outcome wins, buying one share of every outcome costs the sum of the asks and always pays $1.
     * Profit per set is 1 minus the fee-inclusive cost. Prices are the market list's best asks; their sizes are not checked.
     */
    public static SetReport sets(List<Event> events, Settings s) {
        List<SetRow> rows = new ArrayList<>(); int exclusive = 0, incomplete = 0, profitable = 0;
        for (Event e : events) {
            if (!e.negRisk) continue;
            exclusive++;
            boolean complete = e.legs.size() >= 2; double sum = 0, cost = 0;
            for (Leg l : e.legs) {
                if (!(l.ask > 0 && l.ask < 1)) { complete = false; break; }
                sum += l.ask; cost += l.ask * (1 + (l.fee ? feeRate(l.ask, s.polyFeePeakPct) : s.polyOtherFeePct / 100));
            }
            if (!complete) { incomplete++; continue; }
            SetRow r = new SetRow(e.title, e.legs.size(), sum, cost);
            if (r.net > 0) profitable++;
            rows.add(r);
        }
        rows.sort((a, b) -> Double.compare(b.net, a.net));
        return new SetReport(rows, events.size(), exclusive, incomplete, profitable);
    }

    // ---- BTC up/down windows ----
    /** Where the price stands inside a window and what a simple random-walk model says about "Up". */
    public static final class Fair {
        public final double start, now, sigmaPerMin, minutesLeft, pUp;
        Fair(double start, double now, double sigmaPerMin, double minutesLeft, double pUp) { this.start = start; this.now = now; this.sigmaPerMin = sigmaPerMin; this.minutesLeft = minutesLeft; this.pUp = pUp; }
    }
    /**
     * Start price = open of the 1-minute candle that begins the window; current price = latest close; volatility = root-mean-square of the
     * 1-minute log returns available. P(Up) = N(ln(now/start) / (sigma * sqrt(minutes left))), kept within 2% to 98% because real prices jump.
     * Polymarket resolves on Chainlink's BTC/USD, not this exchange's price, so near the start price this is only approximate.
     */
    public static Fair fair(List<Candle> candles, long windowStartMs, long windowEndMs, long nowMs) {
        if (candles.size() < 10) return null;
        double start = Double.NaN;
        for (Candle c : candles) if (c.openTimeMs == windowStartMs) start = c.open;
        if (Double.isNaN(start)) return null;
        double sumSq = 0; int n = 0;
        for (int i = 1; i < candles.size(); i++) { double r = Math.log(candles.get(i).close / candles.get(i - 1).close); sumSq += r * r; n++; }
        double sigma = Math.max(Math.sqrt(sumSq / n), 1e-5), now = candles.get(candles.size() - 1).close;
        double minutes = Math.max((windowEndMs - nowMs) / 60000.0, 0.05);
        double p = normalCdf(Math.log(now / start) / (sigma * Math.sqrt(minutes)));
        return new Fair(start, now, sigma, minutes, Math.min(0.98, Math.max(0.02, p)));
    }
    /** The better side to buy: model probability minus the fee-inclusive price. */
    public static final class Edge {
        public final String side; public final double ask, askSize, p, fee, edge;
        Edge(String side, double ask, double askSize, double p, double fee) { this.side = side; this.ask = ask; this.askSize = askSize; this.p = p; this.fee = fee; this.edge = p - ask * (1 + fee); }
        /** Expected profit per dollar staked if the model were right. */
        public double evPerDollar() { return p / (ask * (1 + fee)) - 1; }
    }
    public static Edge best(double pUp, Book up, Book down, double feePeakPct) {
        Edge a = side("UP", pUp, up, feePeakPct), b = side("DOWN", 1 - pUp, down, feePeakPct);
        return a == null ? b : b == null ? a : (a.edge >= b.edge ? a : b);
    }
    private static Edge side(String side, double p, Book book, double feePeakPct) {
        if (book == null || !(book.bestAsk > 0 && book.bestAsk < 1)) return null;
        return new Edge(side, book.bestAsk, book.askSize, p, feeRate(book.bestAsk, feePeakPct));
    }
    private PolyCalc() {}
}
