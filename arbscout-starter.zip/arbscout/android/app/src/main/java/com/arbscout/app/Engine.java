package com.arbscout.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The scanner, for the whole process. It runs while anything holds it (the screen is open, or the background service is running), keeps the
 * latest results, writes the history files, and tells listeners about each new scan. Screens and the service only display what it produces.
 */
final class Engine {
    static final String VERSION = "1.7.0";
    /** With the screen closed the big spot/perp downloads happen only this often, and the huge events list even more rarely. */
    static final long BACKGROUND_SPOT_MS = 120_000, BACKGROUND_EVENTS_MS = 600_000, FOREGROUND_EVENTS_MS = 30_000, SNAPSHOT_MS = 60_000;

    interface Listener { void onSpot(Feeds.Scan scan); void onPoly(PolyFeed.Scan scan); }

    private static Engine instance;
    static synchronized Engine get(Context context) {
        if (instance == null) {
            Context app = context.getApplicationContext();
            SharedPreferences prefs = app.getSharedPreferences("arbscout", Context.MODE_PRIVATE);
            PolyFeed poly = new PolyFeed(new PolyFeed.Network(), System::currentTimeMillis, prefs.getString("ledger", ""), text -> prefs.edit().putString("ledger", text).apply());
            addStandardRivals(poly, prefs);
            instance = new Engine(prefs, app.getFilesDir(), new Feeds(), poly);
        }
        return instance;
    }

    /**
     * Two rival accounts that trade the same Polymarket windows as account A with different rules, so the rules can be compared fairly
     * within one run instead of across runs in different markets. B: no model filter (the rule before version 1.6). C: favourites only.
     */
    static void addStandardRivals(PolyFeed poly, SharedPreferences prefs) {
        poly.addRival("B", "no model filter (the rule before 1.6)", s -> { Settings c = s.copy(); c.paperMinModelPct = 0; return c; },
                prefs.getString("ledger_B", ""), text -> prefs.edit().putString("ledger_B", text).apply());
        poly.addRival("C", "favourites only (price 60 cents or more)", s -> { Settings c = s.copy(); c.paperMinCents = Math.max(60, s.paperMinCents); return c; },
                prefs.getString("ledger_C", ""), text -> prefs.edit().putString("ledger_C", text).apply());
    }

    private final SharedPreferences prefs;
    private final Feeds feeds;
    private final PolyFeed poly;
    private final HistoryLog snapshots, events, market;
    private final Map<String, ChangeLog> rivalChanges = new HashMap<>();
    private final ChangeLog spotChanges = new ChangeLog(), polyChanges = new ChangeLog();
    private final Set<String> holders = new HashSet<>();
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicBoolean busySpot = new AtomicBoolean(), busyPoly = new AtomicBoolean();
    private ScheduledExecutorService schedule;
    private volatile Settings settings;
    private volatile boolean paperOn, visible;   // not visible until a screen says so: a restarted service must not behave as if someone is watching
    private volatile Feeds.Scan lastSpot;
    private volatile PolyFeed.Scan lastPoly;
    private volatile long startedAt, lastSpotAt;
    /** Changes whenever the schedule is restarted or stopped, so a scan that was already running can tell its result is no longer wanted. */
    private volatile int generation;

    /** Package-private so tests can supply fake data sources and an in-memory store. */
    Engine(SharedPreferences prefs, File dir, Feeds feeds, PolyFeed poly) {
        this.prefs = prefs; this.feeds = feeds; this.poly = poly;
        settings = SettingsStore.load(prefs);
        paperOn = prefs.getBoolean("paperOn", false);
        snapshots = new HistoryLog(new File(dir, "snapshots.csv"), ExportBundle.SNAPSHOT_HEADER, 3000);
        events = new HistoryLog(new File(dir, "events.csv"), ExportBundle.EVENT_HEADER, 3000);
        market = new HistoryLog(new File(dir, "market.csv"), ExportBundle.MARKET_HEADER, 3000);
        poly.setEventsEveryMs(BACKGROUND_EVENTS_MS);
    }

    // ---- state ----
    Settings settings() { return settings; }
    boolean paperOn() { return paperOn; }
    Feeds.Scan lastSpot() { return lastSpot; }
    PolyFeed.Scan lastPoly() { return lastPoly; }
    boolean backgroundWanted() { return prefs.getBoolean("backgroundOn", false); }
    void setBackgroundWanted(boolean on) { prefs.edit().putBoolean("backgroundOn", on).apply(); }
    void addListener(Listener l) { listeners.add(l); }
    void removeListener(Listener l) { listeners.remove(l); }

    void setPaperOn(boolean on) {
        paperOn = on; prefs.edit().putBoolean("paperOn", on).apply();
        logEvent(on ? "PAPER_TRADING_ON" : "PAPER_TRADING_OFF", "");
    }
    /** Saves the settings and, if the scanner is running, restarts it so the new refresh interval applies. */
    synchronized void applySettings(Settings s) {
        SettingsStore.save(prefs, s); settings = s;
        logEvent("SETTINGS_SAVED", String.format(Locale.US, "refresh %.0f s, stake %.0f, edge %.1f pts, price range %.0f-%.0f cents", s.refreshSeconds, s.paperStakeUsdt, s.paperMinEdgePts, s.paperMinCents, s.paperMaxCents));
        if (schedule != null) { stopSchedule(); startSchedule(); }
    }
    void setVisible(boolean v) { visible = v; poly.setEventsEveryMs(v ? FOREGROUND_EVENTS_MS : BACKGROUND_EVENTS_MS); }
    /** Runs off the caller's thread if it may wait for a network refresh to finish. */
    void resetLedger() { poly.resetLedger(); polyChanges.forgetPositions(); rivalChanges.clear(); logEvent("LEDGER_RESET", "all paper accounts"); }

    // ---- who needs the scanner ----
    synchronized void acquire(String who) {
        holders.add(who);
        if (schedule == null) { startSchedule(); logEvent("SCAN_START", "held by " + holders); }
    }
    synchronized void release(String who) {
        holders.remove(who);
        if (holders.isEmpty() && schedule != null) {
            stopSchedule(); startedAt = 0; spotChanges.reset(); polyChanges.reset(); rivalChanges.clear();
            logEvent("SCAN_STOP", "nothing needs the scanner any more");
        }
    }

    private void startSchedule() {
        if (startedAt == 0) startedAt = System.currentTimeMillis();
        generation++;
        schedule = Executors.newScheduledThreadPool(3);
        long period = Math.max(2000, (long) (settings.refreshSeconds * 1000)), spotPeriod = Math.max(2000, (long) (settings.spotRefreshSeconds * 1000));
        schedule.scheduleWithFixedDelay(this::spotTick, 0, spotPeriod, TimeUnit.MILLISECONDS);
        schedule.scheduleWithFixedDelay(this::polyTick, 0, period, TimeUnit.MILLISECONDS);
        schedule.scheduleWithFixedDelay(this::logTick, SNAPSHOT_MS, SNAPSHOT_MS, TimeUnit.MILLISECONDS);
    }
    private void stopSchedule() { if (schedule != null) { generation++; schedule.shutdownNow(); schedule = null; } }

    private void spotTick() {
        if (!busySpot.compareAndSet(false, true)) return;
        final int mine = generation;
        try {
            long now = System.currentTimeMillis();
            if (!visible && now - lastSpotAt < BACKGROUND_SPOT_MS) return;
            Feeds.Scan scan = feeds.refresh(settings);
            if (mine != generation) return;   // the schedule was restarted or stopped meanwhile: the interruption would show up as a false outage
            lastSpot = scan; lastSpotAt = now;
            for (String[] e : spotChanges.sources(scan.status)) logEvent(e[0], e[1]);
            for (Listener l : listeners) { try { l.onSpot(scan); } catch (RuntimeException ignored) { /* a listener must not stop the scanner */ } }
        } catch (Exception e) { if (mine == generation) logEvent("ERROR", "spot scan: " + e); }
        finally { busySpot.set(false); }
    }
    private void polyTick() {
        if (!busyPoly.compareAndSet(false, true)) return;
        final int mine = generation;
        try {
            PolyFeed.Scan scan = poly.refresh(settings, paperOn);
            if (mine != generation) return;   // see spotTick
            lastPoly = scan;
            for (String[] e : polyChanges.sources(scan.status)) logEvent(e[0], e[1]);
            for (String[] e : polyChanges.paper(scan.ledger)) logEvent(e[0], e[1]);
            for (Map.Entry<String, Ledger> r : scan.rivals.entrySet())
                for (String[] e : rivalChanges.computeIfAbsent(r.getKey(), k -> new ChangeLog()).paper(r.getValue())) logEvent(e[0], "[" + r.getKey() + "] " + e[1]);
            for (Listener l : listeners) { try { l.onPoly(scan); } catch (RuntimeException ignored) { /* see above */ } }
        } catch (Exception e) { if (mine == generation) logEvent("ERROR", "polymarket scan: " + e); }
        finally { busyPoly.set(false); }
    }
    private void logTick() {
        try {
            long now = System.currentTimeMillis();
            snapshots.append(ExportBundle.snapshotRow(now, lastSpot, lastPoly, paperOn, Feeds.BYTES.get()));
            String row = ExportBundle.marketRow(now, lastPoly); if (row != null) market.append(row);
        } catch (RuntimeException ignored) { /* never stop for logging */ }
    }
    void logEvent(String type, String detail) { events.append(Csv.row(Csv.iso(System.currentTimeMillis()), type, Csv.oneLine(detail))); }

    // ---- what to show and export ----
    Notice notice() { return Notice.build(lastSpot, lastPoly, paperOn, startedAt, System.currentTimeMillis(), Feeds.BYTES.get()); }
    long startedAt() { return startedAt; }
    Map<String, String> exportFiles(boolean serviceRunning) {
        return ExportBundle.build(VERSION, System.currentTimeMillis(), settings, lastSpot, lastPoly, paperOn, serviceRunning, startedAt, Feeds.BYTES.get(), snapshots.read(), events.read(), market.read());
    }
    static String exportName() { return "arbscout-export-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".zip"; }
}
