package com.arbscout.app;

import com.arbscout.core.Calc;
import com.arbscout.core.Model.*;
import com.arbscout.core.Parsers;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongSupplier;

/**
 * Downloads public market data from several exchanges in parallel and runs the scans. Uses only java.net: no keys, no orders.
 * Call {@link #refresh} from one worker thread at a time; it keeps the last good reply per source and drops it once it is too old.
 */
final class Feeds {
    /** Bytes read from the network since the process started (after decompression, so the real data use is lower). */
    static final AtomicLong BYTES = new AtomicLong();
    static final long SPOT_STALE_MS = 15_000, PERP_EVERY_MS = 60_000, PERP_STALE_MS = 180_000;
    private static final String[] SPOT = {"BINANCE", "BYBIT", "OKX", "MEXC"};
    private static final String[] PERP = {"BINANCE", "BYBIT"};

    /** Where prices come from. The app uses {@link Network}; tests pass a fake. */
    interface Source {
        List<Quote> spot(String exchange) throws Exception;
        List<Perp> perps(String exchange) throws Exception;
    }
    /** Everything the screen needs from one refresh. */
    static final class Scan {
        final Calc.SpreadReport spreads; final Calc.CarryReport carry; final List<String> status; final long at; final int spotLive, perpLive;
        Scan(Calc.SpreadReport spreads, Calc.CarryReport carry, List<String> status, long at, int spotLive, int perpLive) {
            this.spreads = spreads; this.carry = carry; this.status = status; this.at = at; this.spotLive = spotLive; this.perpLive = perpLive;
        }
    }
    private static final class Timed<T> {
        final T value; final long ms;
        Timed(T value, long ms) { this.value = value; this.ms = ms; }
    }

    private final ExecutorService pool = Executors.newFixedThreadPool(6, r -> { Thread t = new Thread(r, "arbscout-net"); t.setDaemon(true); return t; });
    private final Map<String, List<Quote>> spot = new HashMap<>();
    private final Map<String, Long> spotAt = new HashMap<>();
    private final Map<String, List<Perp>> perps = new HashMap<>();
    private final Map<String, Long> perpAt = new HashMap<>();
    private final Map<String, String> perpLine = new LinkedHashMap<>();
    private final Source source;
    private final LongSupplier clock;
    private long lastPerpAttempt = Long.MIN_VALUE / 2;

    Feeds() { this(new Network(), System::currentTimeMillis); }
    Feeds(Source source, LongSupplier clock) { this.source = source; this.clock = clock; }

    Scan refresh(Settings s) {
        long now = clock.getAsLong();
        Map<String, Future<Timed<List<Quote>>>> spotJobs = new LinkedHashMap<>();
        for (String ex : SPOT) spotJobs.put(ex, pool.submit(() -> { long t0 = System.nanoTime(); List<Quote> q = source.spot(ex); return new Timed<>(q, (System.nanoTime() - t0) / 1_000_000); }));
        Map<String, Future<Timed<List<Perp>>>> perpJobs = new LinkedHashMap<>();
        if (now - lastPerpAttempt >= PERP_EVERY_MS) {
            lastPerpAttempt = now;
            for (String ex : PERP) perpJobs.put(ex, pool.submit(() -> { long t0 = System.nanoTime(); List<Perp> p = source.perps(ex); return new Timed<>(p, (System.nanoTime() - t0) / 1_000_000); }));
        }
        List<String> lines = new ArrayList<>();
        for (Map.Entry<String, Future<Timed<List<Quote>>>> e : spotJobs.entrySet()) {
            String ex = e.getKey();
            try {
                Timed<List<Quote>> t = e.getValue().get(20, TimeUnit.SECONDS);
                spot.put(ex, t.value); spotAt.put(ex, clock.getAsLong());
                lines.add("✓ " + ex + " spot · " + t.value.size() + " USDT pairs · " + t.ms + " ms");
            } catch (Exception err) {
                e.getValue().cancel(true);
                Long at = spotAt.get(ex); long age = at == null ? Long.MAX_VALUE : clock.getAsLong() - at;
                lines.add("✗ " + ex + " spot · " + why(err) + (age <= SPOT_STALE_MS ? " · using " + age / 1000 + " s old data" : " · excluded"));
            }
        }
        for (Map.Entry<String, Future<Timed<List<Perp>>>> e : perpJobs.entrySet()) {
            String ex = e.getKey();
            try {
                Timed<List<Perp>> t = e.getValue().get(30, TimeUnit.SECONDS);
                perps.put(ex, t.value); perpAt.put(ex, clock.getAsLong());
                perpLine.put(ex, "✓ " + ex + " perps · " + t.value.size() + " contracts · " + t.ms + " ms");
            } catch (Exception err) {
                e.getValue().cancel(true);
                perpLine.put(ex, "✗ " + ex + " perps · " + why(err));
            }
        }
        lines.addAll(perpLine.values());
        long t = clock.getAsLong();
        List<Quote> quotes = new ArrayList<>(); int spotLive = 0;
        for (String ex : SPOT) { Long at = spotAt.get(ex); if (at != null && t - at <= SPOT_STALE_MS) { quotes.addAll(spot.get(ex)); spotLive++; } }
        List<Perp> contracts = new ArrayList<>(); int perpLive = 0;
        for (String ex : PERP) { Long at = perpAt.get(ex); if (at != null && t - at <= PERP_STALE_MS) { contracts.addAll(perps.get(ex)); perpLive++; } }
        return new Scan(Calc.spreads(quotes, s), Calc.carry(contracts, quotes, s), lines, t, spotLive, perpLive);
    }

    /** The real exchanges' public endpoints. */
    static final class Network implements Source {
        @Override public List<Quote> spot(String ex) throws Exception {
            switch (ex) {
                case "BINANCE": return Parsers.binanceLike(ex, get("https://api.binance.com/api/v3/ticker/bookTicker"));
                case "MEXC": return Parsers.binanceLike(ex, get("https://api.mexc.com/api/v3/ticker/bookTicker"));
                case "BYBIT": return Parsers.bybitSpot(get("https://api.bybit.com/v5/market/tickers?category=spot"));
                default: return Parsers.okxSpot(get("https://www.okx.com/api/v5/market/tickers?instType=SPOT"));
            }
        }
        @Override public List<Perp> perps(String ex) throws Exception {
            if (ex.equals("BYBIT")) return Parsers.bybitPerps(get("https://api.bybit.com/v5/market/tickers?category=linear"));
            String premium = get("https://fapi.binance.com/fapi/v1/premiumIndex");
            return Parsers.binancePerps(premium, optional("https://fapi.binance.com/fapi/v1/fundingInfo"), optional("https://fapi.binance.com/fapi/v1/ticker/24hr"));
        }
        private static String optional(String url) { try { return get(url); } catch (IOException e) { return null; } }
    }

    static String get(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "ArbScout/1.0"); c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode();
            if (code != 200) {
                String hint = code == 451 || code == 403 ? " (blocked in your region or by the exchange)" : code == 429 || code == 418 ? " (rate limited)" : "";
                throw new IOException("HTTP " + code + hint);
            }
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[16384]; int n, total = 0;
                while ((n = in.read(buf)) > 0) { total += n; if (total > 16_000_000) throw new IOException("reply too large"); out.write(buf, 0, n); }
                BYTES.addAndGet(total);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { c.disconnect(); }
    }
    static String why(Throwable err) {
        Throwable t = err instanceof ExecutionException && err.getCause() != null ? err.getCause() : err;
        String m = t instanceof TimeoutException ? "timed out" : t instanceof java.net.UnknownHostException ? "no connection" : t.getMessage();
        if (m == null || m.isEmpty()) m = t.getClass().getSimpleName();
        return m.length() > 90 ? m.substring(0, 90) + "…" : m;
    }
}
