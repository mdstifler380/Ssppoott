package com.arbscout.app;

import com.arbscout.core.Calc;
import com.arbscout.core.Ledger;
import java.text.SimpleDateFormat;
import java.util.*;

/** The words for the status notification: a one-line summary and an expanded view with the details. */
final class Notice {
    final String title, text, big;
    private Notice(String title, String text, String big) { this.title = title; this.text = text; this.big = big; }

    static Notice build(Feeds.Scan spot, PolyFeed.Scan poly, boolean paperOn, long startedAt, long now, long bytes) {
        int ok = 0; List<String> down = new ArrayList<>();
        count(spot == null ? null : spot.status, down); count(poly == null ? null : poly.status, down);
        for (List<String> lines : Arrays.asList(spot == null ? null : spot.status, poly == null ? null : poly.status)) if (lines != null) for (String l : lines) if (l.startsWith("✓")) ok++;
        String title = "ArbScout · " + (spot == null && poly == null ? "starting…" : down.isEmpty() ? ok + " sources OK" : down.size() + " of " + (ok + down.size()) + " sources down");

        String spreads, carry, paper;
        if (spot == null) { spreads = "Spreads: waiting for the first scan"; carry = "Carry: waiting for the first scan"; }
        else {
            if (spot.spotLive < 2) spreads = "Spreads: only " + spot.spotLive + " exchange(s) responding";
            else {
                Calc.SpreadReport r = spot.spreads; spreads = String.format(Locale.US, "Spreads: %d profitable after fees", r.profitable);
                if (!r.rows.isEmpty() && r.rows.get(0).netBps > 0) { Calc.Spread x = r.rows.get(0); spreads += String.format(Locale.US, " · best %s %+.0f bps (≈%+.2f USDT)", x.base, x.netBps, x.netUsdt); }
            }
            if (spot.perpLive == 0) carry = "Carry: no funding data";
            else {
                Calc.CarryReport r = spot.carry; carry = String.format(Locale.US, "Carry: %d candidates", r.rows.size());
                if (!r.rows.isEmpty()) { Calc.Carry c = r.rows.get(0); carry += String.format(Locale.US, " · best %s %s %+.2f%% net", c.base, c.exchange, c.holdNetPct); }
            }
        }
        if (poly == null) paper = "Paper " + (paperOn ? "ON" : "OFF") + ": waiting for the first scan";
        else {
            Ledger.Stats st = poly.ledger.stats();
            paper = String.format(Locale.US, "Paper %s: %d open · %d settled", paperOn ? "ON" : "OFF", st.open, st.settled);
            if (st.settled > 0) paper += String.format(Locale.US, " · won %d · P&L %+.2f USDT", st.wins, st.pnl);
        }
        long last = Math.max(spot == null ? 0 : spot.at, poly == null ? 0 : poly.at);
        String clock = last == 0 ? "no scan yet" : new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(last));
        String foot = String.format(Locale.US, "Updated %s · running %s · ≈%.0f MB read", clock, duration(startedAt == 0 ? 0 : now - startedAt), bytes / 1e6);
        String downLine = down.isEmpty() ? "" : "Down: " + String.join(", ", down) + "\n";
        return new Notice(title, paper, downLine + spreads + "\n" + carry + "\n" + paper + "\n" + foot);
    }
    private static void count(List<String> lines, List<String> down) {
        if (lines == null) return;
        for (String l : lines) if (l.startsWith("✗")) { String body = l.substring(Math.min(2, l.length())); int dot = body.indexOf(" · "); down.add(dot < 0 ? body : body.substring(0, dot)); }
    }
    static String duration(long ms) {
        long min = Math.max(0, ms) / 60_000;
        return min >= 60 ? (min / 60) + " h " + (min % 60) + " min" : min + " min";
    }
}
