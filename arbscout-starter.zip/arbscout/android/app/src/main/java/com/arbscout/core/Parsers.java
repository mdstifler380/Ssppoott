package com.arbscout.core;

import com.arbscout.core.Model.*;
import java.util.*;
import org.json.*;

/**
 * One parser per public endpoint. Each returns only usable rows (positive, uncrossed prices, USDT quote)
 * and throws JSONException with the exchange's own message when the reply is an error.
 */
public final class Parsers {
    static double num(String s) {
        if (s == null || s.isEmpty()) return Double.NaN;
        try { double v = Double.parseDouble(s); return Double.isFinite(v) ? v : Double.NaN; } catch (NumberFormatException e) { return Double.NaN; }
    }
    /** "BTCUSDT", "BTC-USDT" and "BTC_USDT" all give "BTC"; anything not quoted in USDT (or a dated contract) gives null. */
    static String baseOf(String id) {
        if (id == null) return null;
        String s = id.replace("-", "").replace("_", "");
        return s.endsWith("USDT") && s.length() > 4 ? s.substring(0, s.length() - 4) : null;
    }
    private static Quote quote(String ex, String id, double bid, double bidQty, double ask, double askQty) {
        String base = baseOf(id);
        if (base == null || !(bid > 0) || !(ask > 0) || bid > ask) return null;
        return new Quote(ex, base, bid, bidQty, ask, askQty);
    }
    private static JSONArray array(String json, String name) throws JSONException {
        String t = json.trim();
        if (t.startsWith("{")) { JSONObject o = new JSONObject(t); throw new JSONException(name + ": " + o.optString("msg", o.optString("message", t))); }
        return new JSONArray(t);
    }
    /** Binance and MEXC share this reply: /api/v3/ticker/bookTicker. */
    public static List<Quote> binanceLike(String exchange, String json) throws JSONException {
        JSONArray a = array(json, exchange); List<Quote> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Quote q = quote(exchange, o.optString("symbol"), num(o.optString("bidPrice")), num(o.optString("bidQty")), num(o.optString("askPrice")), num(o.optString("askQty")));
            if (q != null) out.add(q);
        }
        return out;
    }
    public static List<Quote> bybitSpot(String json) throws JSONException {
        JSONArray a = bybitList(json); List<Quote> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Quote q = quote("BYBIT", o.optString("symbol"), num(o.optString("bid1Price")), num(o.optString("bid1Size")), num(o.optString("ask1Price")), num(o.optString("ask1Size")));
            if (q != null) out.add(q);
        }
        return out;
    }
    private static JSONArray bybitList(String json) throws JSONException {
        JSONObject root = new JSONObject(json.trim());
        if (root.optInt("retCode", -1) != 0) throw new JSONException("BYBIT: " + root.optString("retMsg", "unexpected reply"));
        return root.getJSONObject("result").getJSONArray("list");
    }
    public static List<Quote> okxSpot(String json) throws JSONException {
        JSONObject root = new JSONObject(json.trim());
        if (!"0".equals(root.optString("code"))) throw new JSONException("OKX: " + root.optString("msg", "unexpected reply"));
        JSONArray a = root.getJSONArray("data"); List<Quote> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Quote q = quote("OKX", o.optString("instId"), num(o.optString("bidPx")), num(o.optString("bidSz")), num(o.optString("askPx")), num(o.optString("askSz")));
            if (q != null) out.add(q);
        }
        return out;
    }
    /** premiumIndex is required; fundingInfo (interval hours) and 24hr (volume) are optional enrichments, pass null if they failed. */
    public static List<Perp> binancePerps(String premiumJson, String fundingInfoJson, String ticker24hJson) throws JSONException {
        Map<String, Double> hours = new HashMap<>(), volume = new HashMap<>();
        if (fundingInfoJson != null) {
            JSONArray a = array(fundingInfoJson, "BINANCE funding info");
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); hours.put(o.optString("symbol"), num(o.optString("fundingIntervalHours"))); }
        }
        if (ticker24hJson != null) {
            JSONArray a = array(ticker24hJson, "BINANCE 24h");
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); volume.put(o.optString("symbol"), num(o.optString("quoteVolume"))); }
        }
        JSONArray a = array(premiumJson, "BINANCE funding"); List<Perp> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i); String sym = o.optString("symbol"), base = baseOf(sym);
            double rate = num(o.optString("lastFundingRate")), mark = num(o.optString("markPrice"));
            if (base == null || Double.isNaN(rate) || !(mark > 0)) continue;
            Double h = hours.get(sym), v = volume.get(sym);
            out.add(new Perp("BINANCE", sym, base, rate, h == null || !(h > 0) ? 8 : h, mark, v == null ? Double.NaN : v));
        }
        return out;
    }
    public static List<Perp> bybitPerps(String json) throws JSONException {
        JSONArray a = bybitList(json); List<Perp> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i); String sym = o.optString("symbol"), base = baseOf(sym);
            double rate = num(o.optString("fundingRate")), mark = num(o.optString("markPrice")), h = num(o.optString("fundingIntervalHour"));
            if (base == null || Double.isNaN(rate) || !(mark > 0)) continue;
            out.add(new Perp("BYBIT", sym, base, rate, h > 0 ? h : 8, mark, num(o.optString("turnover24h"))));
        }
        return out;
    }
    private Parsers() {}
}
