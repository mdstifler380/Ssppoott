package com.arbscout.app;

import android.content.SharedPreferences;
import com.arbscout.core.Model.Settings;

/** The editable settings: which fields exist, how they map onto {@link Settings}, and how they are saved. */
final class SettingsStore {
    static final String[][] FIELDS = {
            {"fee_BINANCE", "Binance spot fee per trade (bps)"}, {"fee_BYBIT", "Bybit spot fee per trade (bps)"},
            {"fee_OKX", "OKX spot fee per trade (bps)"}, {"fee_MEXC", "MEXC spot fee per trade (bps)"},
            {"safety", "Safety margin on spreads (bps)"}, {"depth", "Minimum book depth (USDT)"},
            {"trade", "Trade size for estimates (USDT)"}, {"maxGross", "Largest believable spread (bps)"},
            {"perpFee", "Perpetual fee per trade (bps)"}, {"slippage", "Slippage allowance for carry (bps)"},
            {"hold", "Holding period for carry (days)"}, {"minVol", "Minimum 24h perp volume (USDT)"},
            {"polyFee", "Polymarket Up/Down peak taker fee (%)"}, {"polyOther", "Polymarket fee on other markets (%)"},
            {"stake", "Paper stake per trade (USDT)"}, {"minEdge", "Paper entry: minimum edge (points)"},
            {"minPrice", "Paper entry: lowest price (cents)"}, {"maxPrice", "Paper entry: highest price (cents)"},
            {"refresh", "Refresh every (seconds)"}};

    static double get(Settings s, String k) {
        switch (k) {
            case "fee_BINANCE": return s.fee("BINANCE"); case "fee_BYBIT": return s.fee("BYBIT"); case "fee_OKX": return s.fee("OKX"); case "fee_MEXC": return s.fee("MEXC");
            case "safety": return s.safetyBps; case "depth": return s.minDepthUsdt; case "trade": return s.tradeUsdt; case "maxGross": return s.maxGrossBps;
            case "perpFee": return s.perpFeeBps; case "slippage": return s.slippageBps; case "hold": return s.holdDays; case "minVol": return s.minPerpVolumeUsdt;
            case "polyFee": return s.polyFeePeakPct; case "polyOther": return s.polyOtherFeePct; case "stake": return s.paperStakeUsdt; case "minEdge": return s.paperMinEdgePts;
            case "minPrice": return s.paperMinCents; case "maxPrice": return s.paperMaxCents;
            default: return s.refreshSeconds;
        }
    }
    static void set(Settings s, String k, double v) {
        switch (k) {
            case "fee_BINANCE": s.spotFeeBps.put("BINANCE", v); break; case "fee_BYBIT": s.spotFeeBps.put("BYBIT", v); break;
            case "fee_OKX": s.spotFeeBps.put("OKX", v); break; case "fee_MEXC": s.spotFeeBps.put("MEXC", v); break;
            case "safety": s.safetyBps = v; break; case "depth": s.minDepthUsdt = v; break; case "trade": s.tradeUsdt = v; break; case "maxGross": s.maxGrossBps = v; break;
            case "perpFee": s.perpFeeBps = v; break; case "slippage": s.slippageBps = v; break; case "hold": s.holdDays = v; break; case "minVol": s.minPerpVolumeUsdt = v; break;
            case "polyFee": s.polyFeePeakPct = v; break; case "polyOther": s.polyOtherFeePct = v; break; case "stake": s.paperStakeUsdt = v; break; case "minEdge": s.paperMinEdgePts = v; break;
            case "minPrice": s.paperMinCents = v; break; case "maxPrice": s.paperMaxCents = v; break;
            default: s.refreshSeconds = v; break;
        }
    }
    static String fmt(double v) { return v == Math.rint(v) ? Long.toString((long) v) : Double.toString(v); }

    /** Saved settings, or the defaults if nothing was saved or the saved values no longer pass validation. */
    static Settings load(SharedPreferences prefs) {
        Settings s = new Settings();
        try {
            for (String[] f : FIELDS) { String v = prefs.getString(f[0], null); if (v != null) set(s, f[0], Double.parseDouble(v)); }
            s.validate(); return s;
        } catch (RuntimeException e) { return new Settings(); }
    }
    static void save(SharedPreferences prefs, Settings s) {
        SharedPreferences.Editor ed = prefs.edit();
        for (String[] f : FIELDS) ed.putString(f[0], Double.toString(get(s, f[0])));
        ed.apply();
    }
    private SettingsStore() {}
}
