package com.arbscout.core;

import java.util.*;

/** A fake-money account. Positions are opened at the real best ask (fee included) and settled from Polymarket's real result. */
public final class Ledger {
    public static final class Position {
        public final String slug, label, side; public final long openedMs, endMs; public final double price, shares, stake, modelP;
        public String status = "OPEN"; public double pnl; public long settledMs; public boolean estimated;
        Position(String slug, String label, String side, long openedMs, long endMs, double price, double shares, double stake, double modelP) {
            this.slug = slug; this.label = label; this.side = side; this.openedMs = openedMs; this.endMs = endMs; this.price = price; this.shares = shares; this.stake = stake; this.modelP = modelP;
        }
        Position copy() { Position p = new Position(slug, label, side, openedMs, endMs, price, shares, stake, modelP); p.status = status; p.pnl = pnl; p.settledMs = settledMs; p.estimated = estimated; return p; }
    }
    public static final class Stats {
        public final int open, settled, wins, estimated; public final double pnl, staked, avgModelP;
        Stats(int open, int settled, int wins, double pnl, double staked, double avgModelP, int estimated) {
            this.open = open; this.settled = settled; this.wins = wins; this.pnl = pnl; this.staked = staked; this.avgModelP = avgModelP; this.estimated = estimated;
        }
        public double winRate() { return settled == 0 ? Double.NaN : wins / (double) settled; }
        public double roi() { return staked == 0 ? Double.NaN : pnl / staked; }
    }
    private final List<Position> positions = new ArrayList<>();

    public boolean has(String slug) { for (Position p : positions) if (p.slug.equals(slug)) return true; return false; }
    public Position find(String slug) { for (Position p : positions) if (p.slug.equals(slug)) return p; return null; }
    /** Spend {@code stake} in total: shares = stake / (price * (1 + fee)). Returns null if this window already has a position. */
    public Position open(String slug, String label, String side, long openedMs, long endMs, double price, double fee, double stake, double modelP) {
        if (has(slug) || !(price > 0 && price < 1) || !(stake > 0)) return null;
        Position p = new Position(slug, label, side, openedMs, endMs, price, stake / (price * (1 + fee)), stake, modelP);
        positions.add(p); return p;
    }
    public int settle(String slug, String winningSide, long nowMs) { return settle(slug, winningSide, nowMs, false); }
    /** Settle every open position in this market given the winning side (UP or DOWN). {@code estimated} marks a result not taken from Polymarket. */
    public int settle(String slug, String winningSide, long nowMs, boolean estimated) {
        int n = 0;
        for (Position p : positions) if (p.slug.equals(slug) && p.status.equals("OPEN")) {
            boolean won = p.side.equals(winningSide);
            p.status = won ? "WON" : "LOST"; p.pnl = won ? p.shares - p.stake : -p.stake; p.settledMs = nowMs; p.estimated = estimated; n++;
        }
        return n;
    }
    public List<Position> open() { List<Position> out = new ArrayList<>(); for (Position p : positions) if (p.status.equals("OPEN")) out.add(p.copy()); return out; }
    /** Newest first. */
    public List<Position> recent(int n) {
        List<Position> out = new ArrayList<>();
        for (int i = positions.size() - 1; i >= 0 && out.size() < n; i--) out.add(positions.get(i).copy());
        return out;
    }
    public Stats stats() {
        int open = 0, settled = 0, wins = 0, estimated = 0; double pnl = 0, staked = 0, model = 0;
        for (Position p : positions) {
            if (p.status.equals("OPEN")) { open++; continue; }
            settled++; if (p.status.equals("WON")) wins++; if (p.estimated) estimated++; pnl += p.pnl; staked += p.stake; model += p.modelP;
        }
        return new Stats(open, settled, wins, pnl, staked, settled == 0 ? Double.NaN : model / settled, estimated);
    }
    public void clear() { positions.clear(); }
    public Ledger copy() { Ledger l = new Ledger(); for (Position p : positions) l.positions.add(p.copy()); return l; }

    // ---- persistence: one text line per position ----
    public String encode() {
        StringBuilder b = new StringBuilder("LEDGER1\n");
        for (Position p : positions)
            b.append(p.slug).append('|').append(p.label).append('|').append(p.side).append('|').append(p.openedMs).append('|').append(p.endMs).append('|').append(p.price).append('|')
                    .append(p.shares).append('|').append(p.stake).append('|').append(p.modelP).append('|').append(p.status).append('|').append(p.pnl).append('|').append(p.settledMs).append('|').append(p.estimated ? 1 : 0).append('\n');
        return b.toString();
    }
    public void restore(String data) {
        positions.clear();
        if (data == null || data.isEmpty()) return;
        String[] lines = data.split("\n");
        if (!lines[0].equals("LEDGER1")) throw new IllegalArgumentException("Unknown ledger format");
        for (int i = 1; i < lines.length; i++) {
            if (lines[i].isEmpty()) continue;
            String[] f = lines[i].split("\\|", -1);
            if (f.length != 12 && f.length != 13) throw new IllegalArgumentException("Bad ledger row");   // 12 = saved by an older version
            Position p = new Position(f[0], f[1], f[2], Long.parseLong(f[3]), Long.parseLong(f[4]), Double.parseDouble(f[5]), Double.parseDouble(f[6]), Double.parseDouble(f[7]), Double.parseDouble(f[8]));
            p.status = f[9]; p.pnl = Double.parseDouble(f[10]); p.settledMs = Long.parseLong(f[11]); p.estimated = f.length == 13 && f[12].equals("1");
            if (!p.status.equals("OPEN") && !p.status.equals("WON") && !p.status.equals("LOST")) throw new IllegalArgumentException("Bad ledger status");
            positions.add(p);
        }
    }
}
