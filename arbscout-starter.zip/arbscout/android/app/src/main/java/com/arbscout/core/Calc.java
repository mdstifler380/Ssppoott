package com.arbscout.core;

import com.arbscout.core.Model.*;
import java.util.*;

/** The two scans. Every figure is after the fees and safety margin in {@link Settings}; nothing here sends an order. */
public final class Calc {
    public static final class Spread {
        public final String base, buyOn, sellOn;
        public final double ask, bid, grossBps, netBps, depthUsdt, sizeUsdt, netUsdt;
        Spread(String base, String buyOn, String sellOn, double ask, double bid, double grossBps, double netBps, double depthUsdt, double sizeUsdt) {
            this.base = base; this.buyOn = buyOn; this.sellOn = sellOn; this.ask = ask; this.bid = bid; this.grossBps = grossBps; this.netBps = netBps;
            this.depthUsdt = depthUsdt; this.sizeUsdt = sizeUsdt; this.netUsdt = sizeUsdt * netBps / 1e4;
        }
    }
    public static final class SpreadReport {
        public final List<Spread> rows; public final int compared, profitable, hiddenThin, hiddenSuspect;
        SpreadReport(List<Spread> rows, int compared, int profitable, int hiddenThin, int hiddenSuspect) {
            this.rows = rows; this.compared = compared; this.profitable = profitable; this.hiddenThin = hiddenThin; this.hiddenSuspect = hiddenSuspect;
        }
    }
    /**
     * Buy at one exchange's best ask, sell at another's best bid, for every coin listed on both. Needs balances already on both sides:
     * transfers are not modeled. "Hidden" counts only spreads that looked profitable on paper but were removed because the order book was
     * thin or the spread was implausibly large (usually a halted coin, a stale quote, or two different coins sharing a ticker).
     */
    public static SpreadReport spreads(List<Quote> quotes, Settings s) {
        Map<String, List<Quote>> byBase = new HashMap<>();
        for (Quote q : quotes) byBase.computeIfAbsent(q.base, k -> new ArrayList<>()).add(q);
        List<Spread> rows = new ArrayList<>(); int compared = 0, profitable = 0, thin = 0, suspect = 0;
        for (Map.Entry<String, List<Quote>> e : byBase.entrySet()) {
            List<Quote> l = e.getValue();
            for (Quote buy : l) for (Quote sell : l) {
                if (buy.exchange.equals(sell.exchange)) continue;
                compared++;
                double gross = (sell.bid / buy.ask - 1) * 1e4, net = gross - s.fee(buy.exchange) - s.fee(sell.exchange) - s.safetyBps;
                boolean onPaper = net > 0;
                if (Math.abs(gross) > s.maxGrossBps) { if (onPaper) suspect++; continue; }   // implausible either way: halted coin, stale quote or a shared ticker
                double depth = Math.min(buy.askQty * buy.ask, sell.bidQty * sell.bid);
                if (!(depth >= s.minDepthUsdt)) { if (onPaper) thin++; continue; }
                if (onPaper) profitable++;
                rows.add(new Spread(e.getKey(), buy.exchange, sell.exchange, buy.ask, sell.bid, gross, net, depth, Math.min(s.tradeUsdt, depth)));
            }
        }
        rows.sort((a, b) -> Double.compare(b.netBps, a.netBps));
        return new SpreadReport(rows, compared, profitable, thin, suspect);
    }

    public static final class Carry {
        public final String exchange, base;
        public final double rate, intervalHours, aprPct, basisBps, costBps, breakevenDays, holdNetPct, volumeUsdt, spotDepthUsdt;
        Carry(String exchange, String base, double rate, double intervalHours, double aprPct, double basisBps, double costBps, double breakevenDays, double holdNetPct, double volumeUsdt, double spotDepthUsdt) {
            this.exchange = exchange; this.base = base; this.rate = rate; this.intervalHours = intervalHours; this.aprPct = aprPct; this.basisBps = basisBps;
            this.costBps = costBps; this.breakevenDays = breakevenDays; this.holdNetPct = holdNetPct; this.volumeUsdt = volumeUsdt; this.spotDepthUsdt = spotDepthUsdt;
        }
    }
    public static final class CarryReport {
        public final List<Carry> rows; public final int considered, negative, lowVolume, noSpot;
        CarryReport(List<Carry> rows, int considered, int negative, int lowVolume, int noSpot) {
            this.rows = rows; this.considered = considered; this.negative = negative; this.lowVolume = lowVolume; this.noSpot = noSpot;
        }
    }
    /**
     * Cash-and-carry: buy the coin on spot and short the same coin's perpetual on the same exchange, collecting funding while it is positive.
     * Costs counted: spot fee and perp fee both ways, the spot bid/ask spread, and a slippage allowance. Funding is variable; the rate can fall or
     * turn negative at any settlement, and a short perp can be liquidated in a sharp rally. Net figures assume today's rate simply continues.
     */
    public static CarryReport carry(List<Perp> perps, List<Quote> spot, Settings s) {
        Map<String, Quote> spotBy = new HashMap<>();
        for (Quote q : spot) spotBy.put(q.exchange + "|" + q.base, q);
        List<Carry> rows = new ArrayList<>(); int considered = 0, negative = 0, low = 0, noSpot = 0;
        for (Perp p : perps) {
            considered++;
            if (!(p.rate > 0)) { negative++; continue; }
            if (!(p.volumeUsdt >= s.minPerpVolumeUsdt)) { low++; continue; }
            Quote q = spotBy.get(p.exchange + "|" + p.base);
            if (q == null) { noSpot++; continue; }
            double hours = p.intervalHours > 0 ? p.intervalHours : 8, mid = (q.bid + q.ask) / 2;
            double dailyPct = p.rate * (24 / hours) * 100, apr = dailyPct * 365;
            double spreadBps = (q.ask - q.bid) / mid * 1e4, basisBps = (p.mark - mid) / mid * 1e4;
            double cost = 2 * s.fee(p.exchange) + 2 * s.perpFeeBps + s.slippageBps + spreadBps;
            // Entering with the perpetual priced below spot gives that gap back when the two converge, so a negative basis counts as a cost; a positive one is not counted as a gain.
            double giveBack = Math.max(0, -basisBps) / 100;
            rows.add(new Carry(p.exchange, p.base, p.rate, hours, apr, basisBps, cost, (cost / 100 + giveBack) / dailyPct, dailyPct * s.holdDays - cost / 100 - giveBack, p.volumeUsdt, Math.min(q.askQty * q.ask, q.bidQty * q.bid)));
        }
        rows.sort((a, b) -> Double.compare(b.holdNetPct, a.holdNetPct));
        return new CarryReport(rows, considered, negative, low, noSpot);
    }
    private Calc() {}
}
