package com.arbscout.app;

import com.arbscout.core.Calc;
import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import com.arbscout.core.PolyCalc;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Everything the app knows, as a set of small CSV tables (zipped for sharing): current scans, settings, the paper account and the rolling history. */
final class ExportBundle {
    static final String SNAPSHOT_HEADER = "time_utc,spot_sources_live,perp_sources_live,pairs_compared,spreads_profitable,spreads_hidden_thin,spreads_hidden_suspect,best_spread_coin,best_spread_route,"
            + "best_spread_net_bps,best_spread_est_usdt,carry_candidates,best_carry,best_carry_net_pct,paper_on,paper_open,paper_settled,paper_wins,paper_pnl_usdt,paper_avg_model_p,"
            + "sets_profitable,sources_down,mb_read,btc5m_model_up,btc5m_ask_up,btc5m_ask_down,btc15m_model_up,btc15m_ask_up,btc15m_ask_down";
    static final String EVENT_HEADER = "time_utc,type,detail";
    static final String MARKET_HEADER = "time_utc,btc_price,sigma_pct_per_min,move_since_5m_start_pct,move_since_15m_start_pct";
    private static final int MAX_ROWS = 200;

    /** One line for the minute-by-minute history. */
    static String snapshotRow(long now, Feeds.Scan spot, PolyFeed.Scan poly, boolean paperOn, long bytes) {
        int down = 0;
        for (List<String> lines : Arrays.asList(spot == null ? null : spot.status, poly == null ? null : poly.status)) if (lines != null) for (String l : lines) if (l.startsWith("✗")) down++;
        Calc.Spread best = spot != null && !spot.spreads.rows.isEmpty() ? spot.spreads.rows.get(0) : null;
        Calc.Carry carry = spot != null && !spot.carry.rows.isEmpty() ? spot.carry.rows.get(0) : null;
        Ledger.Stats st = poly == null ? null : poly.ledger.stats();
        PolyFeed.Window w5 = window(poly, 0), w15 = window(poly, 1);
        return Csv.row(Csv.iso(now), spot == null ? null : spot.spotLive, spot == null ? null : spot.perpLive, spot == null ? null : spot.spreads.compared,
                spot == null ? null : spot.spreads.profitable, spot == null ? null : spot.spreads.hiddenThin, spot == null ? null : spot.spreads.hiddenSuspect,
                best == null ? null : best.base, best == null ? null : best.buyOn + ">" + best.sellOn, best == null ? null : best.netBps, best == null ? null : best.netUsdt,
                spot == null ? null : spot.carry.rows.size(), carry == null ? null : carry.base + "." + carry.exchange, carry == null ? null : carry.holdNetPct,
                paperOn ? 1 : 0, st == null ? null : st.open, st == null ? null : st.settled, st == null ? null : st.wins, st == null ? null : st.pnl, st == null ? null : st.avgModelP,
                poly == null || poly.sets == null ? null : poly.sets.profitable, down, bytes / 1e6,
                modelUp(w5), ask(w5, true), ask(w5, false), modelUp(w15), ask(w15, true), ask(w15, false));
    }
    /** One minute of the BTC backdrop (price, recent volatility, move inside the current windows); null until the first Polymarket scan has a price. */
    static String marketRow(long now, PolyFeed.Scan poly) {
        PolyFeed.Window w5 = window(poly, 0), w15 = window(poly, 1);
        PolyFeed.Window any = w5 != null && w5.fair != null ? w5 : w15 != null && w15.fair != null ? w15 : null;
        if (any == null) return null;
        return Csv.row(Csv.iso(now), any.fair.now, any.fair.sigmaPerMin * 100, w5 == null || w5.fair == null ? null : (w5.fair.now / w5.fair.start - 1) * 100,
                w15 == null || w15.fair == null ? null : (w15.fair.now / w15.fair.start - 1) * 100);
    }
    private static PolyFeed.Window window(PolyFeed.Scan poly, int i) { return poly == null || poly.windows.size() <= i ? null : poly.windows.get(i); }
    private static Double modelUp(PolyFeed.Window w) { return w == null || w.fair == null ? null : w.fair.pUp; }
    private static Double ask(PolyFeed.Window w, boolean up) {
        if (w == null) return null;
        com.arbscout.core.Poly.Book b = up ? w.up : w.down;
        return b == null ? null : b.bestAsk;
    }

    /** File name to CSV text. Tables for data that does not exist yet contain only their header. */
    static Map<String, String> build(String version, long now, Settings s, Feeds.Scan spot, PolyFeed.Scan poly, boolean paperOn, boolean serviceRunning,
                                     long startedAt, long bytes, String snapshotsCsv, String eventsCsv, String marketCsv) {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("README.txt", readme());
        StringBuilder status = new StringBuilder("key,value\n");
        status.append(Csv.row("app_version", version)).append('\n').append(Csv.row("exported_at_utc", Csv.iso(now))).append('\n');
        status.append(Csv.row("running_since_utc", startedAt == 0 ? "" : Csv.iso(startedAt))).append('\n').append(Csv.row("background_service_running", serviceRunning ? 1 : 0)).append('\n');
        status.append(Csv.row("paper_trading_on", paperOn ? 1 : 0)).append('\n').append(Csv.row("megabytes_read_uncompressed", bytes / 1e6)).append('\n');
        status.append(Csv.row("last_spot_scan_utc", spot == null ? "" : Csv.iso(spot.at))).append('\n').append(Csv.row("last_poly_scan_utc", poly == null ? "" : Csv.iso(poly.at))).append('\n');
        if (spot != null) {
            Calc.SpreadReport r = spot.spreads; Calc.CarryReport c = spot.carry;
            status.append(Csv.row("spreads_pairs_compared", r.compared)).append('\n').append(Csv.row("spreads_profitable", r.profitable)).append('\n')
                    .append(Csv.row("spreads_hidden_thin", r.hiddenThin)).append('\n').append(Csv.row("spreads_hidden_implausible", r.hiddenSuspect)).append('\n')
                    .append(Csv.row("carry_contracts_checked", c.considered)).append('\n').append(Csv.row("carry_candidates", c.rows.size())).append('\n')
                    .append(Csv.row("carry_negative_funding", c.negative)).append('\n').append(Csv.row("carry_low_volume", c.lowVolume)).append('\n').append(Csv.row("carry_no_spot_market", c.noSpot)).append('\n');
            for (String l : spot.status) status.append(Csv.row("source_status", Csv.oneLine(l))).append('\n');
        }
        if (poly != null) {
            PolyCalc.SetReport r = poly.sets;
            if (r != null) status.append(Csv.row("sets_events_scanned", r.events)).append('\n').append(Csv.row("sets_one_winner", r.exclusive)).append('\n').append(Csv.row("sets_priced", r.rows.size())).append('\n')
                    .append(Csv.row("sets_profitable", r.profitable)).append('\n').append(Csv.row("sets_excluded_incomplete_list", r.unsafe)).append('\n').append(Csv.row("sets_hidden_implausible", r.suspect)).append('\n');
            for (String l : poly.status) status.append(Csv.row("source_status", Csv.oneLine(l))).append('\n');
            for (Map.Entry<String, Ledger> a : accounts(poly).entrySet()) {
                Ledger.Stats st = a.getValue().stats(); String id = a.getKey();
                status.append(Csv.row("paper_" + id + "_rule", id.equals("A") ? "as in settings.csv" : poly.rivalLabels.get(id))).append('\n').append(Csv.row("paper_" + id + "_open", st.open)).append('\n')
                        .append(Csv.row("paper_" + id + "_settled", st.settled)).append('\n').append(Csv.row("paper_" + id + "_wins", st.wins)).append('\n').append(Csv.row("paper_" + id + "_pnl_usdt", st.pnl)).append('\n');
            }
            for (Map.Entry<String, String> n : poly.settleNotes.entrySet()) status.append(Csv.row("open_trade_note", n.getKey() + ": " + Csv.oneLine(n.getValue()))).append('\n');
        }
        files.put("status.csv", status.toString());

        StringBuilder set = new StringBuilder("key,value,label\n");
        for (String[] f : SettingsStore.FIELDS) set.append(Csv.row(f[0], SettingsStore.get(s, f[0]), f[1])).append('\n');
        files.put("settings.csv", set.toString());

        StringBuilder spreads = new StringBuilder("scan_utc,coin,buy_on,sell_on,ask,bid,gross_bps,net_bps,depth_usdt,size_usdt,est_net_usdt\n");
        if (spot != null) for (int i = 0; i < Math.min(MAX_ROWS, spot.spreads.rows.size()); i++) {
            Calc.Spread x = spot.spreads.rows.get(i);
            spreads.append(Csv.row(Csv.iso(spot.at), x.base, x.buyOn, x.sellOn, x.ask, x.bid, x.grossBps, x.netBps, x.depthUsdt, x.sizeUsdt, x.netUsdt)).append('\n');
        }
        files.put("spreads.csv", spreads.toString());

        StringBuilder carry = new StringBuilder("scan_utc,coin,exchange,funding_rate_pct,interval_hours,apr_pct,basis_bps,costs_bps,breakeven_days,net_over_hold_pct,volume_24h_usdt,spot_depth_usdt\n");
        if (spot != null) for (int i = 0; i < Math.min(MAX_ROWS, spot.carry.rows.size()); i++) {
            Calc.Carry c = spot.carry.rows.get(i);
            carry.append(Csv.row(Csv.iso(spot.at), c.base, c.exchange, c.rate * 100, c.intervalHours, c.aprPct, c.basisBps, c.costBps, c.breakevenDays, c.holdNetPct, c.volumeUsdt, c.spotDepthUsdt)).append('\n');
        }
        files.put("carry.csv", carry.toString());

        StringBuilder windows = new StringBuilder("scan_utc,label,slug,window_start_utc,window_end_utc,seconds_left,model_up,start_price,now_price,move_pct,sigma_pct_per_min,ask_up,ask_down,bid_up,bid_down,"
                + "best_side,best_ask,edge_pts,note,paper_side,paper_price,paper_stake_usdt\n");
        if (poly != null) for (PolyFeed.Window w : poly.windows) {
            windows.append(Csv.row(Csv.iso(poly.at), w.label, w.slug, Csv.iso(w.startMs), Csv.iso(w.endMs), (w.endMs - poly.at) / 1000,
                    w.fair == null ? null : w.fair.pUp, w.fair == null ? null : w.fair.start, w.fair == null ? null : w.fair.now, w.fair == null ? null : (w.fair.now / w.fair.start - 1) * 100,
                    w.fair == null ? null : w.fair.sigmaPerMin * 100, w.up == null ? null : w.up.bestAsk, w.down == null ? null : w.down.bestAsk, w.up == null ? null : w.up.bestBid, w.down == null ? null : w.down.bestBid,
                    w.edge == null ? null : w.edge.side, w.edge == null ? null : w.edge.ask, w.edge == null ? null : w.edge.edge * 100, Csv.oneLine(w.note),
                    w.position == null ? null : w.position.side, w.position == null ? null : w.position.price, w.position == null ? null : w.position.stake)).append('\n');
        }
        files.put("poly_windows.csv", windows.toString());

        StringBuilder trades = new StringBuilder("strategy,slug,label,side,opened_utc,window_end_utc,entry_price,shares,stake_usdt,model_probability,status,pnl_usdt,settled_utc,settled_by,context\n");
        if (poly != null) for (Map.Entry<String, Ledger> account : accounts(poly).entrySet()) for (Ledger.Position p : account.getValue().all()) {
            boolean open = p.status.equals("OPEN");
            trades.append(Csv.row(account.getKey(), p.slug, p.label, p.side, Csv.iso(p.openedMs), Csv.iso(p.endMs), p.price, p.shares, p.stake, p.modelP, p.status, open ? null : p.pnl,
                    open ? null : Csv.iso(p.settledMs), open ? "" : p.estimated ? "binance_estimate" : "polymarket", Csv.oneLine(p.context))).append('\n');
        }
        files.put("paper_trades.csv", trades.toString());

        StringBuilder sets = new StringBuilder("scan_utc,title,outcomes,ask_sum,cost_incl_fees,net_per_dollar\n");
        if (poly != null && poly.sets != null) for (int i = 0; i < Math.min(MAX_ROWS, poly.sets.rows.size()); i++) {
            PolyCalc.SetRow r = poly.sets.rows.get(i);
            sets.append(Csv.row(Csv.iso(poly.at), Csv.oneLine(r.title), r.outcomes, r.askSum, r.cost, r.net)).append('\n');
        }
        files.put("buy_every_outcome.csv", sets.toString());
        files.put("snapshots.csv", snapshotsCsv == null || snapshotsCsv.isEmpty() ? SNAPSHOT_HEADER + "\n" : snapshotsCsv);
        files.put("events.csv", eventsCsv == null || eventsCsv.isEmpty() ? EVENT_HEADER + "\n" : eventsCsv);
        files.put("market.csv", marketCsv == null || marketCsv.isEmpty() ? MARKET_HEADER + "\n" : marketCsv);
        return files;
    }

    /** Account A first (the one the Settings describe), then the rivals. */
    static Map<String, Ledger> accounts(PolyFeed.Scan poly) {
        Map<String, Ledger> all = new LinkedHashMap<>(); all.put("A", poly.ledger); all.putAll(poly.rivals); return all;
    }

    static byte[] zip(Map<String, String> files) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bytes)) {
            for (Map.Entry<String, String> f : files.entrySet()) { z.putNextEntry(new ZipEntry(f.getKey())); z.write(f.getValue().getBytes(StandardCharsets.UTF_8)); z.closeEntry(); }
        }
        return bytes.toByteArray();
    }

    private static String readme() {
        return "ArbScout export. All times are UTC. Numbers use a dot as the decimal separator; empty means not available.\n\n"
                + "status.csv           version, run state, data used, source status lines and the counters behind the Spreads, Carry and Buy-every-outcome summaries\n"
                + "settings.csv         every setting in force (fees in bps, thresholds, paper-trading rules)\n"
                + "spreads.csv          cross-exchange spreads from the last scan, best first (net_bps is after both fees and the safety margin)\n"
                + "carry.csv            funding-rate carry candidates from the last scan, best first (spot_depth_usdt is how much the top of the spot order book can absorb)\n"
                + "poly_windows.csv     the live BTC 5m/15m Polymarket windows at the last scan: model probability, both asks, edge, any paper position\n"
                + "paper_trades.csv     every paper trade of every account with entry details in 'context', result, P&L and whether Polymarket or a Binance estimate settled it. strategy A follows settings.csv; B and C are rival rules (B: no model filter, C: favourites only) that trade the same windows at the same moments, so their results can be compared directly\n"
                + "buy_every_outcome.csv  multi-outcome events priced as a full set (net_per_dollar above 0 would be profit before checking sizes)\n"
                + "snapshots.csv        one row per minute of summary figures, kept for roughly the last 50 hours\n"
                + "market.csv         one row per minute: BTC price, recent volatility and the move inside the current 5m and 15m windows (the market backdrop for judging results)\n"
                + "events.csv           source outages and recoveries, paper trades opened and settled, service start and stop, settings changes\n\n"
                + "Paper trades are simulated with fake money. Nothing in this app places real orders.\n";
    }
    private ExportBundle() {}
}
