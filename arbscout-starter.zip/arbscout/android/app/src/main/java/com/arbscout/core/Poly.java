package com.arbscout.core;

import java.util.*;
import org.json.*;

/** Parsers for Polymarket's public Gamma (catalogue) and CLOB (order book) replies, and Binance candles. Read-only. */
public final class Poly {
    /** Best bid and ask of one outcome token; NaN where that side of the book is empty. Sizes are shares at that best price. */
    public static final class Book {
        public final double bestBid, bidSize, bestAsk, askSize;
        public Book(double bestBid, double bidSize, double bestAsk, double askSize) { this.bestBid = bestBid; this.bidSize = bidSize; this.bestAsk = bestAsk; this.askSize = askSize; }
    }
    /** A two-outcome market. {@code winner} is the index of the winning outcome once it has resolved, else -1. */
    public static final class Market {
        public final String slug, question; public final List<String> outcomes, tokens; public final boolean closed; public final int winner;
        Market(String slug, String question, List<String> outcomes, List<String> tokens, boolean closed, int winner) {
            this.slug = slug; this.question = question; this.outcomes = outcomes; this.tokens = tokens; this.closed = closed; this.winner = winner;
        }
        public int indexOf(String name) { for (int i = 0; i < outcomes.size(); i++) if (outcomes.get(i).equalsIgnoreCase(name)) return i; return -1; }
    }
    /** One outcome of a multi-outcome event: the cheapest price to buy it now (NaN if nobody is selling). */
    public static final class Leg {
        public final String name; public final double ask, bid; public final boolean fee;
        Leg(String name, double ask, double bid, boolean fee) { this.name = name; this.ask = ask; this.bid = bid; this.fee = fee; }
    }
    public static final class Event {
        public final String title, slug; public final boolean negRisk; public final List<Leg> legs;
        Event(String title, String slug, boolean negRisk, List<Leg> legs) { this.title = title; this.slug = slug; this.negRisk = negRisk; this.legs = legs; }
    }
    public static final class Candle {
        public final long openTimeMs; public final double open, close;
        Candle(long openTimeMs, double open, double close) { this.openTimeMs = openTimeMs; this.open = open; this.close = close; }
    }

    /** Gamma sends some arrays as JSON text inside a string ("[\"Up\",\"Down\"]"); accept either form. */
    private static JSONArray array(JSONObject o, String key) throws JSONException {
        JSONArray a = o.optJSONArray(key);
        if (a != null) return a;
        String s = o.optString(key, "").trim();
        return s.startsWith("[") ? new JSONArray(s) : new JSONArray();
    }
    private static List<String> strings(JSONArray a) throws JSONException {
        List<String> out = new ArrayList<>(); for (int i = 0; i < a.length(); i++) out.add(a.optString(i, ""));
        return out;
    }
    private static JSONArray topArray(String json, String name) throws JSONException {
        String t = json.trim();
        if (t.startsWith("{")) { JSONObject o = new JSONObject(t); throw new JSONException(name + ": " + o.optString("error", o.optString("message", o.optString("msg", t)))); }
        return new JSONArray(t);
    }

    /** Reply of /markets?slug=...; null if no market has that slug. */
    public static Market parseMarket(String json) throws JSONException {
        JSONArray list = topArray(json, "Polymarket");
        if (list.length() == 0) return null;
        JSONObject m = list.getJSONObject(0);
        List<String> outcomes = strings(array(m, "outcomes")), tokens = strings(array(m, "clobTokenIds")), prices = strings(array(m, "outcomePrices"));
        boolean closed = m.optBoolean("closed", false); int winner = -1;
        if (closed) for (int i = 0; i < prices.size(); i++) if (Parsers.num(prices.get(i)) >= 0.99) winner = i;
        if (outcomes.size() != tokens.size()) throw new JSONException("Polymarket: outcomes and token ids do not match");
        return new Market(m.optString("slug"), m.optString("question"), outcomes, tokens, closed, winner);
    }
    /** Reply of CLOB /book. Best prices are found by scanning, because the order the exchange lists levels in is not relied on. */
    public static Book parseBook(String json) throws JSONException {
        JSONObject o = new JSONObject(json.trim());
        if (o.has("error")) throw new JSONException("Polymarket book: " + o.optString("error"));
        double[] bid = best(o.optJSONArray("bids"), true), ask = best(o.optJSONArray("asks"), false);
        return new Book(bid[0], bid[1], ask[0], ask[1]);
    }
    private static double[] best(JSONArray levels, boolean highest) throws JSONException {
        double price = Double.NaN, size = 0;
        if (levels != null) for (int i = 0; i < levels.length(); i++) {
            JSONObject l = levels.getJSONObject(i); double p = Parsers.num(l.optString("price")), q = Parsers.num(l.optString("size"));
            if (!(p > 0) || !(q > 0)) continue;
            if (Double.isNaN(price) || (highest ? p > price : p < price)) { price = p; size = q; } else if (p == price) size += q;
        }
        return new double[]{price, Double.isNaN(price) ? Double.NaN : size};
    }
    /** Reply of /events: every open outcome with its best prices, for events where exactly one outcome can win. */
    public static List<Event> parseEvents(String json) throws JSONException {
        JSONArray a = topArray(json, "Polymarket"); List<Event> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject e = a.getJSONObject(i); JSONArray ms = e.optJSONArray("markets");
            if (ms == null || ms.length() < 2) continue;
            boolean allNeg = true; List<Leg> legs = new ArrayList<>();
            for (int j = 0; j < ms.length(); j++) {
                JSONObject m = ms.getJSONObject(j);
                allNeg &= m.optBoolean("negRisk", false);
                if (m.optBoolean("closed", false) || !m.optBoolean("active", true) || !m.optBoolean("acceptingOrders", true)) continue;
                String fee = m.optString("feeType", "");
                legs.add(new Leg(m.optString("groupItemTitle", m.optString("question")), Parsers.num(m.optString("bestAsk")), Parsers.num(m.optString("bestBid")), !fee.isEmpty() && !fee.equals("null")));
            }
            out.add(new Event(e.optString("title"), e.optString("slug"), e.optBoolean("negRisk", false) || allNeg, legs));
        }
        return out;
    }
    /** Binance klines: [openTime, open, high, low, close, ...] per candle, oldest first. */
    public static List<Candle> parseCandles(String json) throws JSONException {
        JSONArray a = topArray(json, "BINANCE candles"); List<Candle> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONArray k = a.getJSONArray(i); double open = Parsers.num(k.optString(1)), close = Parsers.num(k.optString(4));
            if (open > 0 && close > 0) out.add(new Candle(k.getLong(0), open, close));
        }
        return out;
    }
    private Poly() {}
}
