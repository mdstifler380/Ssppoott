package com.arbscout.core;

import java.util.*;

/** Plain data shared by the parsers, the math and the screen. No Android classes. */
public final class Model {
    /** Best bid/ask for one coin against USDT on one exchange. Quantities are in coin units; NaN if the exchange does not say. */
    public static final class Quote {
        public final String exchange, base;
        public final double bid, ask, bidQty, askQty;
        public Quote(String exchange, String base, double bid, double bidQty, double ask, double askQty) {
            this.exchange = exchange; this.base = base; this.bid = bid; this.bidQty = bidQty; this.ask = ask; this.askQty = askQty;
        }
    }

    /** A USDT-margined perpetual with its latest funding rate. */
    public static final class Perp {
        public final String exchange, symbol, base;
        public final double rate, intervalHours, mark, volumeUsdt;
        public Perp(String exchange, String symbol, String base, double rate, double intervalHours, double mark, double volumeUsdt) {
            this.exchange = exchange; this.symbol = symbol; this.base = base; this.rate = rate;
            this.intervalHours = intervalHours; this.mark = mark; this.volumeUsdt = volumeUsdt;
        }
    }

    /** User assumptions. Fees are basis points (1 bp = 0.01%) per trade; defaults are typical entry-level taker fees, not your tier. */
    public static final class Settings {
        public final Map<String, Double> spotFeeBps = new LinkedHashMap<>();
        public double safetyBps = 5, minDepthUsdt = 100, tradeUsdt = 500, maxGrossBps = 200;
        public double perpFeeBps = 5, slippageBps = 5, holdDays = 30, minPerpVolumeUsdt = 20_000_000, refreshSeconds = 5;
        /** Polymarket: peak taker fee on Up/Down crypto markets (percent of cost at 50c), fee on other markets, and the paper account's rules. */
        public double polyFeePeakPct = 1.56, polyOtherFeePct = 0, paperStakeUsdt = 10, paperMinEdgePts = 6, paperMinCents = 15, paperMaxCents = 85;
        public Settings() {
            spotFeeBps.put("BINANCE", 10.0); spotFeeBps.put("BYBIT", 10.0); spotFeeBps.put("OKX", 10.0); spotFeeBps.put("MEXC", 5.0);
        }
        public double fee(String exchange) { Double f = spotFeeBps.get(exchange); return f == null ? 10 : f; }
        /** Throws IllegalArgumentException with a message fit to show the user. */
        public void validate() {
            for (Map.Entry<String, Double> e : spotFeeBps.entrySet()) range(e.getKey() + " fee", e.getValue(), 0, 200);
            range("Safety margin", safetyBps, 0, 500); range("Minimum depth", minDepthUsdt, 0, 1e9); range("Trade size", tradeUsdt, 1, 1e9);
            range("Largest believable spread", maxGrossBps, 1, 10000); range("Perp fee", perpFeeBps, 0, 200); range("Slippage", slippageBps, 0, 1000);
            range("Polymarket peak fee", polyFeePeakPct, 0, 10); range("Polymarket other fee", polyOtherFeePct, 0, 10);
            range("Paper stake", paperStakeUsdt, 1, 1e6); range("Paper minimum edge", paperMinEdgePts, 0, 50);
            range("Paper lowest price", paperMinCents, 1, 50); range("Paper highest price", paperMaxCents, 50, 99);
            range("Holding days", holdDays, 1, 3650); range("Minimum perp volume", minPerpVolumeUsdt, 0, 1e12); range("Refresh seconds", refreshSeconds, 2, 300);
        }
        private static void range(String name, double v, double lo, double hi) {
            if (!(v >= lo && v <= hi)) throw new IllegalArgumentException(name + " must be between " + lo + " and " + hi + ".");
        }
    }
    private Model() {}
}
