package com.arbscout.app;

import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import com.arbscout.core.Poly;
import com.arbscout.core.PolyCalc;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/**
 * Polymarket side of the app: finds the live BTC 5- and 15-minute Up/Down windows, reads their order books, compares them with a simple
 * model built from Binance candles, scans multi-outcome events, and runs a fake-money paper account. It never places a real order.
 * Call from one worker thread; the methods are synchronized so the screen can reset the ledger safely.
 */
final class PolyFeed {
    interface Source {
        String events() throws Exception;
        String market(String slug) throws Exception;
        String book(String token) throws Exception;
        String candles() throws Exception;
    }
    /** The public endpoints. Polymarket's Gamma and CLOB read APIs need no key. */
    static final class Network implements Source {
        @Override public String events() throws Exception { return Feeds.get("https://gamma-api.polymarket.com/events?active=true&closed=false&order=volume24hr&ascending=false&limit=60"); }
        @Override public String market(String slug) throws Exception { return Feeds.get("https://gamma-api.polymarket.com/markets?slug=" + slug); }
        @Override public String book(String token) throws Exception { return Feeds.get("https://clob.polymarket.com/book?token_id=" + token); }
        @Override public String candles() throws Exception { return Feeds.get("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=62"); }
    }

    static final class Window {
        final String label, slug; final long startMs, endMs;
        String note = ""; Poly.Market market; Poly.Book up, down; PolyCalc.Fair fair; PolyCalc.Edge edge; Ledger.Position position;
        Window(String label, String slug, long startMs, long endMs) { this.label = label; this.slug = slug; this.startMs = startMs; this.endMs = endMs; }
    }
    static final class Scan {
        final List<Window> windows; final PolyCalc.SetReport sets; final Ledger ledger; final List<String> status; final long at; final boolean paper;
        Scan(List<Window> windows, PolyCalc.SetReport sets, Ledger ledger, List<String> status, long at, boolean paper) {
            this.windows = windows; this.sets = sets; this.ledger = ledger; this.status = status; this.at = at; this.paper = paper;
        }
    }

    private static final long NEVER = Long.MIN_VALUE / 2;
    private final Source source; private final LongSupplier clock; private final Consumer<String> save;
    private final Ledger ledger = new Ledger();
    private final Map<String, Poly.Market> markets = new HashMap<>();
    private final Map<String, Long> tried = new HashMap<>();
    private PolyCalc.SetReport sets; private String setsStatus = "… POLYMARKET events · loading"; private long lastEvents = NEVER;

    PolyFeed(Source source, LongSupplier clock, String savedLedger, Consumer<String> save) {
        this.source = source; this.clock = clock; this.save = save;
        try { ledger.restore(savedLedger); } catch (RuntimeException e) { ledger.clear(); }
    }

    synchronized void resetLedger() { ledger.clear(); tried.clear(); save.accept(ledger.encode()); }

    synchronized Scan refresh(Settings s, boolean paper) {
        long now = clock.getAsLong(); Set<String> status = new LinkedHashSet<>(); boolean changed = false;
        List<Poly.Candle> candles = null;
        try { candles = Poly.parseCandles(source.candles()); status.add("✓ BINANCE candles · " + candles.size()); }
        catch (Exception e) { status.add("✗ BINANCE candles · " + Feeds.why(e)); }

        List<Window> windows = new ArrayList<>(); Set<String> current = new HashSet<>();
        for (int minutes : new int[]{5, 15}) {
            long interval = minutes * 60_000L, start = now / interval * interval;
            Window w = new Window("BTC " + minutes + "m", "btc-updown-" + minutes + "m-" + start / 1000, start, start + interval);
            windows.add(w); current.add(w.slug);
            w.market = markets.get(w.slug);
            if (w.market == null && now - tried.getOrDefault(w.slug, NEVER) >= 15_000) {
                tried.put(w.slug, now);
                try { w.market = Poly.parseMarket(source.market(w.slug)); if (w.market != null) markets.put(w.slug, w.market); }
                catch (Exception e) { status.add("✗ POLYMARKET markets · " + Feeds.why(e)); }
            }
            w.position = ledger.find(w.slug);
            if (w.market == null) { w.note = "waiting for Polymarket to list this window"; continue; }
            int upIndex = w.market.indexOf("Up"), downIndex = w.market.indexOf("Down");
            if (upIndex < 0 || downIndex < 0) { w.note = "outcomes are not Up/Down"; continue; }
            try { w.up = Poly.parseBook(source.book(w.market.tokens.get(upIndex))); } catch (Exception e) { status.add("✗ POLYMARKET order book · " + Feeds.why(e)); }
            try { w.down = Poly.parseBook(source.book(w.market.tokens.get(downIndex))); } catch (Exception e) { status.add("✗ POLYMARKET order book · " + Feeds.why(e)); }
            if (candles != null) w.fair = PolyCalc.fair(candles, w.startMs, w.endMs, now);
            if (w.fair != null && (w.up != null || w.down != null)) w.edge = PolyCalc.best(w.fair.pUp, w.up, w.down, s.polyFeePeakPct);

            if (candles == null) w.note = "no BTC price data";
            else if (w.fair == null) w.note = "waiting for this window's first price candle";
            else if (w.edge == null) w.note = "no prices to buy yet";
            else if (w.position != null) w.note = "";
            else if (paper) {
                PolyCalc.Edge e = w.edge; double secsLeft = (w.endMs - now) / 1000.0;
                if (secsLeft < 20) w.note = "too close to the end to enter";
                else if (e.edge < s.paperMinEdgePts / 100) w.note = String.format(Locale.US, "waiting for an edge of %.0f points", s.paperMinEdgePts);
                else if (e.ask < 0.05 || e.ask > 0.95) w.note = "price outside 5 to 95 cents: not entering";
                else if (e.askSize * e.ask < s.paperStakeUsdt) w.note = "book too thin for the stake";
                else {
                    w.position = ledger.open(w.slug, w.label, e.side, now, w.endMs, e.ask, e.fee, s.paperStakeUsdt, e.p);
                    if (w.position != null) { changed = true; w.note = ""; }
                }
            }
        }
        markets.keySet().retainAll(current);
        tried.values().removeIf(t -> now - t > 3_600_000L);

        for (Ledger.Position p : ledger.open()) {
            String key = "settle:" + p.slug;
            if (now < p.endMs + 20_000 || now - tried.getOrDefault(key, NEVER) < 20_000) continue;
            tried.put(key, now);
            try {
                Poly.Market m = Poly.parseMarket(source.market(p.slug));
                if (m != null && m.winner >= 0) {
                    String name = m.outcomes.get(m.winner), side = name.equalsIgnoreCase("Up") ? "UP" : name.equalsIgnoreCase("Down") ? "DOWN" : null;
                    if (side != null && ledger.settle(p.slug, side, now) > 0) changed = true;
                }
            } catch (Exception e) { status.add("✗ POLYMARKET result · " + Feeds.why(e)); }
        }

        if (now - lastEvents >= 30_000) {
            lastEvents = now;
            try { sets = PolyCalc.sets(Poly.parseEvents(source.events()), s); setsStatus = "✓ POLYMARKET events · " + sets.events + " events · " + sets.exclusive + " one-winner"; }
            catch (Exception e) { setsStatus = "✗ POLYMARKET events · " + Feeds.why(e); }
        }
        status.add(setsStatus);
        if (changed) save.accept(ledger.encode());
        return new Scan(windows, sets, ledger.copy(), new ArrayList<>(status), now, paper);
    }
}
