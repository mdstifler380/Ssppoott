package com.arbscout.app;

import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import com.arbscout.core.Poly;
import com.arbscout.core.PolyCalc;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.UnaryOperator;

/**
 * Polymarket side of the app: finds the live BTC 5- and 15-minute Up/Down windows, reads their order books, compares them with a simple
 * model built from Binance candles, scans multi-outcome events, and runs a fake-money paper account. It never places a real order.
 * Call from one worker thread; the methods are synchronized so the screen can reset the ledger safely.
 */
final class PolyFeed {
    interface Source {
        String events(int offset, int limit) throws Exception;
        String market(String slug) throws Exception;
        String book(String token) throws Exception;
        String candles() throws Exception;
        /** Same lookup restricted to finished markets; some deployments hide those from the plain lookup. */
        default String closedMarket(String slug) throws Exception { return market(slug); }
    }
    /** The public endpoints. Polymarket's Gamma and CLOB read APIs need no key. */
    static final class Network implements Source {
        @Override public String events(int offset, int limit) throws Exception {
            return Feeds.get("https://gamma-api.polymarket.com/events?active=true&closed=false&order=volume24hr&ascending=false&limit=" + limit + "&offset=" + offset);
        }
        @Override public String market(String slug) throws Exception { return Feeds.get("https://gamma-api.polymarket.com/markets?slug=" + slug); }
        @Override public String book(String token) throws Exception { return Feeds.get("https://clob.polymarket.com/book?token_id=" + token); }
        @Override public String closedMarket(String slug) throws Exception { return Feeds.get("https://gamma-api.polymarket.com/markets?slug=" + slug + "&closed=true"); }
        @Override public String candles() throws Exception { return Feeds.get("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=120"); }
    }

    static final class Window {
        final String label, slug; final long startMs, endMs;
        String note = ""; Poly.Market market; Poly.Book up, down; PolyCalc.Fair fair; PolyCalc.Edge edge; Ledger.Position position;
        Window(String label, String slug, long startMs, long endMs) { this.label = label; this.slug = slug; this.startMs = startMs; this.endMs = endMs; }
    }
    static final class Scan {
        final List<Window> windows; final PolyCalc.SetReport sets; final Ledger ledger; final List<String> status; final long at; final boolean paper; final Map<String, String> settleNotes;
        /** The rival accounts by id (B, C, ...), copies; {@link #ledger} is account A, the one the Settings describe. */
        final Map<String, Ledger> rivals; final Map<String, String> rivalLabels;
        Scan(List<Window> windows, PolyCalc.SetReport sets, Ledger ledger, List<String> status, long at, boolean paper, Map<String, String> settleNotes, Map<String, Ledger> rivals, Map<String, String> rivalLabels) {
            this.windows = windows; this.sets = sets; this.ledger = ledger; this.status = status; this.at = at; this.paper = paper; this.settleNotes = settleNotes; this.rivals = rivals; this.rivalLabels = rivalLabels;
        }
    }
    /** A rival rule set with its own fake-money account, trading exactly the same windows at exactly the same prices as account A. */
    private static final class Rival {
        final String id, label; final UnaryOperator<Settings> rule; final Ledger ledger = new Ledger(); final Consumer<String> save;
        Rival(String id, String label, UnaryOperator<Settings> rule, Consumer<String> save) { this.id = id; this.label = label; this.rule = rule; this.save = save; }
    }

    private static final long NEVER = Long.MIN_VALUE / 2, ESTIMATE_AFTER_MS = 10 * 60_000L, SETTLE_EVERY_MS = 60_000L;   // Polymarket publishes about 5.5 minutes after a window ends
    private static final int EVENT_PAGE = 20, EVENT_PAGES = 3;   // small pages: one big reply used to exceed the size limit
    private final Map<String, String> settleNotes = new HashMap<>();
    private final Source source; private final LongSupplier clock; private final Consumer<String> save;
    private final Ledger ledger = new Ledger();
    private final Map<String, Rival> rivals = new LinkedHashMap<>();
    private final Set<Ledger> dirty = new HashSet<>();
    private final Map<String, Poly.Market> markets = new HashMap<>();
    private final Map<String, Long> tried = new HashMap<>();
    private volatile long eventsEveryMs = 30_000;
    private PolyCalc.SetReport sets; private String setsStatus = "… POLYMARKET events · loading"; private long lastEvents = NEVER;

    PolyFeed(Source source, LongSupplier clock, String savedLedger, Consumer<String> save) {
        this.source = source; this.clock = clock; this.save = save;
        try { ledger.restore(savedLedger); } catch (RuntimeException e) { ledger.clear(); }
    }

    /** How often the large events list is downloaded; the app slows this down when it is running in the background. */
    void setEventsEveryMs(long ms) { eventsEveryMs = ms; }
    /**
     * Adds a rival account. Its rule turns the Settings into its own variation (for example no model filter). It is evaluated on every window
     * at the same moment as account A, so the accounts differ only by their rules and not by when or how the market was moving.
     */
    synchronized void addRival(String id, String label, UnaryOperator<Settings> rule, String savedLedger, Consumer<String> saver) {
        Rival r = new Rival(id, label, rule, saver);
        try { r.ledger.restore(savedLedger); } catch (RuntimeException e) { r.ledger.clear(); }
        rivals.put(id, r);
    }
    synchronized void resetLedger() {
        ledger.clear(); tried.clear(); save.accept(ledger.encode());
        for (Rival r : rivals.values()) { r.ledger.clear(); r.save.accept(r.ledger.encode()); }
    }
    private List<Ledger> allLedgers() { List<Ledger> all = new ArrayList<>(); all.add(ledger); for (Rival r : rivals.values()) all.add(r.ledger); return all; }
    private String entryContext(Window w, PolyCalc.Edge e, double secsLeft) {
        return String.format(Locale.US, "start=%.2f;now=%.2f;sigmaPctPerMin=%.4f;secondsLeft=%.0f;pUp=%.3f;askUp=%s;askDown=%s;edgePts=%.1f;feePct=%.2f",
                w.fair.start, w.fair.now, w.fair.sigmaPerMin * 100, secsLeft, w.fair.pUp, askText(w.up), askText(w.down), e.edge * 100, e.fee * 100);
    }
    /** Settles one window in every account that holds it; true if any account changed. */
    private boolean settleEverywhere(String slug, String side, long now, boolean estimated) {
        boolean any = false;
        for (Ledger l : allLedgers()) if (l.settle(slug, side, now, estimated) > 0) { dirty.add(l); any = true; }
        return any;
    }

    synchronized Scan refresh(Settings s, boolean paper) {
        long now = clock.getAsLong(); Set<String> status = new LinkedHashSet<>(); dirty.clear();
        List<Poly.Candle> candles = null;
        try { candles = Poly.parseCandles(source.candles()); status.add("✓ BINANCE candles · " + candles.size()); }
        catch (Exception e) { status.add("✗ BINANCE candles · " + Feeds.why(e)); }

        List<Window> windows = new ArrayList<>(); Set<String> current = new HashSet<>();
        for (int minutes : new int[]{5, 15}) {
            long interval = minutes * 60_000L, start = now / interval * interval;
            Window w = new Window("BTC " + minutes + "m", "btc-updown-" + minutes + "m-" + start / 1000, start, start + interval);
            windows.add(w); current.add(w.slug);
            w.market = markets.get(w.slug);
            if (w.market == null && now - tried.getOrDefault(w.slug, NEVER) >= 15_000) {
                tried.put(w.slug, now);
                try { w.market = Poly.parseMarket(source.market(w.slug)); if (w.market != null) markets.put(w.slug, w.market); }
                catch (Exception e) { status.add("✗ POLYMARKET markets · " + Feeds.why(e)); }
            }
            w.position = ledger.find(w.slug);
            if (w.market == null) { w.note = "waiting for Polymarket to list this window"; continue; }
            int upIndex = w.market.indexOf("Up"), downIndex = w.market.indexOf("Down");
            if (upIndex < 0 || downIndex < 0) { w.note = "outcomes are not Up/Down"; continue; }
            try { w.up = Poly.parseBook(source.book(w.market.tokens.get(upIndex))); } catch (Exception e) { status.add("✗ POLYMARKET order book · " + Feeds.why(e)); }
            try { w.down = Poly.parseBook(source.book(w.market.tokens.get(downIndex))); } catch (Exception e) { status.add("✗ POLYMARKET order book · " + Feeds.why(e)); }
            if (candles != null) w.fair = PolyCalc.fair(candles, w.startMs, w.endMs, now);
            if (w.fair != null && (w.up != null || w.down != null)) w.edge = PolyCalc.best(w.fair.pUp, w.up, w.down, s.polyFeePeakPct, s.paperMinCents / 100, s.paperMaxCents / 100, s.paperMinModelPct / 100);

            if (candles == null) w.note = "no BTC price data";
            else if (w.fair == null) w.note = "waiting for this window's first price candle";
            else if (w.edge == null) {
                if (w.up == null && w.down == null) w.note = "no prices to buy yet";
                else if (PolyCalc.best(w.fair.pUp, w.up, w.down, s.polyFeePeakPct, s.paperMinCents / 100, s.paperMaxCents / 100) == null)
                    w.note = String.format(Locale.US, "no side priced between %.0f and %.0f cents", s.paperMinCents, s.paperMaxCents);
                else w.note = String.format(Locale.US, "the model does not favour a side enough (needs %.0f%%)", s.paperMinModelPct);
            }
            else if (w.position != null) w.note = "";
            else if (paper) {
                PolyCalc.Edge e = w.edge; double secsLeft = (w.endMs - now) / 1000.0;
                if (secsLeft < 20) w.note = "too close to the end to enter";
                else if (e.edge < s.paperMinEdgePts / 100) w.note = String.format(Locale.US, "waiting for an edge of %.0f points", s.paperMinEdgePts);
                else if (e.askSize * e.ask < s.paperStakeUsdt) w.note = "book too thin for the stake";
                else {
                    w.position = ledger.open(w.slug, w.label, e.side, now, w.endMs, e.ask, e.fee, s.paperStakeUsdt, e.p, entryContext(w, e, secsLeft));
                    if (w.position != null) { dirty.add(ledger); w.note = ""; }
                }
            }
            if (paper && w.fair != null && (w.up != null || w.down != null)) {   // the rival accounts look at this very window with their own rules
                double secsLeft = (w.endMs - now) / 1000.0;
                for (Rival r : rivals.values()) {
                    if (r.ledger.has(w.slug) || secsLeft < 20) continue;
                    Settings rs = r.rule.apply(s);
                    PolyCalc.Edge e = PolyCalc.best(w.fair.pUp, w.up, w.down, rs.polyFeePeakPct, rs.paperMinCents / 100, rs.paperMaxCents / 100, rs.paperMinModelPct / 100);
                    if (e == null || e.edge < rs.paperMinEdgePts / 100 || e.askSize * e.ask < rs.paperStakeUsdt) continue;
                    if (r.ledger.open(w.slug, w.label, e.side, now, w.endMs, e.ask, e.fee, rs.paperStakeUsdt, e.p, entryContext(w, e, secsLeft)) != null) dirty.add(r.ledger);
                }
            }
        }
        markets.keySet().retainAll(current);
        tried.values().removeIf(t -> now - t > 3_600_000L);

        Map<String, Long> openWindows = new LinkedHashMap<>();   // window -> its end, over all accounts: one lookup serves every account
        for (Ledger l : allLedgers()) for (Ledger.Position p : l.open()) openWindows.putIfAbsent(p.slug, p.endMs);
        for (Map.Entry<String, Long> open : openWindows.entrySet()) {
            final String slug = open.getKey(); final long endMs = open.getValue(); long over = now - endMs;
            if (over < 20_000) continue;
            String key = "settle:" + slug; boolean settled = false;
            if (now - tried.getOrDefault(key, NEVER) >= SETTLE_EVERY_MS) {
                tried.put(key, now);
                try {
                    Poly.Market m = Poly.parseMarket(source.market(slug));
                    if (m == null) {   // the plain lookup may hide finished markets: ask for finished ones too
                        Poly.Market c = Poly.parseMarket(source.closedMarket(slug));
                        if (c != null) m = c;
                    }
                    if (m != null && m.winner >= 0) {
                        String name = m.outcomes.get(m.winner), side = name.equalsIgnoreCase("Up") ? "UP" : name.equalsIgnoreCase("Down") ? "DOWN" : null;
                        if (side != null && settleEverywhere(slug, side, now, false)) { settled = true; settleNotes.remove(slug); }
                    }
                    if (!settled) settleNotes.put(slug, m == null ? "Polymarket returned no market for this window"
                            : "Polymarket has not published a result yet (closed=" + m.closed + ", status=" + (m.uma.isEmpty() ? "none" : m.uma) + ", prices=" + m.prices + ")");
                } catch (Exception e) { settleNotes.put(slug, "result lookup failed: " + Feeds.why(e)); status.add("✗ POLYMARKET result · " + Feeds.why(e)); }
            }
            if (!settled && over >= ESTIMATE_AFTER_MS && candles != null) {   // Polymarket still silent after 10 minutes: estimate from Binance and say so
                String side = PolyCalc.outcome(candles, startOf(slug), endMs);
                if (side != null && settleEverywhere(slug, side, now, true)) settleNotes.remove(slug);
                else if (side == null) settleNotes.put(slug, "no result from Polymarket and too old to estimate from Binance candles");
            }
        }
        settleNotes.keySet().removeIf(k -> !openWindows.containsKey(k) || !openStill(k));

        if (now - lastEvents >= eventsEveryMs) {
            lastEvents = now;
            List<Poly.Event> all = new ArrayList<>(); Set<String> seen = new HashSet<>(); int pagesOk = 0; String firstError = null;
            for (int page = 0; page < EVENT_PAGES; page++) {
                try {
                    for (Poly.Event e : Poly.parseEvents(source.events(page * EVENT_PAGE, EVENT_PAGE))) if (e.slug.isEmpty() || seen.add(e.slug)) all.add(e);   // the ranking can shift between pages
                    pagesOk++;
                } catch (Exception e) { if (firstError == null) firstError = Feeds.why(e); }
            }
            if (pagesOk == 0) setsStatus = "✗ POLYMARKET events · " + firstError;
            else {
                sets = PolyCalc.sets(all, s);
                setsStatus = "✓ POLYMARKET events · " + sets.events + " events · " + sets.exclusive + " one-winner" + (pagesOk < EVENT_PAGES ? " (" + pagesOk + " of " + EVENT_PAGES + " pages loaded: " + firstError + ")" : "");
            }
        }
        status.add(setsStatus);
        for (Ledger l : dirty) {
            if (l == ledger) save.accept(ledger.encode());
            else for (Rival r : rivals.values()) if (r.ledger == l) r.save.accept(l.encode());
        }
        Map<String, Ledger> rivalCopies = new LinkedHashMap<>(); Map<String, String> labels = new LinkedHashMap<>();
        for (Rival r : rivals.values()) { rivalCopies.put(r.id, r.ledger.copy()); labels.put(r.id, r.label); }
        return new Scan(windows, sets, ledger.copy(), new ArrayList<>(status), now, paper, new HashMap<>(settleNotes), rivalCopies, labels);
    }
    private boolean openStill(String slug) {
        for (Ledger l : allLedgers()) { Ledger.Position p = l.find(slug); if (p != null && p.status.equals("OPEN")) return true; }
        return false;
    }
    private static String askText(Poly.Book b) { return b == null || Double.isNaN(b.bestAsk) ? "" : String.format(Locale.US, "%.4f", b.bestAsk); }
    /** Window start in ms, read from a slug ending in its start time in seconds; -1 if unreadable. */
    private static long startOf(String slug) {
        try { return Long.parseLong(slug.substring(slug.lastIndexOf('-') + 1)) * 1000L; } catch (NumberFormatException e) { return -1; }
    }
}
