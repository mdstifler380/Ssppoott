package com.arbscout.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.arbscout.core.Calc;
import com.arbscout.core.Ledger;
import com.arbscout.core.Poly;
import com.arbscout.core.Model.Settings;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final int INK = 0xFF1B2B24, MUTED = 0xFF66736C, GREEN = 0xFF1E7A4F, RED = 0xFFB3402F, PAPER = 0xFFF5F6F2, CARD = Color.WHITE;
    private static final String[][] FIELDS = {
            {"fee_BINANCE", "Binance spot fee per trade (bps)"}, {"fee_BYBIT", "Bybit spot fee per trade (bps)"},
            {"fee_OKX", "OKX spot fee per trade (bps)"}, {"fee_MEXC", "MEXC spot fee per trade (bps)"},
            {"safety", "Safety margin on spreads (bps)"}, {"depth", "Minimum book depth (USDT)"},
            {"trade", "Trade size for estimates (USDT)"}, {"maxGross", "Largest believable spread (bps)"},
            {"perpFee", "Perpetual fee per trade (bps)"}, {"slippage", "Slippage allowance for carry (bps)"},
            {"hold", "Holding period for carry (days)"}, {"minVol", "Minimum 24h perp volume (USDT)"},
            {"polyFee", "Polymarket Up/Down peak taker fee (%)"}, {"polyOther", "Polymarket fee on other markets (%)"},
            {"stake", "Paper stake per trade (USDT)"}, {"minEdge", "Paper entry: minimum edge (points)"},
            {"refresh", "Refresh every (seconds)"}};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Feeds feeds = new Feeds();
    private final AtomicBoolean busy = new AtomicBoolean(), busyPoly = new AtomicBoolean();
    private final Map<String, EditText> inputs = new LinkedHashMap<>();
    private volatile Settings settings = new Settings();
    private ScheduledExecutorService schedule;
    private SharedPreferences prefs;
    private LinearLayout spreadsPage, carryPage, settingsPage, spreadList, carryList;
    private TextView statusView, spreadSummary, carrySummary;
    private Button[] tabs, paperButton = new Button[1];
    private LinearLayout polyPage, windowList, ledgerList, setsList;
    private TextView polyStatus, ledgerSummary, setsSummary;
    private PolyFeed poly;
    private volatile boolean paperOn;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("arbscout", MODE_PRIVATE);
        settings = loadSettings();
        paperOn = prefs.getBoolean("paperOn", false);
        poly = new PolyFeed(new PolyFeed.Network(), System::currentTimeMillis, prefs.getString("ledger", ""), text -> prefs.edit().putString("ledger", text).apply());
        LinearLayout root = column(); root.setBackgroundColor(PAPER);
        LinearLayout header = column(); header.setPadding(dp(18), dp(14), dp(18), dp(8));
        header.addView(text("ArbScout", 24, INK, true));
        header.addView(text("Read-only · public data · no keys, no orders", 12, MUTED, false));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(dp(12), 0, dp(12), dp(8));
        String[] names = {"Spreads", "Carry", "Poly", "Settings"}; tabs = new Button[4];
        for (int i = 0; i < 4; i++) {
            final int index = i;
            tabs[i] = button(names[i], () -> show(index));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (i > 0) p.leftMargin = dp(8);
            nav.addView(tabs[i], p);
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = column(); body.setPadding(dp(14), dp(4), dp(14), dp(24));
        statusView = text("Connecting…", 11, MUTED, false); body.addView(statusView);
        spreadsPage = column(); carryPage = column(); polyPage = column(); settingsPage = column();
        spreadSummary = text("Loading prices…", 13, INK, false); spreadSummary.setPadding(0, dp(10), 0, dp(4));
        spreadsPage.addView(spreadSummary); spreadList = column(); spreadsPage.addView(spreadList);
        carrySummary = text("Loading funding rates…", 13, INK, false); carrySummary.setPadding(0, dp(10), 0, dp(4));
        carryPage.addView(carrySummary); carryList = column(); carryPage.addView(carryList);
        buildPoly(); buildSettings();
        body.addView(spreadsPage); body.addView(carryPage); body.addView(polyPage); body.addView(settingsPage);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                left = bars.left; top = bars.top; right = bars.right; bottom = Math.max(bars.bottom, ime.bottom);
            } else { left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop(); right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom(); }
            root.setPadding(left, top, right, bottom); return insets;
        });
        root.requestApplyInsets();
        show(0);
    }
    @Override protected void onStart() { super.onStart(); startScanning(); }
    @Override protected void onStop() { super.onStop(); stopScanning(); }

    // ---- scanning ----
    private void startScanning() {
        stopScanning();
        schedule = Executors.newScheduledThreadPool(2);
        long period = (long) (settings.refreshSeconds * 1000);
        schedule.scheduleWithFixedDelay(this::tick, 0, period, TimeUnit.MILLISECONDS);
        schedule.scheduleWithFixedDelay(this::polyTick, 0, period, TimeUnit.MILLISECONDS);
    }
    private void stopScanning() { if (schedule != null) { schedule.shutdownNow(); schedule = null; } }
    private void tick() {
        if (!busy.compareAndSet(false, true)) return;
        try {
            final Settings s = settings;
            final Feeds.Scan scan = feeds.refresh(s);
            ui.post(() -> render(scan, s));
        } catch (Exception e) {
            ui.post(() -> statusView.setText("Scan failed: " + e));
        } finally { busy.set(false); }
    }

    private void polyTick() {
        if (!busyPoly.compareAndSet(false, true)) return;
        try {
            final Settings s = settings; final boolean paper = paperOn;
            final PolyFeed.Scan scan = poly.refresh(s, paper);
            ui.post(() -> renderPoly(scan, s));
        } catch (Exception e) {
            ui.post(() -> polyStatus.setText("Polymarket scan failed: " + e));
        } finally { busyPoly.set(false); }
    }

    // ---- screens ----
    private void show(int tab) {
        spreadsPage.setVisibility(tab == 0 ? View.VISIBLE : View.GONE);
        carryPage.setVisibility(tab == 1 ? View.VISIBLE : View.GONE);
        polyPage.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        settingsPage.setVisibility(tab == 3 ? View.VISIBLE : View.GONE);
        statusView.setVisibility(tab <= 1 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < tabs.length; i++) { tabs[i].setBackground(shape(i == tab ? INK : CARD, 10)); tabs[i].setTextColor(i == tab ? Color.WHITE : INK); }
    }
    private void render(Feeds.Scan scan, Settings s) {
        StringBuilder st = new StringBuilder();
        for (String line : scan.status) st.append(line).append('\n');
        statusView.setText(st.append("Updated ").append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(scan.at))).toString());
        renderSpreads(scan); renderCarry(scan, s);
    }
    private void renderSpreads(Feeds.Scan scan) {
        Calc.SpreadReport r = scan.spreads; StringBuilder head = new StringBuilder();
        if (scan.spotLive < 2) head.append("Need at least two exchanges responding to compare prices. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%,d price pairs compared · %d profitable after fees", r.compared, r.profitable));
            if (r.hiddenThin + r.hiddenSuspect > 0) head.append(String.format(Locale.US, "\n%d more looked profitable but were hidden: %d on thin books, %d implausibly large.", r.hiddenThin + r.hiddenSuspect, r.hiddenThin, r.hiddenSuspect));
            if (r.profitable == 0) head.append("\nNo spread covers the fees right now. That is the normal state for liquid coins.");
            head.append("\nBuying on one exchange and selling on another needs balances already held on both.");
        }
        spreadSummary.setText(head.toString()); spreadList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Spread x = r.rows.get(i);
            addRow(spreadList, x.base + "   buy " + x.buyOn + " → sell " + x.sellOn,
                    String.format(Locale.US, "net %+.1f bps   (gross %+.1f)", x.netBps, x.grossBps), x.netBps > 0 ? GREEN : RED,
                    String.format(Locale.US, "ask %s · bid %s · depth ≈ %s USDT · est. %+.2f USDT on %s USDT", price(x.ask), price(x.bid), compact(x.depthUsdt), x.netUsdt, compact(x.sizeUsdt)));
        }
    }
    private void renderCarry(Feeds.Scan scan, Settings s) {
        Calc.CarryReport r = scan.carry; StringBuilder head = new StringBuilder();
        if (scan.perpLive == 0) head.append("Funding data is not available yet. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%d contracts checked · %d candidates", r.considered, r.rows.size()));
            head.append(String.format(Locale.US, "\nHidden: %d negative funding, %d under %s USDT daily volume, %d with no matching spot market.", r.negative, r.lowVolume, compact(s.minPerpVolumeUsdt), r.noSpot));
            head.append(String.format(Locale.US, "\nBuy spot + short the perpetual on the same exchange. Net assumes today's rate lasts %.0f days; funding can fall or turn negative, and a short can be liquidated in a sharp rally.", s.holdDays));
        }
        carrySummary.setText(head.toString()); carryList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Carry c = r.rows.get(i);
            addRow(carryList, c.base + " · " + c.exchange,
                    String.format(Locale.US, "funding %+.4f%% / %.0f h → APR %.1f%%", c.rate * 100, c.intervalHours, c.aprPct), c.aprPct > 0 ? GREEN : RED,
                    String.format(Locale.US, "net over %.0f d %+.2f%% · break-even %.1f d · costs %.0f bps · basis %+.0f bps · 24h vol %s", s.holdDays, c.holdNetPct, c.breakevenDays, c.costBps, c.basisBps, compact(c.volumeUsdt)));
        }
    }
    private void addRow(LinearLayout list, String title, String figure, int figureColor, String detail) {
        LinearLayout card = column(); card.setPadding(dp(14), dp(12), dp(14), dp(12)); card.setBackground(shape(CARD, 12));
        card.addView(text(title, 15, INK, true)); TextView f = text(figure, 14, figureColor, true); f.setPadding(0, dp(4), 0, dp(4)); card.addView(f);
        if (!detail.isEmpty()) card.addView(text(detail, 12, MUTED, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); list.addView(card, p);
    }
    private static String price(double p) { return String.format(Locale.US, p >= 1000 ? "%.2f" : p >= 1 ? "%.4f" : "%.8f", p); }
    private static String compact(double v) {
        if (Double.isNaN(v)) return "?";
        return v >= 1e9 ? String.format(Locale.US, "%.1fB", v / 1e9) : v >= 1e6 ? String.format(Locale.US, "%.1fM", v / 1e6) : v >= 1e3 ? String.format(Locale.US, "%.1fk", v / 1e3) : String.format(Locale.US, "%.0f", v);
    }

    // ---- Polymarket ----
    private void buildPoly() {
        polyStatus = text("Connecting…", 11, MUTED, false); polyStatus.setPadding(0, 0, 0, dp(8)); polyPage.addView(polyStatus);
        paperButton[0] = button("", this::togglePaper); polyPage.addView(paperButton[0], new LinearLayout.LayoutParams(-1, -2)); updatePaperButton();
        TextView paperNote = text("Paper trading uses fake money at real Polymarket prices, fees included, and settles from Polymarket's real result. It only trades while this app is open on screen.", 11, MUTED, false);
        paperNote.setPadding(0, dp(6), 0, 0); polyPage.addView(paperNote);
        polyPage.addView(heading("LIVE BTC WINDOWS")); windowList = column(); polyPage.addView(windowList);
        TextView windowNote = text("Polymarket settles these on Chainlink's BTC/USD price. This model uses Binance candles, so near the start price the two can disagree. The model is a plain random walk and ignores sudden jumps.", 11, MUTED, false);
        windowNote.setPadding(0, dp(8), 0, 0); polyPage.addView(windowNote);
        polyPage.addView(heading("PAPER ACCOUNT")); ledgerSummary = text("Loading…", 13, INK, false); polyPage.addView(ledgerSummary);
        ledgerList = column(); polyPage.addView(ledgerList);
        polyPage.addView(button("Reset paper account", this::resetPaper), new LinearLayout.LayoutParams(-1, -2));
        polyPage.addView(heading("BUY EVERY OUTCOME")); setsSummary = text("Loading events…", 13, INK, false); polyPage.addView(setsSummary);
        setsList = column(); polyPage.addView(setsList);
    }
    private TextView heading(String title) { TextView h = text(title, 11, MUTED, true); h.setPadding(0, dp(20), 0, dp(6)); return h; }
    private void togglePaper() {
        paperOn = !paperOn; prefs.edit().putBoolean("paperOn", paperOn).apply(); updatePaperButton();
        Toast.makeText(this, paperOn ? "Paper trading started" : "Paper trading stopped", Toast.LENGTH_SHORT).show();
    }
    private void updatePaperButton() { paperButton[0].setText(paperOn ? "Paper trading: ON (tap to stop)" : "Paper trading: OFF (tap to start)"); }
    /** Runs off the main thread: it shares a lock with the network refresh and must not freeze the screen. */
    private void resetPaper() {
        new Thread(() -> { poly.resetLedger(); ui.post(() -> Toast.makeText(this, "Paper account reset", Toast.LENGTH_SHORT).show()); }).start();
    }
    private void renderPoly(PolyFeed.Scan scan, Settings s) {
        StringBuilder st = new StringBuilder();
        for (String line : scan.status) st.append(line).append('\n');
        polyStatus.setText(st.append("Updated ").append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(scan.at))).toString());
        windowList.removeAllViews();
        for (PolyFeed.Window w : scan.windows) {
            long left = Math.max(0, (w.endMs - scan.at) / 1000);
            String title = String.format(Locale.US, "%s · %d:%02d left", w.label, left / 60, left % 60), figure, detail = "";
            int color = MUTED;
            if (w.fair == null || w.edge == null) figure = w.note.isEmpty() ? "no data yet" : w.note;
            else {
                figure = String.format(Locale.US, "model Up %.0f%% · best buy %s at %.2f → edge %+.1f pts", w.fair.pUp * 100, w.edge.side, w.edge.ask, w.edge.edge * 100);
                color = w.edge.edge * 100 >= s.paperMinEdgePts ? GREEN : w.edge.edge > 0 ? INK : RED;
                detail = String.format(Locale.US, "start %s → now %s (%+.3f%%) · σ %.3f%%/min · asks Up %s / Down %s", price(w.fair.start), price(w.fair.now),
                        (w.fair.now / w.fair.start - 1) * 100, w.fair.sigmaPerMin * 100, ask(w.up), ask(w.down));
                if (w.position != null) detail += String.format(Locale.US, "\nPAPER: bought %s at %.2f for %.0f USDT", w.position.side, w.position.price, w.position.stake);
                else if (!w.note.isEmpty()) detail += "\n" + w.note;
            }
            addRow(windowList, title, figure, color, detail);
        }
        Ledger.Stats ls = scan.ledger.stats(); StringBuilder b = new StringBuilder(String.format(Locale.US, "%d open · %d settled", ls.open, ls.settled));
        if (ls.settled > 0) b.append(String.format(Locale.US, "\nWon %d of %d (%.0f%%) · P&L %+.2f USDT on %.0f staked (%+.1f%%)\nThe model's average win chance on these was %.0f%%; the actual rate was %.0f%%.",
                ls.wins, ls.settled, ls.winRate() * 100, ls.pnl, ls.staked, ls.roi() * 100, ls.avgModelP * 100, ls.winRate() * 100));
        else b.append("\nNo settled trades yet. Windows resolve a few minutes after they end.");
        ledgerSummary.setText(b.toString()); ledgerList.removeAllViews();
        for (Ledger.Position p : scan.ledger.recent(8)) {
            boolean open = p.status.equals("OPEN");
            addRow(ledgerList, p.label + " · " + p.side + " at " + String.format(Locale.US, "%.2f", p.price),
                    open ? "awaiting result" : String.format(Locale.US, "%s %+.2f USDT", p.status, p.pnl), open ? MUTED : p.pnl > 0 ? GREEN : RED,
                    String.format(Locale.US, "stake %.0f USDT · model said %.0f%%", p.stake, p.modelP * 100));
        }
        if (scan.sets == null) setsSummary.setText("Loading events…");
        else {
            setsSummary.setText(String.format(Locale.US, "%d events scanned · %d have exactly one winner · %d complete sets priced · %d profitable after fees\nBuying one share of every outcome always pays $1; it only works if the asks add up to less than that. Sizes are not checked.",
                    scan.sets.events, scan.sets.exclusive, scan.sets.rows.size(), scan.sets.profitable));
            setsList.removeAllViews();
            for (int i = 0; i < Math.min(8, scan.sets.rows.size()); i++) {
                com.arbscout.core.PolyCalc.SetRow r = scan.sets.rows.get(i);
                addRow(setsList, r.title.length() > 70 ? r.title.substring(0, 70) + "…" : r.title,
                        String.format(Locale.US, "cost %.3f for a $1 payout → net %+.1f¢ per set", r.cost, r.net * 100), r.net > 0 ? GREEN : RED,
                        String.format(Locale.US, "%d outcomes · asks add up to %.3f", r.outcomes, r.askSum));
            }
        }
    }
    private static String ask(Poly.Book b) { return b == null || Double.isNaN(b.bestAsk) ? "–" : String.format(Locale.US, "%.2f", b.bestAsk); }

    // ---- settings ----
    private void buildSettings() {
        Settings s = settings;
        for (String[] f : FIELDS) {
            String section = f[0].equals("fee_BINANCE") ? "SPOT FEES" : f[0].equals("safety") ? "SPREAD SCAN" : f[0].equals("perpFee") ? "FUNDING CARRY" : f[0].equals("polyFee") ? "POLYMARKET PAPER TRADING" : f[0].equals("refresh") ? "GENERAL" : null;
            if (section != null) { TextView h = text(section, 11, MUTED, true); h.setPadding(0, dp(18), 0, dp(2)); settingsPage.addView(h); }
            TextView label = text(f[1], 13, INK, false); label.setPadding(0, dp(10), 0, dp(2)); settingsPage.addView(label);
            EditText e = new EditText(this); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            e.setText(fmt(get(s, f[0]))); e.setTextColor(INK); e.setTextSize(15); e.setPadding(dp(12), dp(10), dp(12), dp(10)); e.setBackground(shape(CARD, 10));
            inputs.put(f[0], e); settingsPage.addView(e, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(0, dp(18), 0, 0);
        actions.addView(button("Save", this::saveSettings), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.leftMargin = dp(8);
        actions.addView(button("Reset to defaults", () -> fill(new Settings())), p);
        settingsPage.addView(actions);
        TextView note = text("1 bp = 0.01%. Default fees are typical entry-level taker fees, not your tier: enter your own. Prices are top-of-book snapshots taken a few seconds apart, so a spread can vanish before orders fill. Transfers, withdrawal limits and funding changes are not modeled. This app only reads public data and never places orders.", 11, MUTED, false);
        note.setPadding(0, dp(16), 0, 0); settingsPage.addView(note);
    }
    private void saveSettings() {
        try {
            Settings s = readFields();
            SharedPreferences.Editor ed = prefs.edit();
            for (String[] f : FIELDS) ed.putString(f[0], Double.toString(get(s, f[0])));
            ed.apply(); settings = s; startScanning();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IllegalArgumentException e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private Settings readFields() {
        Settings s = new Settings();
        for (String[] f : FIELDS) {
            String raw = inputs.get(f[0]).getText().toString().trim().replace(',', '.');
            try { set(s, f[0], Double.parseDouble(raw)); } catch (NumberFormatException e) { throw new IllegalArgumentException(f[1] + " is not a number."); }
        }
        s.validate(); return s;
    }
    private void fill(Settings s) { for (String[] f : FIELDS) inputs.get(f[0]).setText(fmt(get(s, f[0]))); }
    private Settings loadSettings() {
        Settings s = new Settings();
        try {
            for (String[] f : FIELDS) { String v = prefs.getString(f[0], null); if (v != null) set(s, f[0], Double.parseDouble(v)); }
            s.validate(); return s;
        } catch (RuntimeException e) { return new Settings(); }
    }
    private static String fmt(double v) { return v == Math.rint(v) ? Long.toString((long) v) : Double.toString(v); }
    private static double get(Settings s, String k) {
        switch (k) {
            case "fee_BINANCE": return s.fee("BINANCE"); case "fee_BYBIT": return s.fee("BYBIT"); case "fee_OKX": return s.fee("OKX"); case "fee_MEXC": return s.fee("MEXC");
            case "safety": return s.safetyBps; case "depth": return s.minDepthUsdt; case "trade": return s.tradeUsdt; case "maxGross": return s.maxGrossBps;
            case "perpFee": return s.perpFeeBps; case "slippage": return s.slippageBps; case "hold": return s.holdDays; case "minVol": return s.minPerpVolumeUsdt;
            case "polyFee": return s.polyFeePeakPct; case "polyOther": return s.polyOtherFeePct; case "stake": return s.paperStakeUsdt; case "minEdge": return s.paperMinEdgePts;
            default: return s.refreshSeconds;
        }
    }
    private static void set(Settings s, String k, double v) {
        switch (k) {
            case "fee_BINANCE": s.spotFeeBps.put("BINANCE", v); break; case "fee_BYBIT": s.spotFeeBps.put("BYBIT", v); break;
            case "fee_OKX": s.spotFeeBps.put("OKX", v); break; case "fee_MEXC": s.spotFeeBps.put("MEXC", v); break;
            case "safety": s.safetyBps = v; break; case "depth": s.minDepthUsdt = v; break; case "trade": s.tradeUsdt = v; break; case "maxGross": s.maxGrossBps = v; break;
            case "perpFee": s.perpFeeBps = v; break; case "slippage": s.slippageBps = v; break; case "hold": s.holdDays = v; break; case "minVol": s.minPerpVolumeUsdt = v; break;
            case "polyFee": s.polyFeePeakPct = v; break; case "polyOther": s.polyOtherFeePct = v; break; case "stake": s.paperStakeUsdt = v; break; case "minEdge": s.paperMinEdgePts = v; break;
            default: s.refreshSeconds = v; break;
        }
    }

    // ---- small view helpers ----
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(color); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(3), 1); if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); return t;
    }
    private Button button(String title, Runnable click) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(INK);
        b.setMinHeight(dp(48)); b.setMinimumHeight(dp(48)); b.setPadding(dp(12), dp(12), dp(12), dp(12)); b.setBackground(shape(CARD, 10));
        b.setOnClickListener(v -> click.run()); return b;
    }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
