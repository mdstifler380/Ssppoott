package com.arbscout.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.arbscout.core.Calc;
import com.arbscout.core.Model.Settings;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final int INK = 0xFF1B2B24, MUTED = 0xFF66736C, GREEN = 0xFF1E7A4F, RED = 0xFFB3402F, PAPER = 0xFFF5F6F2, CARD = Color.WHITE;
    private static final String[][] FIELDS = {
            {"fee_BINANCE", "Binance spot fee per trade (bps)"}, {"fee_BYBIT", "Bybit spot fee per trade (bps)"},
            {"fee_OKX", "OKX spot fee per trade (bps)"}, {"fee_MEXC", "MEXC spot fee per trade (bps)"},
            {"safety", "Safety margin on spreads (bps)"}, {"depth", "Minimum book depth (USDT)"},
            {"trade", "Trade size for estimates (USDT)"}, {"maxGross", "Largest believable spread (bps)"},
            {"perpFee", "Perpetual fee per trade (bps)"}, {"slippage", "Slippage allowance for carry (bps)"},
            {"hold", "Holding period for carry (days)"}, {"minVol", "Minimum 24h perp volume (USDT)"},
            {"refresh", "Refresh every (seconds)"}};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Feeds feeds = new Feeds();
    private final AtomicBoolean busy = new AtomicBoolean();
    private final Map<String, EditText> inputs = new LinkedHashMap<>();
    private volatile Settings settings = new Settings();
    private ScheduledExecutorService schedule;
    private SharedPreferences prefs;
    private LinearLayout spreadsPage, carryPage, settingsPage, spreadList, carryList;
    private TextView statusView, spreadSummary, carrySummary;
    private Button[] tabs;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("arbscout", MODE_PRIVATE);
        settings = loadSettings();
        LinearLayout root = column(); root.setBackgroundColor(PAPER);
        LinearLayout header = column(); header.setPadding(dp(18), dp(14), dp(18), dp(8));
        header.addView(text("ArbScout", 24, INK, true));
        header.addView(text("Read-only · public data · no keys, no orders", 12, MUTED, false));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(dp(12), 0, dp(12), dp(8));
        String[] names = {"Spreads", "Carry", "Settings"}; tabs = new Button[3];
        for (int i = 0; i < 3; i++) {
            final int index = i;
            tabs[i] = button(names[i], () -> show(index));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (i > 0) p.leftMargin = dp(8);
            nav.addView(tabs[i], p);
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = column(); body.setPadding(dp(14), dp(4), dp(14), dp(24));
        statusView = text("Connecting…", 11, MUTED, false); body.addView(statusView);
        spreadsPage = column(); carryPage = column(); settingsPage = column();
        spreadSummary = text("Loading prices…", 13, INK, false); spreadSummary.setPadding(0, dp(10), 0, dp(4));
        spreadsPage.addView(spreadSummary); spreadList = column(); spreadsPage.addView(spreadList);
        carrySummary = text("Loading funding rates…", 13, INK, false); carrySummary.setPadding(0, dp(10), 0, dp(4));
        carryPage.addView(carrySummary); carryList = column(); carryPage.addView(carryList);
        buildSettings();
        body.addView(spreadsPage); body.addView(carryPage); body.addView(settingsPage);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                left = bars.left; top = bars.top; right = bars.right; bottom = Math.max(bars.bottom, ime.bottom);
            } else { left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop(); right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom(); }
            root.setPadding(left, top, right, bottom); return insets;
        });
        root.requestApplyInsets();
        show(0);
    }
    @Override protected void onStart() { super.onStart(); startScanning(); }
    @Override protected void onStop() { super.onStop(); stopScanning(); }

    // ---- scanning ----
    private void startScanning() {
        stopScanning();
        schedule = Executors.newSingleThreadScheduledExecutor();
        schedule.scheduleWithFixedDelay(this::tick, 0, (long) (settings.refreshSeconds * 1000), TimeUnit.MILLISECONDS);
    }
    private void stopScanning() { if (schedule != null) { schedule.shutdownNow(); schedule = null; } }
    private void tick() {
        if (!busy.compareAndSet(false, true)) return;
        try {
            final Settings s = settings;
            final Feeds.Scan scan = feeds.refresh(s);
            ui.post(() -> render(scan, s));
        } catch (Exception e) {
            ui.post(() -> statusView.setText("Scan failed: " + e));
        } finally { busy.set(false); }
    }

    // ---- screens ----
    private void show(int tab) {
        spreadsPage.setVisibility(tab == 0 ? View.VISIBLE : View.GONE);
        carryPage.setVisibility(tab == 1 ? View.VISIBLE : View.GONE);
        settingsPage.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        statusView.setVisibility(tab == 2 ? View.GONE : View.VISIBLE);
        for (int i = 0; i < tabs.length; i++) { tabs[i].setBackground(shape(i == tab ? INK : CARD, 10)); tabs[i].setTextColor(i == tab ? Color.WHITE : INK); }
    }
    private void render(Feeds.Scan scan, Settings s) {
        StringBuilder st = new StringBuilder();
        for (String line : scan.status) st.append(line).append('\n');
        statusView.setText(st.append("Updated ").append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(scan.at))).toString());
        renderSpreads(scan); renderCarry(scan, s);
    }
    private void renderSpreads(Feeds.Scan scan) {
        Calc.SpreadReport r = scan.spreads; StringBuilder head = new StringBuilder();
        if (scan.spotLive < 2) head.append("Need at least two exchanges responding to compare prices. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%,d price pairs compared · %d profitable after fees", r.compared, r.profitable));
            if (r.hiddenThin + r.hiddenSuspect > 0) head.append(String.format(Locale.US, "\n%d more looked profitable but were hidden: %d on thin books, %d implausibly large.", r.hiddenThin + r.hiddenSuspect, r.hiddenThin, r.hiddenSuspect));
            if (r.profitable == 0) head.append("\nNo spread covers the fees right now. That is the normal state for liquid coins.");
            head.append("\nBuying on one exchange and selling on another needs balances already held on both.");
        }
        spreadSummary.setText(head.toString()); spreadList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Spread x = r.rows.get(i);
            addRow(spreadList, x.base + "   buy " + x.buyOn + " → sell " + x.sellOn,
                    String.format(Locale.US, "net %+.1f bps   (gross %+.1f)", x.netBps, x.grossBps), x.netBps > 0 ? GREEN : RED,
                    String.format(Locale.US, "ask %s · bid %s · depth ≈ %s USDT · est. %+.2f USDT on %s USDT", price(x.ask), price(x.bid), compact(x.depthUsdt), x.netUsdt, compact(x.sizeUsdt)));
        }
    }
    private void renderCarry(Feeds.Scan scan, Settings s) {
        Calc.CarryReport r = scan.carry; StringBuilder head = new StringBuilder();
        if (scan.perpLive == 0) head.append("Funding data is not available yet. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%d contracts checked · %d candidates", r.considered, r.rows.size()));
            head.append(String.format(Locale.US, "\nHidden: %d negative funding, %d under %s USDT daily volume, %d with no matching spot market.", r.negative, r.lowVolume, compact(s.minPerpVolumeUsdt), r.noSpot));
            head.append(String.format(Locale.US, "\nBuy spot + short the perpetual on the same exchange. Net assumes today's rate lasts %.0f days; funding can fall or turn negative, and a short can be liquidated in a sharp rally.", s.holdDays));
        }
        carrySummary.setText(head.toString()); carryList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Carry c = r.rows.get(i);
            addRow(carryList, c.base + " · " + c.exchange,
                    String.format(Locale.US, "funding %+.4f%% / %.0f h → APR %.1f%%", c.rate * 100, c.intervalHours, c.aprPct), c.aprPct > 0 ? GREEN : RED,
                    String.format(Locale.US, "net over %.0f d %+.2f%% · break-even %.1f d · costs %.0f bps · basis %+.0f bps · 24h vol %s", s.holdDays, c.holdNetPct, c.breakevenDays, c.costBps, c.basisBps, compact(c.volumeUsdt)));
        }
    }
    private void addRow(LinearLayout list, String title, String figure, int figureColor, String detail) {
        LinearLayout card = column(); card.setPadding(dp(14), dp(12), dp(14), dp(12)); card.setBackground(shape(CARD, 12));
        card.addView(text(title, 15, INK, true)); TextView f = text(figure, 14, figureColor, true); f.setPadding(0, dp(4), 0, dp(4)); card.addView(f);
        card.addView(text(detail, 12, MUTED, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); list.addView(card, p);
    }
    private static String price(double p) { return String.format(Locale.US, p >= 1000 ? "%.2f" : p >= 1 ? "%.4f" : "%.8f", p); }
    private static String compact(double v) {
        if (Double.isNaN(v)) return "?";
        return v >= 1e9 ? String.format(Locale.US, "%.1fB", v / 1e9) : v >= 1e6 ? String.format(Locale.US, "%.1fM", v / 1e6) : v >= 1e3 ? String.format(Locale.US, "%.1fk", v / 1e3) : String.format(Locale.US, "%.0f", v);
    }

    // ---- settings ----
    private void buildSettings() {
        Settings s = settings;
        for (String[] f : FIELDS) {
            String section = f[0].equals("fee_BINANCE") ? "SPOT FEES" : f[0].equals("safety") ? "SPREAD SCAN" : f[0].equals("perpFee") ? "FUNDING CARRY" : f[0].equals("refresh") ? "GENERAL" : null;
            if (section != null) { TextView h = text(section, 11, MUTED, true); h.setPadding(0, dp(18), 0, dp(2)); settingsPage.addView(h); }
            TextView label = text(f[1], 13, INK, false); label.setPadding(0, dp(10), 0, dp(2)); settingsPage.addView(label);
            EditText e = new EditText(this); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            e.setText(fmt(get(s, f[0]))); e.setTextColor(INK); e.setTextSize(15); e.setPadding(dp(12), dp(10), dp(12), dp(10)); e.setBackground(shape(CARD, 10));
            inputs.put(f[0], e); settingsPage.addView(e, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(0, dp(18), 0, 0);
        actions.addView(button("Save", this::saveSettings), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.leftMargin = dp(8);
        actions.addView(button("Reset to defaults", () -> fill(new Settings())), p);
        settingsPage.addView(actions);
        TextView note = text("1 bp = 0.01%. Default fees are typical entry-level taker fees, not your tier: enter your own. Prices are top-of-book snapshots taken a few seconds apart, so a spread can vanish before orders fill. Transfers, withdrawal limits and funding changes are not modeled. This app only reads public data and never places orders.", 11, MUTED, false);
        note.setPadding(0, dp(16), 0, 0); settingsPage.addView(note);
    }
    private void saveSettings() {
        try {
            Settings s = readFields();
            SharedPreferences.Editor ed = prefs.edit();
            for (String[] f : FIELDS) ed.putString(f[0], Double.toString(get(s, f[0])));
            ed.apply(); settings = s; startScanning();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IllegalArgumentException e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private Settings readFields() {
        Settings s = new Settings();
        for (String[] f : FIELDS) {
            String raw = inputs.get(f[0]).getText().toString().trim().replace(',', '.');
            try { set(s, f[0], Double.parseDouble(raw)); } catch (NumberFormatException e) { throw new IllegalArgumentException(f[1] + " is not a number."); }
        }
        s.validate(); return s;
    }
    private void fill(Settings s) { for (String[] f : FIELDS) inputs.get(f[0]).setText(fmt(get(s, f[0]))); }
    private Settings loadSettings() {
        Settings s = new Settings();
        try {
            for (String[] f : FIELDS) { String v = prefs.getString(f[0], null); if (v != null) set(s, f[0], Double.parseDouble(v)); }
            s.validate(); return s;
        } catch (RuntimeException e) { return new Settings(); }
    }
    private static String fmt(double v) { return v == Math.rint(v) ? Long.toString((long) v) : Double.toString(v); }
    private static double get(Settings s, String k) {
        switch (k) {
            case "fee_BINANCE": return s.fee("BINANCE"); case "fee_BYBIT": return s.fee("BYBIT"); case "fee_OKX": return s.fee("OKX"); case "fee_MEXC": return s.fee("MEXC");
            case "safety": return s.safetyBps; case "depth": return s.minDepthUsdt; case "trade": return s.tradeUsdt; case "maxGross": return s.maxGrossBps;
            case "perpFee": return s.perpFeeBps; case "slippage": return s.slippageBps; case "hold": return s.holdDays; case "minVol": return s.minPerpVolumeUsdt;
            default: return s.refreshSeconds;
        }
    }
    private static void set(Settings s, String k, double v) {
        switch (k) {
            case "fee_BINANCE": s.spotFeeBps.put("BINANCE", v); break; case "fee_BYBIT": s.spotFeeBps.put("BYBIT", v); break;
            case "fee_OKX": s.spotFeeBps.put("OKX", v); break; case "fee_MEXC": s.spotFeeBps.put("MEXC", v); break;
            case "safety": s.safetyBps = v; break; case "depth": s.minDepthUsdt = v; break; case "trade": s.tradeUsdt = v; break; case "maxGross": s.maxGrossBps = v; break;
            case "perpFee": s.perpFeeBps = v; break; case "slippage": s.slippageBps = v; break; case "hold": s.holdDays = v; break; case "minVol": s.minPerpVolumeUsdt = v; break;
            default: s.refreshSeconds = v; break;
        }
    }

    // ---- small view helpers ----
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(color); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(3), 1); if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); return t;
    }
    private Button button(String title, Runnable click) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(INK);
        b.setMinHeight(dp(48)); b.setMinimumHeight(dp(48)); b.setPadding(dp(12), dp(12), dp(12), dp(12)); b.setBackground(shape(CARD, 10));
        b.setOnClickListener(v -> click.run()); return b;
    }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
