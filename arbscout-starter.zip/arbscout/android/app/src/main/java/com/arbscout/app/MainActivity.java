package com.arbscout.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.arbscout.core.Calc;
import com.arbscout.core.Ledger;
import com.arbscout.core.Poly;
import com.arbscout.core.Model.Settings;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int INK = 0xFF1B2B24, MUTED = 0xFF66736C, GREEN = 0xFF1E7A4F, RED = 0xFFB3402F, PAPER = 0xFFF5F6F2, CARD = Color.WHITE;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, EditText> inputs = new LinkedHashMap<>();
    private Engine engine;
    private LinearLayout spreadsPage, carryPage, settingsPage, spreadList, carryList;
    private TextView statusView, spreadSummary, carrySummary;
    private Button[] tabs, paperButton = new Button[1];
    private LinearLayout polyPage, windowList, ledgerList, setsList;
    private TextView polyStatus, ledgerSummary, setsSummary;
    private Button bgButton;
    private TextView bgNote;
    /** The scanner lives in {@link Engine}; this screen only displays what it produces. */
    private final Engine.Listener listener = new Engine.Listener() {
        @Override public void onSpot(Feeds.Scan scan) { ui.post(() -> render(scan, engine.settings())); }
        @Override public void onPoly(PolyFeed.Scan scan) { ui.post(() -> { renderPoly(scan, engine.settings()); updateBackgroundUi(); }); }
    };

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        engine = Engine.get(this);
        LinearLayout root = column(); root.setBackgroundColor(PAPER);
        LinearLayout header = column(); header.setPadding(dp(18), dp(14), dp(18), dp(8));
        header.addView(text("ArbScout", 24, INK, true));
        header.addView(text("Read-only · public data · no keys, no orders", 12, MUTED, false));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(dp(12), 0, dp(12), dp(8));
        String[] names = {"Spreads", "Carry", "Poly", "Settings"}; tabs = new Button[4];
        for (int i = 0; i < 4; i++) {
            final int index = i;
            tabs[i] = button(names[i], () -> show(index));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (i > 0) p.leftMargin = dp(8);
            nav.addView(tabs[i], p);
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = column(); body.setPadding(dp(14), dp(4), dp(14), dp(24));
        statusView = text("Connecting…", 11, MUTED, false); body.addView(statusView);
        spreadsPage = column(); carryPage = column(); polyPage = column(); settingsPage = column();
        spreadSummary = text("Loading prices…", 13, INK, false); spreadSummary.setPadding(0, dp(10), 0, dp(4));
        spreadsPage.addView(spreadSummary); spreadList = column(); spreadsPage.addView(spreadList);
        carrySummary = text("Loading funding rates…", 13, INK, false); carrySummary.setPadding(0, dp(10), 0, dp(4));
        carryPage.addView(carrySummary); carryList = column(); carryPage.addView(carryList);
        buildPoly(); buildSettings();
        body.addView(spreadsPage); body.addView(carryPage); body.addView(polyPage); body.addView(settingsPage);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                left = bars.left; top = bars.top; right = bars.right; bottom = Math.max(bars.bottom, ime.bottom);
            } else { left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop(); right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom(); }
            root.setPadding(left, top, right, bottom); return insets;
        });
        root.requestApplyInsets();
        show(0);
    }
    @Override protected void onStart() {
        super.onStart();
        engine.setVisible(true); engine.acquire("ui"); engine.addListener(listener);
        Feeds.Scan spot = engine.lastSpot(); if (spot != null) render(spot, engine.settings());
        PolyFeed.Scan poly = engine.lastPoly(); if (poly != null) renderPoly(poly, engine.settings());
        if (engine.backgroundWanted() && !ScanService.running) startBackground();   // it was on when the app was last closed
        updatePaperButton(); updateBackgroundUi();
    }
    @Override protected void onStop() {
        super.onStop();
        engine.removeListener(listener); engine.setVisible(false); engine.release("ui");   // keeps running if the background service holds it
    }

    // ---- screens ----
    private void show(int tab) {
        spreadsPage.setVisibility(tab == 0 ? View.VISIBLE : View.GONE);
        carryPage.setVisibility(tab == 1 ? View.VISIBLE : View.GONE);
        polyPage.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        settingsPage.setVisibility(tab == 3 ? View.VISIBLE : View.GONE);
        statusView.setVisibility(tab <= 1 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < tabs.length; i++) { tabs[i].setBackground(shape(i == tab ? INK : CARD, 10)); tabs[i].setTextColor(i == tab ? Color.WHITE : INK); }
    }
    private void render(Feeds.Scan scan, Settings s) {
        StringBuilder st = new StringBuilder();
        for (String line : scan.status) st.append(line).append('\n');
        statusView.setText(st.append("Updated ").append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(scan.at))).toString());
        renderSpreads(scan); renderCarry(scan, s);
    }
    private void renderSpreads(Feeds.Scan scan) {
        Calc.SpreadReport r = scan.spreads; StringBuilder head = new StringBuilder();
        if (scan.spotLive < 2) head.append("Need at least two exchanges responding to compare prices. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%,d price pairs compared · %d profitable after fees", r.compared, r.profitable));
            if (r.hiddenThin + r.hiddenSuspect > 0) head.append(String.format(Locale.US, "\n%d more looked profitable but were hidden: %d on thin books, %d implausibly large.", r.hiddenThin + r.hiddenSuspect, r.hiddenThin, r.hiddenSuspect));
            if (r.profitable == 0) head.append("\nNo spread covers the fees right now. That is the normal state for liquid coins.");
            head.append("\nBuying on one exchange and selling on another needs balances already held on both.");
        }
        spreadSummary.setText(head.toString()); spreadList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Spread x = r.rows.get(i);
            addRow(spreadList, x.base + "   buy " + x.buyOn + " → sell " + x.sellOn,
                    String.format(Locale.US, "net %+.1f bps   (gross %+.1f)", x.netBps, x.grossBps), x.netBps > 0 ? GREEN : RED,
                    String.format(Locale.US, "ask %s · bid %s · depth ≈ %s USDT · est. %+.2f USDT on %s USDT", price(x.ask), price(x.bid), compact(x.depthUsdt), x.netUsdt, compact(x.sizeUsdt)));
        }
    }
    private void renderCarry(Feeds.Scan scan, Settings s) {
        Calc.CarryReport r = scan.carry; StringBuilder head = new StringBuilder();
        if (scan.perpLive == 0) head.append("Funding data is not available yet. See the status lines above.");
        else {
            head.append(String.format(Locale.US, "%d contracts checked · %d candidates", r.considered, r.rows.size()));
            head.append(String.format(Locale.US, "\nHidden: %d negative funding, %d under %s USDT daily volume, %d with no matching spot market.", r.negative, r.lowVolume, compact(s.minPerpVolumeUsdt), r.noSpot));
            head.append(String.format(Locale.US, "\nBuy spot + short the perpetual on the same exchange. Net assumes today's rate lasts %.0f days and counts a negative basis as a cost; funding can fall or turn negative, and a short can be liquidated in a sharp rally.", s.holdDays));
        }
        carrySummary.setText(head.toString()); carryList.removeAllViews();
        for (int i = 0; i < Math.min(25, r.rows.size()); i++) {
            Calc.Carry c = r.rows.get(i);
            addRow(carryList, c.base + " · " + c.exchange,
                    String.format(Locale.US, "funding %+.4f%% / %.0f h → APR %.1f%%", c.rate * 100, c.intervalHours, c.aprPct), c.aprPct > 0 ? GREEN : RED,
                    String.format(Locale.US, "net over %.0f d %+.2f%% · break-even %.1f d · costs %.0f bps · basis %+.0f bps · 24h vol %s · spot depth ≈ %s USDT", s.holdDays, c.holdNetPct, c.breakevenDays, c.costBps, c.basisBps, compact(c.volumeUsdt), compact(c.spotDepthUsdt)));
        }
    }
    private void addRow(LinearLayout list, String title, String figure, int figureColor, String detail) {
        LinearLayout card = column(); card.setPadding(dp(14), dp(12), dp(14), dp(12)); card.setBackground(shape(CARD, 12));
        card.addView(text(title, 15, INK, true)); TextView f = text(figure, 14, figureColor, true); f.setPadding(0, dp(4), 0, dp(4)); card.addView(f);
        if (!detail.isEmpty()) card.addView(text(detail, 12, MUTED, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); list.addView(card, p);
    }
    private static String price(double p) { return String.format(Locale.US, p >= 1000 ? "%.2f" : p >= 1 ? "%.4f" : "%.8f", p); }
    private static String compact(double v) {
        if (Double.isNaN(v)) return "?";
        return v >= 1e9 ? String.format(Locale.US, "%.1fB", v / 1e9) : v >= 1e6 ? String.format(Locale.US, "%.1fM", v / 1e6) : v >= 1e3 ? String.format(Locale.US, "%.1fk", v / 1e3) : String.format(Locale.US, "%.0f", v);
    }

    // ---- Polymarket ----
    private void buildPoly() {
        polyStatus = text("Connecting…", 11, MUTED, false); polyStatus.setPadding(0, 0, 0, dp(8)); polyPage.addView(polyStatus);
        paperButton[0] = button("", this::togglePaper); polyPage.addView(paperButton[0], new LinearLayout.LayoutParams(-1, -2)); updatePaperButton();
        TextView paperNote = text("Paper trading uses fake money at real Polymarket prices, fees included, and settles from Polymarket's real result. It trades while the app is open, and also with the screen off if \"Run in background\" is on (Settings tab).", 11, MUTED, false);
        paperNote.setPadding(0, dp(6), 0, 0); polyPage.addView(paperNote);
        polyPage.addView(heading("LIVE BTC WINDOWS")); windowList = column(); polyPage.addView(windowList);
        TextView windowNote = text("Polymarket settles these on Chainlink's BTC/USD price. This model uses Binance candles, so near the start price the two can disagree. The model is a plain random walk and ignores sudden jumps.", 11, MUTED, false);
        windowNote.setPadding(0, dp(8), 0, 0); polyPage.addView(windowNote);
        polyPage.addView(heading("PAPER ACCOUNT")); ledgerSummary = text("Loading…", 13, INK, false); polyPage.addView(ledgerSummary);
        ledgerList = column(); polyPage.addView(ledgerList);
        polyPage.addView(button("Reset paper account", this::resetPaper), new LinearLayout.LayoutParams(-1, -2));
        polyPage.addView(heading("BUY EVERY OUTCOME")); setsSummary = text("Loading events…", 13, INK, false); polyPage.addView(setsSummary);
        setsList = column(); polyPage.addView(setsList);
    }
    private TextView heading(String title) { TextView h = text(title, 11, MUTED, true); h.setPadding(0, dp(20), 0, dp(6)); return h; }
    private void togglePaper() {
        engine.setPaperOn(!engine.paperOn()); updatePaperButton();
        Toast.makeText(this, engine.paperOn() ? "Paper trading started" : "Paper trading stopped", Toast.LENGTH_SHORT).show();
    }
    private void updatePaperButton() { paperButton[0].setText(engine.paperOn() ? "Paper trading: ON (tap to stop)" : "Paper trading: OFF (tap to start)"); }
    /** Runs off the main thread: it shares a lock with the network refresh and must not freeze the screen. */
    private void resetPaper() {
        new Thread(() -> { engine.resetLedger(); ui.post(() -> Toast.makeText(this, "Paper account reset", Toast.LENGTH_SHORT).show()); }).start();
    }
    private void renderPoly(PolyFeed.Scan scan, Settings s) {
        StringBuilder st = new StringBuilder();
        for (String line : scan.status) st.append(line).append('\n');
        polyStatus.setText(st.append("Updated ").append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(scan.at))).toString());
        windowList.removeAllViews();
        for (PolyFeed.Window w : scan.windows) {
            long left = Math.max(0, (w.endMs - scan.at) / 1000);
            String title = String.format(Locale.US, "%s · %d:%02d left", w.label, left / 60, left % 60), figure, detail = "";
            int color = MUTED;
            if (w.fair == null) figure = w.note.isEmpty() ? "no data yet" : w.note;
            else {
                detail = String.format(Locale.US, "start %s → now %s (%+.3f%%) · σ %.3f%%/min · asks Up %s / Down %s", price(w.fair.start), price(w.fair.now),
                        (w.fair.now / w.fair.start - 1) * 100, w.fair.sigmaPerMin * 100, ask(w.up), ask(w.down));
                if (w.edge != null) {
                    figure = String.format(Locale.US, "model Up %.0f%% · best buy %s at %s → edge %+.1f pts", w.fair.pUp * 100, w.edge.side, cents(w.edge.ask), w.edge.edge * 100);
                    color = w.edge.edge * 100 >= s.paperMinEdgePts ? GREEN : w.edge.edge > 0 ? INK : RED;
                } else figure = String.format(Locale.US, "model Up %.0f%% · %s", w.fair.pUp * 100, w.note.isEmpty() ? "no edge" : w.note);
                if (w.position != null) detail += String.format(Locale.US, "\nPAPER: bought %s at %.2f for %.0f USDT", w.position.side, w.position.price, w.position.stake);
                else if (w.edge != null && !w.note.isEmpty()) detail += "\n" + w.note;
            }
            addRow(windowList, title, figure, color, detail);
        }
        Ledger.Stats ls = scan.ledger.stats(); StringBuilder b = new StringBuilder(String.format(Locale.US, "%d open · %d settled", ls.open, ls.settled));
        if (ls.settled > 0) b.append(String.format(Locale.US, "\nWon %d of %d (%.0f%%) · P&L %+.2f USDT on %.0f staked (%+.1f%%)\nThe model's average win chance on these was %.0f%%; the actual rate was %.0f%%.",
                ls.wins, ls.settled, ls.winRate() * 100, ls.pnl, ls.staked, ls.roi() * 100, ls.avgModelP * 100, ls.winRate() * 100));
        else b.append("\nNo settled trades yet. Windows resolve a few minutes after they end.");
        if (ls.estimated > 0) b.append(String.format(Locale.US, "\n%d of the settled trades (marked *) use Binance prices because Polymarket had published no result after 10 minutes.", ls.estimated));
        ledgerSummary.setText(b.toString()); ledgerList.removeAllViews();
        for (Ledger.Position p : scan.ledger.recent(8)) {
            boolean open = p.status.equals("OPEN");
            String note = open ? scan.settleNotes.get(p.slug) : null;
            addRow(ledgerList, p.label + " · " + p.side + " at " + String.format(Locale.US, "%.2f", p.price),
                    open ? "awaiting result" : String.format(Locale.US, "%s%s %+.2f USDT", p.status, p.estimated ? "*" : "", p.pnl), open ? MUTED : p.pnl > 0 ? GREEN : RED,
                    String.format(Locale.US, "stake %.0f USDT · model said %.0f%%", p.stake, p.modelP * 100) + (note == null ? "" : "\n" + note));
        }
        if (scan.sets == null) setsSummary.setText("Loading events…");
        else {
            setsSummary.setText(String.format(Locale.US, "%d events scanned · %d have exactly one winner · %d priced as complete sets · %d profitable after fees\nExcluded: %d whose outcome list may be incomplete, %d with an implausible profit over 5¢ (almost always a list with missing outcomes).\nBuying one share of every outcome pays $1 only if every possible winner is in the set. Sizes are not checked; verify on Polymarket first.",
                    scan.sets.events, scan.sets.exclusive, scan.sets.rows.size(), scan.sets.profitable, scan.sets.unsafe, scan.sets.suspect));
            setsList.removeAllViews();
            for (int i = 0; i < Math.min(8, scan.sets.rows.size()); i++) {
                com.arbscout.core.PolyCalc.SetRow r = scan.sets.rows.get(i);
                addRow(setsList, r.title.length() > 70 ? r.title.substring(0, 70) + "…" : r.title,
                        String.format(Locale.US, "cost %.3f for a $1 payout → net %+.1f¢ per set", r.cost, r.net * 100), r.net > 0 ? GREEN : RED,
                        String.format(Locale.US, "%d outcomes · asks add up to %.3f", r.outcomes, r.askSum));
            }
        }
    }
    private static String ask(Poly.Book b) { return b == null || Double.isNaN(b.bestAsk) ? "–" : cents(b.bestAsk); }
    /** Prices under 10 cents get a third decimal so a 0.1-cent ask does not read as zero. */
    private static String cents(double p) { return String.format(Locale.US, p < 0.1 ? "%.3f" : "%.2f", p); }

    // ---- settings ----
    private void buildSettings() {
        buildBackground();
        Settings s = engine.settings();
        for (String[] f : SettingsStore.FIELDS) {
            String section = f[0].equals("fee_BINANCE") ? "SPOT FEES" : f[0].equals("safety") ? "SPREAD SCAN" : f[0].equals("perpFee") ? "FUNDING CARRY" : f[0].equals("polyFee") ? "POLYMARKET PAPER TRADING" : f[0].equals("refresh") ? "GENERAL" : null;
            if (section != null) { TextView h = text(section, 11, MUTED, true); h.setPadding(0, dp(18), 0, dp(2)); settingsPage.addView(h); }
            TextView label = text(f[1], 13, INK, false); label.setPadding(0, dp(10), 0, dp(2)); settingsPage.addView(label);
            EditText e = new EditText(this); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            e.setText(SettingsStore.fmt(SettingsStore.get(s, f[0]))); e.setTextColor(INK); e.setTextSize(15); e.setPadding(dp(12), dp(10), dp(12), dp(10)); e.setBackground(shape(CARD, 10));
            inputs.put(f[0], e); settingsPage.addView(e, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(0, dp(18), 0, 0);
        actions.addView(button("Save", this::saveSettings), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.leftMargin = dp(8);
        actions.addView(button("Reset to defaults", () -> fill(new Settings())), p);
        settingsPage.addView(actions);
        TextView note = text("1 bp = 0.01%. Default fees are typical entry-level taker fees, not your tier: enter your own. Prices are top-of-book snapshots taken a few seconds apart, so a spread can vanish before orders fill. Transfers, withdrawal limits and funding changes are not modeled. This app only reads public data and never places orders.", 11, MUTED, false);
        note.setPadding(0, dp(16), 0, 0); settingsPage.addView(note);
    }
    private void saveSettings() {
        try {
            engine.applySettings(readFields());
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IllegalArgumentException e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private Settings readFields() {
        Settings s = new Settings();
        for (String[] f : SettingsStore.FIELDS) {
            String raw = inputs.get(f[0]).getText().toString().trim().replace(',', '.');
            try { SettingsStore.set(s, f[0], Double.parseDouble(raw)); } catch (NumberFormatException e) { throw new IllegalArgumentException(f[1] + " is not a number."); }
        }
        s.validate(); return s;
    }
    private void fill(Settings s) { for (String[] f : SettingsStore.FIELDS) inputs.get(f[0]).setText(SettingsStore.fmt(SettingsStore.get(s, f[0]))); }

    // ---- background running and export ----
    private void buildBackground() {
        settingsPage.addView(heading("BACKGROUND AND DATA"));
        bgButton = button("", this::toggleBackground); settingsPage.addView(bgButton, new LinearLayout.LayoutParams(-1, -2));
        bgNote = text("", 11, MUTED, false); bgNote.setPadding(0, dp(6), 0, dp(10)); settingsPage.addView(bgNote);
        settingsPage.addView(button("Allow unrestricted battery use", this::openBatterySettings), new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8);
        settingsPage.addView(button("Export data (ZIP of CSV files)", this::exportData), p);
        TextView exportNote = text("The export holds the current scans, your settings, every paper trade with its entry details, a one-row-per-minute history and an event log. It is saved to your Downloads folder and the share sheet opens so you can attach it to a chat.", 11, MUTED, false);
        exportNote.setPadding(0, dp(6), 0, 0); settingsPage.addView(exportNote);
    }
    private void toggleBackground() {
        if (ScanService.running) {
            engine.setBackgroundWanted(false); stopService(new Intent(this, ScanService.class));
        } else {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                Toast.makeText(this, "Allow notifications so the status panel can show", Toast.LENGTH_LONG).show();
            }
            engine.setBackgroundWanted(true); startBackground();
        }
        ui.postDelayed(this::updateBackgroundUi, 600);
    }
    private void startBackground() {
        try { startForegroundService(new Intent(this, ScanService.class)); }
        catch (RuntimeException e) { Toast.makeText(this, "Could not start the background service: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void updateBackgroundUi() {
        if (bgButton == null) return;
        bgButton.setText(ScanService.running ? "Run in background: ON (tap to stop)" : "Run in background: OFF (tap to start)");
        bgNote.setText(String.format(Locale.US, "%s Keeps scanning and paper trading with the screen off or the app closed, and shows how it is doing in a notification. It uses battery and data: about %.0f MB read since the app process started. With the screen closed, the big price downloads slow to every 2 minutes.",
                ScanService.running ? "Running." : "Not running.", Feeds.BYTES.get() / 1e6));
    }
    private void openBatterySettings() {
        try { startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (RuntimeException e) { Toast.makeText(this, "Open Android Settings > Apps > ArbScout > Battery and choose Unrestricted", Toast.LENGTH_LONG).show(); }
    }
    /** Builds the bundle off the main thread, saves it to Downloads, then offers the share sheet. */
    private void exportData() {
        final boolean serviceRunning = ScanService.running;
        Toast.makeText(this, "Preparing export…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String name = Engine.exportName();
                Uri uri = saveToDownloads(name, ExportBundle.zip(engine.exportFiles(serviceRunning)));
                ui.post(() -> shareExport(uri, name));
            } catch (Exception e) { ui.post(() -> Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        }).start();
    }
    private Uri saveToDownloads(String name, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name); v.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip"); v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("could not create the file in Downloads");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("could not open the file in Downloads");
                out.write(data);
            }
            return uri;
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) throw new IOException("no storage available");
        try (OutputStream out = new FileOutputStream(new File(dir, name))) { out.write(data); }
        return null;   // older Android: saved in the app's own folder, no share link
    }
    private void shareExport(Uri uri, String name) {
        if (uri == null) { Toast.makeText(this, "Saved " + name + " in this app's Download folder (Android/data/com.arbscout.app/files/Download)", Toast.LENGTH_LONG).show(); return; }
        Toast.makeText(this, "Saved to Downloads: " + name, Toast.LENGTH_LONG).show();
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("application/zip"); send.putExtra(Intent.EXTRA_STREAM, uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(send, "Share ArbScout export")); } catch (RuntimeException e) { /* the file is already in Downloads */ }
    }

    // ---- small view helpers ----
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(color); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(3), 1); if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); return t;
    }
    private Button button(String title, Runnable click) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(INK);
        b.setMinHeight(dp(48)); b.setMinimumHeight(dp(48)); b.setPadding(dp(12), dp(12), dp(12), dp(12)); b.setBackground(shape(CARD, 10));
        b.setOnClickListener(v -> click.run()); return b;
    }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
