package com.arbscout.app;

import com.arbscout.core.Ledger;
import com.arbscout.core.PolyCalc;
import java.util.*;

/**
 * Turns two successive scans into short event records: a data source going down or coming back, a paper trade being opened or settled.
 * Use one instance per feed, because a source's line simply disappears from the next scan when it has recovered.
 */
final class ChangeLog {
    private final Map<String, Boolean> sources = new HashMap<>();
    private final Map<String, String> positions = new HashMap<>();
    private boolean primed;
    private final Map<String, String> profitableSets = new LinkedHashMap<>();

    /** Status lines look like "✓ BINANCE spot · …" or "✗ OKX spot · HTTP 451 …". Returns {type, detail} for each change. */
    List<String[]> sources(List<String> lines) {
        List<String[]> out = new ArrayList<>(); Set<String> seen = new HashSet<>();
        for (String line : lines) {
            if (line.length() < 3) continue;
            char mark = line.charAt(0);
            if (mark != '✓' && mark != '✗') continue;
            String key = key(line); boolean ok = mark == '✓'; seen.add(key);
            Boolean before = sources.put(key, ok);
            if (!ok && (before == null || before)) out.add(new String[]{"SOURCE_DOWN", Csv.oneLine(line.substring(2))});
            else if (ok && before != null && !before) out.add(new String[]{"SOURCE_UP", key});
        }
        for (Iterator<Map.Entry<String, Boolean>> it = sources.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, Boolean> e = it.next();
            if (!seen.contains(e.getKey()) && !e.getValue()) { out.add(new String[]{"SOURCE_UP", e.getKey()}); it.remove(); }
        }
        return out;
    }
    /** New and newly settled paper positions. The first call only learns what already exists, so a restart does not replay history. */
    List<String[]> paper(Ledger ledger) {
        List<String[]> out = new ArrayList<>();
        for (Ledger.Position p : ledger.all()) {
            String state = p.status + (p.estimated ? "*" : ""), before = positions.put(p.slug, state);
            if (!primed) continue;
            if (before == null) out.add(new String[]{"PAPER_OPEN", String.format(Locale.US, "%s %s at %.3f stake %.2f model %.3f %s", p.label, p.side, p.price, p.stake, p.modelP, p.slug)});
            else if (before.equals("OPEN") && !p.status.equals("OPEN"))
                out.add(new String[]{"PAPER_SETTLED", String.format(Locale.US, "%s %s %s%s pnl %+.2f %s", p.label, p.side, p.status, p.estimated ? " (estimated from Binance)" : "", p.pnl, p.slug)});
        }
        primed = true; return out;
    }
    /**
     * Buy-every-outcome sets that cost less than the $1 they pay: one SET_PROFITABLE row when a set first appears and one SET_GONE row when it
     * disappears, so an export shows which event it was and how large the gap was. Sizes are not checked by the scan itself.
     */
    List<String[]> sets(PolyCalc.SetReport report) {
        List<String[]> out = new ArrayList<>();
        if (report == null) return out;
        Map<String, String> now = new LinkedHashMap<>();
        for (PolyCalc.SetRow r : report.rows) if (r.net > 0) now.put(r.title, String.format(Locale.US, "%s · %d outcomes · asks add up to %.3f · net %+.2f cents per $1 set", r.title, r.outcomes, r.askSum, r.net * 100));
        for (Map.Entry<String, String> e : now.entrySet()) if (!profitableSets.containsKey(e.getKey())) out.add(new String[]{"SET_PROFITABLE", Csv.oneLine(e.getValue())});
        for (Map.Entry<String, String> e : profitableSets.entrySet()) if (!now.containsKey(e.getKey())) out.add(new String[]{"SET_GONE", Csv.oneLine(e.getValue())});
        profitableSets.clear(); profitableSets.putAll(now);
        return out;
    }
    void forgetPositions() { positions.clear(); primed = false; }
    /** Forget everything seen so far: used when scanning stops, so a gap in scanning is not read as one long outage. */
    void reset() { sources.clear(); positions.clear(); profitableSets.clear(); primed = false; }
    private static String key(String line) { String body = line.substring(2); int dot = body.indexOf(" · "); return dot < 0 ? body : body.substring(0, dot); }
}
