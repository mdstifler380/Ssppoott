package com.arbscout.app;

import java.time.Instant;

/** Minimal CSV writing: a field with a comma, quote or line break is quoted; NaN and null become empty. */
final class Csv {
    static String cell(Object o) {
        if (o == null) return "";
        String s;
        if (o instanceof Double || o instanceof Float) { double d = ((Number) o).doubleValue(); s = Double.isNaN(d) || Double.isInfinite(d) ? "" : Double.toString(d); }
        else s = String.valueOf(o);
        if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0) return '"' + s.replace("\"", "\"\"") + '"';
        return s;
    }
    static String row(Object... cells) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cells.length; i++) { if (i > 0) b.append(','); b.append(cell(cells[i])); }
        return b.toString();
    }
    static String iso(long ms) { return Instant.ofEpochMilli(ms).toString(); }
    /** One line only, so that a row of a history file is always one line. */
    static String oneLine(String s) { return s == null ? "" : s.replace('\r', ' ').replace('\n', ' '); }
    private Csv() {}
}
