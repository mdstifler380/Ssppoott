package com.arbscout.app;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** An append-only CSV file that keeps roughly the last {@code maxLines} rows, so a long background run never grows without limit. */
final class HistoryLog {
    private final File file; private final String header; private final int maxLines; private int lines = -1;

    HistoryLog(File file, String header, int maxLines) { this.file = file; this.header = header; this.maxLines = maxLines; }

    /** Adds one row (no line breaks inside). Failures are ignored: logging must never stop the scanner. */
    synchronized void append(String row) {
        try {
            if (lines < 0) lines = Math.max(0, readLines().size() - 1);
            boolean fresh = !file.exists() || file.length() == 0;
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8)) {
                if (fresh) { w.write(header); w.write('\n'); lines = 0; }
                w.write(Csv.oneLine(row)); w.write('\n');
            }
            lines++;
            if (lines > maxLines + maxLines / 4) trim();
        } catch (IOException ignored) { /* disk full or similar */ }
    }
    /** The whole file, header first; just the header if nothing was logged yet. */
    synchronized String read() {
        List<String> all = readLines();
        if (all.isEmpty()) return header + "\n";
        StringBuilder b = new StringBuilder();
        for (String l : all) b.append(l).append('\n');
        return b.toString();
    }
    synchronized void clear() { lines = 0; //noinspection ResultOfMethodCallIgnored
        file.delete(); }
    private void trim() throws IOException {
        List<String> all = readLines(); int keep = Math.min(maxLines, all.size() - 1);
        File tmp = new File(file.getPath() + ".tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp, false), StandardCharsets.UTF_8)) {
            w.write(header); w.write('\n');
            for (int i = all.size() - keep; i < all.size(); i++) { w.write(all.get(i)); w.write('\n'); }
        }
        if (!tmp.renameTo(file)) { //noinspection ResultOfMethodCallIgnored
            file.delete(); if (!tmp.renameTo(file)) throw new IOException("could not replace the trimmed log"); }
        lines = keep;
    }
    private List<String> readLines() {
        List<String> out = new ArrayList<>();
        if (!file.exists()) return out;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String l; while ((l = r.readLine()) != null) out.add(l);
        } catch (IOException ignored) { /* return what was read */ }
        return out;
    }
}
