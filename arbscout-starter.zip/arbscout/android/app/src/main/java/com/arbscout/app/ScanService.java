package com.arbscout.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Keeps the scanner running with the screen off or the app closed, the way a VPN app does: a foreground service with a status notification
 * (what is working, what the paper account is doing) and a Stop button. It holds a wake lock so the CPU keeps running while the screen is off.
 */
public final class ScanService extends Service {
    static final String ACTION_STOP = "com.arbscout.app.STOP";
    private static final String CHANNEL = "arbscout_status";
    private static final int NOTIFICATION_ID = 7;
    private static final long WAKE_MS = 10 * 60_000L, MIN_UPDATE_MS = 4_000L;
    /** True while the service exists; the screen reads it to show the right button. */
    static volatile boolean running;

    private Engine engine; private NotificationManager notifications; private PowerManager.WakeLock wake; private volatile long lastUpdate;
    private final Engine.Listener listener = new Engine.Listener() {
        @Override public void onSpot(Feeds.Scan scan) { update(); }
        @Override public void onPoly(PolyFeed.Scan scan) { update(); }
    };

    @Override public void onCreate() {
        super.onCreate();
        notifications = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Scanner status", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Shows what ArbScout is doing while it runs in the background");
        notifications.createNotificationChannel(channel);
        engine = Engine.get(this);
        try {
            Notification first = build(engine.notice());
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTIFICATION_ID, first);
        } catch (RuntimeException e) {   // for example the system refusing a foreground start
            engine.logEvent("ERROR", "could not start in the foreground: " + e);
            stopSelf(); return;
        }
        PowerManager pm = getSystemService(PowerManager.class);
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "arbscout:scan");
        wake.setReferenceCounted(false); wake.acquire(WAKE_MS);
        running = true;
        engine.acquire("service"); engine.addListener(listener);
        engine.logEvent("SERVICE_START", "background service started");
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { engine.setBackgroundWanted(false); stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }
    @Override public void onDestroy() {
        if (running) {
            engine.removeListener(listener); engine.release("service");
            engine.logEvent("SERVICE_STOP", "background service stopped");
        }
        running = false;
        if (wake != null && wake.isHeld()) wake.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    /** Refreshes the notification at most every few seconds and keeps the bounded wake lock alive. */
    private void update() {
        long now = System.currentTimeMillis();
        if (now - lastUpdate < MIN_UPDATE_MS) return;
        lastUpdate = now;
        if (wake != null) wake.acquire(WAKE_MS);
        notifications.notify(NOTIFICATION_ID, build(engine.notice()));
    }
    private Notification build(Notice n) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, ScanService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat).setContentTitle(n.title).setContentText(n.text)
                .setStyle(new Notification.BigTextStyle().bigText(n.big)).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(open).addAction(0, "Stop", stop).setWhen(System.currentTimeMillis()).setShowWhen(true).build();
    }
}
