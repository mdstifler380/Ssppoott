package com.arbscout.app;

import static org.junit.Assert.*;

import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.junit.Test;

public class BackgroundPiecesTest {
    static final long T = PolyFeedTest.T;

    /** A small CSV reader for the tests: quoted fields, doubled quotes, line breaks only between rows. */
    static List<List<String>> parse(String csv) {
        List<List<String>> rows = new ArrayList<>(); List<String> row = new ArrayList<>(); StringBuilder f = new StringBuilder(); boolean quoted = false;
        for (int i = 0; i < csv.length(); i++) {
            char c = csv.charAt(i);
            if (quoted) { if (c == '"') { if (i + 1 < csv.length() && csv.charAt(i + 1) == '"') { f.append('"'); i++; } else quoted = false; } else f.append(c); }
            else if (c == '"') quoted = true;
            else if (c == ',') { row.add(f.toString()); f.setLength(0); }
            else if (c == '\n') { row.add(f.toString()); f.setLength(0); rows.add(row); row = new ArrayList<>(); }
            else f.append(c);
        }
        return rows;
    }

    // ---- Csv ----
    @Test public void csvQuotesOnlyWhenNeededAndBlanksNanAndNull() {
        assertEquals("a,b", Csv.row("a", "b"));
        assertEquals("\"a,b\",\"say \"\"hi\"\"\",\"line\nbreak\"", Csv.row("a,b", "say \"hi\"", "line\nbreak"));
        assertEquals("x,,,,y", Csv.row("x", null, Double.NaN, Double.POSITIVE_INFINITY, "y"));
        assertEquals("1.0E-4", Csv.cell(0.0001)); assertEquals("0.5", Csv.cell(0.5)); assertEquals("3", Csv.cell(3)); assertEquals("-7", Csv.cell(-7L));
        assertEquals("2026-01-01T00:00:00Z", Csv.iso(1767225600000L));
        assertEquals("a b  c", Csv.oneLine("a\nb\r\nc"));
    }

    // ---- HistoryLog ----
    static File tempDir() throws IOException { return Files.createTempDirectory("arbscout-test").toFile(); }
    @Test public void historyKeepsHeaderRowsAndTrimsToTheNewest() throws Exception {
        File dir = tempDir(); HistoryLog log = new HistoryLog(new File(dir, "h.csv"), "time,value", 10);
        assertEquals("time,value\n", log.read());
        for (int i = 1; i <= 13; i++) log.append("r" + i + "," + i);
        List<String> lines = Arrays.asList(log.read().split("\n"));
        assertEquals(11, lines.size()); assertEquals("time,value", lines.get(0)); assertEquals("r4,4", lines.get(1)); assertEquals("r13,13", lines.get(10));   // the 13th row triggered the trim
        log.append("multi\nline"); assertTrue(log.read().contains("multi line\n"));
        log.clear(); assertEquals("time,value\n", log.read());
    }
    @Test public void historySurvivesARestartAndConcurrentWriters() throws Exception {
        File file = new File(tempDir(), "h.csv"); HistoryLog a = new HistoryLog(file, "t,v", 1000);
        a.append("1,a"); a.append("2,b");
        HistoryLog b = new HistoryLog(file, "t,v", 1000); b.append("3,c");
        assertEquals("t,v\n1,a\n2,b\n3,c\n", b.read());
        Thread[] ts = new Thread[4];
        for (int t = 0; t < ts.length; t++) { final int id = t; ts[t] = new Thread(() -> { for (int i = 0; i < 50; i++) b.append("w" + id + "," + i); }); ts[t].start(); }
        for (Thread t : ts) t.join();
        assertEquals(1 + 3 + 200, b.read().split("\n").length);
    }

    // ---- ChangeLog ----
    @Test public void sourceOutagesAndRecoveriesAreReportedOnceEach() {
        ChangeLog c = new ChangeLog();
        assertTrue(c.sources(Arrays.asList("✓ BINANCE spot · 516 pairs", "✓ OKX spot · 450 pairs")).isEmpty());             // first sight of healthy sources: nothing to report
        List<String[]> down = c.sources(Arrays.asList("✓ BINANCE spot · 1", "✗ OKX spot · HTTP 451 (blocked) · excluded"));
        assertEquals(1, down.size()); assertEquals("SOURCE_DOWN", down.get(0)[0]); assertTrue(down.get(0)[1].startsWith("OKX spot"));
        assertTrue(c.sources(Arrays.asList("✓ BINANCE spot · 1", "✗ OKX spot · HTTP 451 (blocked) · excluded")).isEmpty());   // still down: no repeat
        List<String[]> up = c.sources(Arrays.asList("✓ BINANCE spot · 1", "✓ OKX spot · 450 pairs"));
        assertEquals(1, up.size()); assertEquals("SOURCE_UP", up.get(0)[0]); assertEquals("OKX spot", up.get(0)[1]);
        assertEquals("SOURCE_DOWN", new ChangeLog().sources(Arrays.asList("✗ BINANCE candles · boom")).get(0)[0]);          // a source that is down from the start
    }
    @Test public void aFailureLineThatDisappearsMeansTheSourceRecovered() {
        ChangeLog c = new ChangeLog();
        assertEquals("SOURCE_DOWN", c.sources(Arrays.asList("✓ BINANCE candles · 120", "✗ POLYMARKET markets · HTTP 500")).get(0)[0]);
        List<String[]> back = c.sources(Arrays.asList("✓ BINANCE candles · 120"));
        assertEquals(1, back.size()); assertEquals("SOURCE_UP", back.get(0)[0]); assertEquals("POLYMARKET markets", back.get(0)[1]);
        assertTrue(c.sources(Arrays.asList("✓ BINANCE candles · 120")).isEmpty());
    }
    static com.arbscout.core.PolyCalc.SetReport setsAt(double ask, String title) throws Exception {
        String json = "[{\"title\":\"" + title + "\",\"slug\":\"x\",\"negRisk\":true,\"markets\":[{\"bestAsk\":" + ask + "},{\"bestAsk\":" + ask + "},{\"bestAsk\":" + ask + "}]}]";
        return com.arbscout.core.PolyCalc.sets(com.arbscout.core.Poly.parseEvents(json), new Settings());
    }
    @Test public void profitableSetsAreLoggedOnceWhenTheyAppearAndOnceWhenTheyGo() throws Exception {
        ChangeLog c = new ChangeLog();
        assertTrue(c.sets(null).isEmpty());
        assertTrue(c.sets(setsAt(0.34, "Dear")).isEmpty());                                // 3 x 0.34 = 1.02: costs more than it pays
        List<String[]> on = c.sets(setsAt(0.32, "Cheap"));                                  // 3 x 0.32 = 0.96
        assertEquals(1, on.size()); assertEquals("SET_PROFITABLE", on.get(0)[0]);
        assertTrue(on.get(0)[1], on.get(0)[1].startsWith("Cheap · 3 outcomes · asks add up to 0.960 · net +4.00 cents"));
        assertTrue(c.sets(setsAt(0.32, "Cheap")).isEmpty());                                // still there: no repeat
        List<String[]> gone = c.sets(setsAt(0.34, "Cheap"));
        assertEquals(1, gone.size()); assertEquals("SET_GONE", gone.get(0)[0]); assertTrue(gone.get(0)[1].startsWith("Cheap"));
        c.sets(setsAt(0.32, "Cheap")); c.reset(); assertEquals(1, c.sets(setsAt(0.32, "Cheap")).size());   // after a restart it is news again
    }
    @Test public void aGapInScanningIsNotReadAsOneLongOutage() {
        ChangeLog c = new ChangeLog();
        assertEquals("SOURCE_DOWN", c.sources(Arrays.asList("✗ POLYMARKET result · timeout")).get(0)[0]);
        c.reset();                                                                // scanning stopped and later started again
        assertTrue(c.sources(Arrays.asList("✓ BINANCE candles · 120")).isEmpty());   // the old failure line is simply gone: no recovery event invented
    }
    @Test public void paperTradesAreReportedWhenOpenedAndSettledButNotReplayedAfterARestart() {
        Ledger l = new Ledger(); l.open("a", "BTC 5m", "UP", 1, 2, 0.5, 0.01, 10, 0.6);
        ChangeLog c = new ChangeLog();
        assertTrue(c.paper(l).isEmpty());                                         // the first look only learns what exists
        l.open("b", "BTC 15m", "DOWN", 3, 4, 0.4, 0.01, 10, 0.5);
        List<String[]> opened = c.paper(l); assertEquals(1, opened.size()); assertEquals("PAPER_OPEN", opened.get(0)[0]); assertTrue(opened.get(0)[1].contains("BTC 15m DOWN"));
        l.settle("a", "UP", 9); l.settle("b", "UP", 9, true);
        List<String[]> done = c.paper(l);
        assertEquals(2, done.size()); assertEquals("PAPER_SETTLED", done.get(0)[0]); assertTrue(done.get(0)[1].contains("WON")); assertTrue(done.get(1)[1].contains("LOST") && done.get(1)[1].contains("estimated"));
        assertTrue(c.paper(l).isEmpty());
        c.forgetPositions(); assertTrue(c.paper(l).isEmpty());
    }

    // ---- Notice ----
    @Test public void notificationSummarisesSourcesSpreadsCarryAndPaperAccount() {
        long[] now = {T + 120_000}; Settings s = new Settings();
        Feeds.Scan spot = new Feeds(new FeedsTest.Fake(), () -> now[0]).refresh(s);
        PolyFeed.Scan poly = PolyFeedTest.feed(PolyFeedTest.bullish(now[0], 0.60, 500), now, new ArrayList<>(), "").refresh(s, true);
        Notice n = Notice.build(spot, poly, true, now[0] - 125 * 60_000L, now[0] + 5_000, 12_345_678);
        assertEquals("ArbScout · 8 sources OK", n.title);
        assertTrue(n.text.startsWith("Paper ON: 2 open · 0 settled"));
        for (String part : new String[]{"Spreads:", "Carry:", "Paper ON: 2 open", "running 2 h 5 min", "≈12 MB read"}) assertTrue(part, n.big.contains(part));
    }
    @Test public void rivalRulesAppearOnlyInTheExpandedNotification() {
        long[] now = {T + 120_000}; Settings s = new Settings();
        PolyFeed pf = PolyFeedTest.feed(PolyFeedTest.bullish(now[0], 0.60, 500), now, new ArrayList<>(), ""); Engine.addStandardRivals(pf, EngineTest.memoryPrefs());
        PolyFeed.Scan poly = pf.refresh(s, true);
        Notice n = Notice.build(null, poly, true, now[0], now[0], 0);
        assertTrue(n.big, n.big.contains("Rival rules (P&L USDT): B 0 settled · C 0 settled")); assertFalse(n.text.contains("Rival"));
    }
    @Test public void aSettingsCopyIsIndependent() {
        Settings a = new Settings(); a.paperStakeUsdt = 33; a.spotFeeBps.put("OKX", 7.0);
        Settings b = a.copy();
        for (String[] f : SettingsStore.FIELDS) assertEquals(f[0], SettingsStore.get(a, f[0]), SettingsStore.get(b, f[0]), 0);
        b.paperMinModelPct = 0; b.spotFeeBps.put("OKX", 1.0); b.paperStakeUsdt = 1;
        assertEquals(55, a.paperMinModelPct, 0); assertEquals(7.0, a.fee("OKX"), 0); assertEquals(33, a.paperStakeUsdt, 0);
    }
    @Test public void notificationNamesSourcesThatAreDownAndCopesWithNoData() {
        long[] now = {T + 120_000}; FeedsTest.Fake fake = new FeedsTest.Fake(); fake.failing.add("OKX");
        Feeds.Scan spot = new Feeds(fake, () -> now[0]).refresh(new Settings());
        Notice n = Notice.build(spot, null, false, 0, now[0], 0);
        assertTrue(n.title.contains("1 of 6 sources down")); assertTrue(n.big.startsWith("Down: OKX spot")); assertTrue(n.big.contains("Paper OFF: waiting"));
        Notice empty = Notice.build(null, null, false, 0, now[0], 0);
        assertEquals("ArbScout · starting…", empty.title); assertTrue(empty.big.contains("waiting for the first scan"));
        assertEquals("0 min", Notice.duration(-5)); assertEquals("59 min", Notice.duration(59 * 60_000L)); assertEquals("1 h 0 min", Notice.duration(60 * 60_000L));
    }

    // ---- SettingsStore ----
    @Test public void everySettingFieldMapsBothWays() {
        Set<String> keys = new HashSet<>();
        for (String[] f : SettingsStore.FIELDS) {
            assertTrue("duplicate key " + f[0], keys.add(f[0]));
            Settings s = new Settings(); SettingsStore.set(s, f[0], 7.5); assertEquals(f[0], 7.5, SettingsStore.get(s, f[0]), 0);
        }
        Settings d = new Settings();
        assertEquals(10, SettingsStore.get(d, "fee_BINANCE"), 0); assertEquals(5, SettingsStore.get(d, "fee_MEXC"), 0); assertEquals(15, SettingsStore.get(d, "minPrice"), 0); assertEquals(5, SettingsStore.get(d, "refresh"), 0); assertEquals(15, SettingsStore.get(d, "spotRefresh"), 0); assertEquals(55, SettingsStore.get(d, "minModel"), 0);
        assertEquals("10", SettingsStore.fmt(10)); assertEquals("1.56", SettingsStore.fmt(1.56));
    }

    // ---- ExportBundle ----
    static Map<String, String> unzip(byte[] zip) throws IOException {
        Map<String, String> out = new LinkedHashMap<>();
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(zip))) {
            ZipEntry e; while ((e = z.getNextEntry()) != null) { ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n; while ((n = z.read(buf)) > 0) b.write(buf, 0, n); out.put(e.getName(), b.toString("UTF-8")); }
        }
        return out;
    }
    @Test public void exportContainsEveryTableWithConsistentColumns() throws Exception {
        long[] now = {T + 120_000}; Settings s = new Settings(); FeedsTest.Fake fake = new FeedsTest.Fake(); fake.failing.add("OKX");
        Feeds.Scan spot = new Feeds(fake, () -> now[0]).refresh(s);
        PolyFeed pf = PolyFeedTest.feed(PolyFeedTest.bullish(now[0], 0.60, 500), now, new ArrayList<>(), ""); Engine.addStandardRivals(pf, EngineTest.memoryPrefs());
        PolyFeed.Scan poly = pf.refresh(s, true);
        Map<String, String> files = ExportBundle.build("9.9.9", now[0], s, spot, poly, true, true, now[0] - 600_000, 5_000_000,
                ExportBundle.SNAPSHOT_HEADER + "\n" + ExportBundle.snapshotRow(now[0], spot, poly, true, 5_000_000) + "\n", null, ExportBundle.MARKET_HEADER + "\n" + ExportBundle.marketRow(now[0], poly) + "\n");
        assertEquals(new HashSet<>(Arrays.asList("README.txt", "status.csv", "settings.csv", "spreads.csv", "carry.csv", "poly_windows.csv", "paper_trades.csv", "buy_every_outcome.csv", "snapshots.csv", "events.csv", "market.csv")), files.keySet());
        for (Map.Entry<String, String> f : files.entrySet()) {
            if (!f.getKey().endsWith(".csv")) continue;
            List<List<String>> rows = parse(f.getValue()); int width = rows.get(0).size();
            for (List<String> r : rows) assertEquals(f.getKey() + " row " + r, width, r.size());
        }
        List<List<String>> trades = parse(files.get("paper_trades.csv"));
        assertEquals(1 + 3 * 2, trades.size());                                   // header + the 5m and 15m positions of each of the three accounts
        assertEquals("A", trades.get(1).get(0)); assertEquals("B", trades.get(3).get(0)); assertEquals("C", trades.get(5).get(0));
        assertTrue(trades.get(1).get(14).contains("pUp=") && trades.get(1).get(14).contains("askUp=0.6000")); assertEquals("OPEN", trades.get(1).get(10));
        String statusCsv = files.get("status.csv");
        assertTrue(statusCsv.contains("paper_A_open,2") && statusCsv.contains("paper_B_open,2") && statusCsv.contains("paper_C_open,2") && statusCsv.contains("paper_B_rule"));
        List<List<String>> market = parse(files.get("market.csv")); assertEquals(2, market.size()); assertEquals(5, market.get(1).size());
        assertEquals(1 + SettingsStore.FIELDS.length, parse(files.get("settings.csv")).size());
        assertEquals(3, parse(files.get("poly_windows.csv")).size());
        List<List<String>> sp = parse(files.get("spreads.csv"));
        assertTrue(sp.size() >= 1 && sp.size() <= 201);                          // header plus at most 200 rows
    }
    @Test public void statusTableKeepsHostileTextIntact() throws Exception {
        long[] now = {T + 120_000}; FeedsTest.Fake inner = new FeedsTest.Fake();
        Feeds.Source fake = new Feeds.Source() {
            @Override public List<com.arbscout.core.Model.Quote> spot(String ex) throws Exception { if (ex.equals("OKX")) throw new IOException("HTTP 500, \"bad\"\ngateway"); return inner.spot(ex); }
            @Override public List<com.arbscout.core.Model.Perp> perps(String ex) throws Exception { return inner.perps(ex); }
        };
        Feeds.Scan spot = new Feeds(fake, () -> now[0]).refresh(new Settings());
        Map<String, String> files = ExportBundle.build("v", now[0], new Settings(), spot, null, false, false, 0, 0, null, null, null);
        boolean found = false;
        for (List<String> r : parse(files.get("status.csv"))) if (r.get(0).equals("source_status") && r.get(1).contains("OKX")) { found = true; assertTrue(r.get(1), r.get(1).contains("HTTP 500, \"bad\"")); assertFalse(r.get(1).contains("\n")); }
        assertTrue(found);
        assertEquals("time_utc,type,detail\n", files.get("events.csv"));
        assertEquals(ExportBundle.SNAPSHOT_HEADER + "\n", files.get("snapshots.csv"));
        assertEquals(ExportBundle.MARKET_HEADER + "\n", files.get("market.csv")); assertNull(ExportBundle.marketRow(now[0], null));
    }
    @Test public void zipRoundTripsAndSnapshotRowsMatchTheirHeader() throws Exception {
        Map<String, String> files = new LinkedHashMap<>(); files.put("a.csv", "x,y\n1,é\n"); files.put("b.txt", "hello");
        Map<String, String> back = unzip(ExportBundle.zip(files));
        assertEquals(files, back); assertEquals(new ArrayList<>(files.keySet()), new ArrayList<>(back.keySet()));
        int width = ExportBundle.SNAPSHOT_HEADER.split(",").length;
        assertEquals(width, parse(ExportBundle.snapshotRow(T, null, null, false, 0) + "\n").get(0).size());
        long[] now = {T + 120_000};
        Feeds.Scan spot = new Feeds(new FeedsTest.Fake(), () -> now[0]).refresh(new Settings());
        PolyFeed.Scan poly = PolyFeedTest.feed(PolyFeedTest.bullish(now[0], 0.60, 500), now, new ArrayList<>(), "").refresh(new Settings(), true);
        List<String> row = parse(ExportBundle.snapshotRow(now[0], spot, poly, true, 2_500_000) + "\n").get(0);
        assertEquals(width, row.size()); assertEquals("1", row.get(14)); assertEquals("2", row.get(15)); assertEquals("2.5", row.get(22));
    }
}
