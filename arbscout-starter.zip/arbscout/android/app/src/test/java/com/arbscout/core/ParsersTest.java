package com.arbscout.core;

import static org.junit.Assert.*;

import com.arbscout.core.Model.*;
import java.util.*;
import org.json.JSONException;
import org.junit.Test;

public class ParsersTest {
    @Test public void binanceBookTickerKeepsOnlyUsableUsdtRows() throws Exception {
        String json = "[{\"symbol\":\"BTCUSDT\",\"bidPrice\":\"60000.10\",\"bidQty\":\"0.5\",\"askPrice\":\"60000.20\",\"askQty\":\"0.25\"},"
                + "{\"symbol\":\"ETHBTC\",\"bidPrice\":\"0.05\",\"bidQty\":\"1\",\"askPrice\":\"0.0501\",\"askQty\":\"1\"},"
                + "{\"symbol\":\"XRPUSDT\",\"bidPrice\":\"0.50\",\"bidQty\":\"10\",\"askPrice\":\"0.49\",\"askQty\":\"10\"},"
                + "{\"symbol\":\"DEADUSDT\",\"bidPrice\":\"0.00000000\",\"bidQty\":\"0\",\"askPrice\":\"0.00000000\",\"askQty\":\"0\"}]";
        List<Quote> q = Parsers.binanceLike("BINANCE", json);
        assertEquals(1, q.size());
        assertEquals("BTC", q.get(0).base); assertEquals("BINANCE", q.get(0).exchange);
        assertEquals(60000.10, q.get(0).bid, 1e-9); assertEquals(0.25, q.get(0).askQty, 1e-12);
    }
    @Test public void binanceErrorObjectBecomesReadableMessage() {
        try { Parsers.binanceLike("BINANCE", "{\"code\":-1003,\"msg\":\"Too many requests\"}"); fail("must throw"); }
        catch (JSONException e) { assertTrue(e.getMessage().contains("Too many requests")); }
    }
    @Test public void bybitSpotSkipsEmptySidesAndReportsErrors() throws Exception {
        String ok = "{\"retCode\":0,\"retMsg\":\"OK\",\"result\":{\"category\":\"spot\",\"list\":["
                + "{\"symbol\":\"BTCUSDT\",\"bid1Price\":\"59999\",\"bid1Size\":\"2\",\"ask1Price\":\"60001\",\"ask1Size\":\"1.5\",\"turnover24h\":\"1\"},"
                + "{\"symbol\":\"NEWUSDT\",\"bid1Price\":\"\",\"bid1Size\":\"\",\"ask1Price\":\"\",\"ask1Size\":\"\"}]}}";
        List<Quote> q = Parsers.bybitSpot(ok);
        assertEquals(1, q.size()); assertEquals("BYBIT", q.get(0).exchange); assertEquals(1.5, q.get(0).askQty, 1e-12);
        try { Parsers.bybitSpot("{\"retCode\":10006,\"retMsg\":\"Too many visits\",\"result\":{}}"); fail("must throw"); }
        catch (JSONException e) { assertTrue(e.getMessage().contains("Too many visits")); }
    }
    @Test public void okxSpotParsesDashedIdsAndReportsErrors() throws Exception {
        String ok = "{\"code\":\"0\",\"msg\":\"\",\"data\":[{\"instId\":\"SOL-USDT\",\"bidPx\":\"150.1\",\"bidSz\":\"20\",\"askPx\":\"150.2\",\"askSz\":\"30\"},"
                + "{\"instId\":\"SOL-USDC\",\"bidPx\":\"150\",\"bidSz\":\"1\",\"askPx\":\"151\",\"askSz\":\"1\"},"
                + "{\"instId\":\"ABC-USDT\",\"bidPx\":\"\",\"bidSz\":\"\",\"askPx\":\"\",\"askSz\":\"\"}]}";
        List<Quote> q = Parsers.okxSpot(ok);
        assertEquals(1, q.size()); assertEquals("SOL", q.get(0).base); assertEquals(30, q.get(0).askQty, 1e-12);
        try { Parsers.okxSpot("{\"code\":\"50011\",\"msg\":\"Rate limit reached\",\"data\":[]}"); fail("must throw"); }
        catch (JSONException e) { assertTrue(e.getMessage().contains("Rate limit")); }
    }
    @Test public void binancePerpsUseIntervalAndVolumeWhenAvailable() throws Exception {
        String premium = "[{\"symbol\":\"BTCUSDT\",\"markPrice\":\"60010.5\",\"lastFundingRate\":\"0.00010000\"},"
                + "{\"symbol\":\"ETHUSDT\",\"markPrice\":\"3000.1\",\"lastFundingRate\":\"-0.00005000\"},"
                + "{\"symbol\":\"BTCUSDT_250627\",\"markPrice\":\"61000\",\"lastFundingRate\":\"\"},"
                + "{\"symbol\":\"SOLUSDT\",\"markPrice\":\"150\",\"lastFundingRate\":\"0.0002\"}]";
        String info = "[{\"symbol\":\"SOLUSDT\",\"fundingIntervalHours\":4}]";
        String t24 = "[{\"symbol\":\"BTCUSDT\",\"quoteVolume\":\"9000000000.5\"},{\"symbol\":\"ETHUSDT\",\"quoteVolume\":\"100\"}]";
        Map<String, Perp> by = new HashMap<>();
        for (Perp p : Parsers.binancePerps(premium, info, t24)) by.put(p.base, p);
        assertEquals(3, by.size());
        assertEquals(8, by.get("BTC").intervalHours, 0); assertEquals(4, by.get("SOL").intervalHours, 0);
        assertEquals(9000000000.5, by.get("BTC").volumeUsdt, 1e-3); assertTrue(Double.isNaN(by.get("SOL").volumeUsdt));
        assertEquals(-0.00005, by.get("ETH").rate, 1e-12);
        assertEquals(3, Parsers.binancePerps(premium, null, null).size());
    }
    @Test public void bybitPerpsReadFundingIntervalAndTurnover() throws Exception {
        String json = "{\"retCode\":0,\"result\":{\"list\":["
                + "{\"symbol\":\"BTCUSDT\",\"markPrice\":\"60000\",\"fundingRate\":\"0.0001\",\"turnover24h\":\"5000000000\",\"fundingIntervalHour\":\"8\"},"
                + "{\"symbol\":\"DOGEUSDT\",\"markPrice\":\"0.1\",\"fundingRate\":\"0.0003\",\"turnover24h\":\"90000000\",\"fundingIntervalHour\":\"4\"},"
                + "{\"symbol\":\"XRPUSDT\",\"markPrice\":\"0.5\",\"fundingRate\":\"-0.0001\",\"turnover24h\":\"1\"},"
                + "{\"symbol\":\"BTC-27JUN25\",\"markPrice\":\"61000\",\"fundingRate\":\"\"},"
                + "{\"symbol\":\"ADAUSDT\",\"markPrice\":\"0.4\",\"fundingRate\":\"0.0001\",\"turnover24h\":\"70000000\"}]}}";
        Map<String, Perp> by = new HashMap<>();
        for (Perp p : Parsers.bybitPerps(json)) by.put(p.base, p);
        assertEquals(4, by.size());
        assertEquals(4, by.get("DOGE").intervalHours, 0); assertEquals(8, by.get("ADA").intervalHours, 0);
        assertEquals(5e9, by.get("BTC").volumeUsdt, 1e-3); assertEquals("BYBIT", by.get("BTC").exchange);
    }
    @Test public void tickerNamingRules() {
        assertEquals("BTC", Parsers.baseOf("BTCUSDT")); assertEquals("BTC", Parsers.baseOf("BTC-USDT")); assertEquals("BTC", Parsers.baseOf("BTC_USDT"));
        assertNull(Parsers.baseOf("USDT")); assertNull(Parsers.baseOf("ETHBTC")); assertNull(Parsers.baseOf("BTCUSDT_250627")); assertNull(Parsers.baseOf(null));
        assertTrue(Double.isNaN(Parsers.num(""))); assertTrue(Double.isNaN(Parsers.num("abc"))); assertTrue(Double.isNaN(Parsers.num("Infinity")));
    }
}
