package com.arbscout.core;

import static org.junit.Assert.*;

import java.util.*;
import org.junit.Test;

public class LedgerTest {
    static Ledger.Position open(Ledger l, String slug, String side, double price, double p) { return l.open(slug, "BTC 5m", side, 1000, 301000, price, 0.0144, 10, p); }

    @Test public void stakeBuysSharesAfterFeeAndWinPaysOneDollarEach() {
        Ledger l = new Ledger(); Ledger.Position p = open(l, "a", "UP", 0.6, 0.8);
        assertEquals(10 / (0.6 * 1.0144), p.shares, 1e-12);
        assertNull(open(l, "a", "DOWN", 0.4, 0.5));           // one position per window
        assertEquals(1, l.settle("a", "UP", 5000)); assertEquals("WON", p.status); assertEquals(p.shares - 10, p.pnl, 1e-12);
        assertEquals(0, l.settle("a", "UP", 6000));             // settling twice changes nothing
    }
    @Test public void losingPositionLosesTheWholeStake() {
        Ledger l = new Ledger(); open(l, "b", "DOWN", 0.3, 0.6);
        assertEquals(0, l.settle("other", "UP", 1)); assertEquals(1, l.settle("b", "UP", 5000));
        assertEquals("LOST", l.find("b").status); assertEquals(-10, l.find("b").pnl, 1e-12);
    }
    @Test public void statsAddUpAndCompareModelToReality() {
        Ledger l = new Ledger(); open(l, "a", "UP", 0.5, 0.9); open(l, "b", "UP", 0.5, 0.7); open(l, "c", "UP", 0.5, 0.6);
        l.settle("a", "UP", 1); l.settle("b", "DOWN", 1);
        Ledger.Stats s = l.stats();
        assertEquals(1, s.open); assertEquals(2, s.settled); assertEquals(1, s.wins); assertEquals(0.5, s.winRate(), 1e-12);
        assertEquals(l.find("a").pnl - 10, s.pnl, 1e-12); assertEquals(20, s.staked, 1e-12); assertEquals(s.pnl / 20, s.roi(), 1e-12); assertEquals(0.8, s.avgModelP, 1e-12);
        assertTrue(Double.isNaN(new Ledger().stats().winRate()));
    }
    @Test public void rejectsNonsenseOrders() {
        Ledger l = new Ledger();
        assertNull(l.open("x", "L", "UP", 0, 1, 0.0, 0, 10, 0.5)); assertNull(l.open("x", "L", "UP", 0, 1, 1.0, 0, 10, 0.5)); assertNull(l.open("x", "L", "UP", 0, 1, 0.5, 0, 0, 0.5));
        assertFalse(l.has("x"));
    }
    @Test public void saveAndReloadKeepsEverythingExactly() {
        Ledger l = new Ledger(); open(l, "a", "UP", 0.61, 0.83); open(l, "b", "DOWN", 0.27, 0.66); open(l, "c", "UP", 0.5, 0.7); l.settle("a", "UP", 4242); l.settle("b", "UP", 4243);
        Ledger back = new Ledger(); back.restore(l.encode());
        assertEquals(l.encode(), back.encode()); assertEquals(l.stats().pnl, back.stats().pnl, 0); assertEquals("OPEN", back.find("c").status);
        back.restore(""); assertEquals(0, back.stats().open + back.stats().settled);
        for (String bad : new String[]{"nonsense", "LEDGER1\na|b|c", "LEDGER1\na|L|UP|1|2|0.5|1|10|0.5|MAYBE|0|0"}) {
            try { new Ledger().restore(bad); fail("must reject " + bad); } catch (IllegalArgumentException expected) { /* ok */ }
        }
    }
    @Test public void viewsAreCopiesAndRecentIsNewestFirst() {
        Ledger l = new Ledger(); open(l, "a", "UP", 0.5, 0.6); open(l, "b", "UP", 0.5, 0.6); open(l, "c", "UP", 0.5, 0.6);
        List<Ledger.Position> r = l.recent(2);
        assertEquals("c", r.get(0).slug); assertEquals("b", r.get(1).slug); assertEquals(2, r.size());
        r.get(0).status = "WON"; assertEquals("OPEN", l.find("c").status);
        Ledger snap = l.copy(); l.clear(); assertEquals(3, snap.stats().open); assertEquals(0, l.stats().open);
    }
}
