package com.arbscout.core;

import static org.junit.Assert.*;

import com.arbscout.core.Model.*;
import java.util.*;
import org.junit.Test;

public class CalcTest {
    static Quote q(String ex, String base, double bid, double bidQty, double ask, double askQty) { return new Quote(ex, base, bid, bidQty, ask, askQty); }

    @Test public void spreadNetIsGrossMinusBothFeesAndSafety() {
        Settings s = new Settings();                       // BINANCE 10, OKX 10, safety 5, trade 500, min depth 100
        List<Quote> l = Arrays.asList(q("BINANCE", "X", 99.98, 10, 100.00, 10), q("OKX", "X", 100.50, 8, 100.52, 8));
        Calc.SpreadReport r = Calc.spreads(l, s);
        assertEquals(2, r.compared); assertEquals(1, r.profitable);
        Calc.Spread best = r.rows.get(0);
        assertEquals("BINANCE", best.buyOn); assertEquals("OKX", best.sellOn);
        assertEquals(50.0, best.grossBps, 1e-9); assertEquals(25.0, best.netBps, 1e-9);
        assertEquals(804.0, best.depthUsdt, 1e-9);          // min(10*100, 8*100.5)
        assertEquals(500.0, best.sizeUsdt, 1e-9); assertEquals(1.25, best.netUsdt, 1e-9);
        Calc.Spread other = r.rows.get(1);                  // the opposite direction loses the spread plus costs
        assertEquals("OKX", other.buyOn); assertTrue(other.netBps < -70);
    }
    @Test public void thinBooksAndImplausibleSpreadsAreHiddenAndCounted() {
        Settings s = new Settings();
        List<Quote> l = new ArrayList<>();
        l.add(q("BINANCE", "THIN", 9.9, 1, 10.0, 1)); l.add(q("OKX", "THIN", 10.2, 1, 10.3, 1));         // 200 bps but ~10 USDT deep
        l.add(q("BINANCE", "FAKE", 0.9, 5000, 1.0, 5000)); l.add(q("OKX", "FAKE", 1.08, 5000, 1.09, 5000)); // 800 bps: beyond the 500 bps cap
        l.add(q("BINANCE", "SOLO", 5, 100, 5.01, 100));                                                    // only one exchange: nothing to compare
        Calc.SpreadReport r = Calc.spreads(l, s);
        assertEquals(1, r.hiddenThin); assertEquals(1, r.hiddenSuspect); assertEquals(0, r.profitable);
        for (Calc.Spread x : r.rows) { assertNotEquals("THIN", x.base); assertNotEquals("FAKE", x.base); assertNotEquals("SOLO", x.base); }
        assertEquals(4, r.compared);
    }
    @Test public void realisticMarketsShowNoProfitAfterFees() {
        Settings s = new Settings();   // two liquid books 2 bps apart: far below 25 bps of costs
        Calc.SpreadReport r = Calc.spreads(Arrays.asList(q("BINANCE", "BTC", 60000, 5, 60001, 5), q("BYBIT", "BTC", 60012, 5, 60013, 5)), s);
        assertEquals(0, r.profitable); assertTrue(r.rows.get(0).netBps < 0);
    }
    @Test public void mexcUsesItsOwnLowerFee() {
        Settings s = new Settings();
        Calc.SpreadReport r = Calc.spreads(Arrays.asList(q("MEXC", "X", 99, 100, 100, 100), q("BINANCE", "X", 100.4, 100, 100.5, 100)), s);
        Calc.Spread buyMexc = r.rows.get(0);   // gross 40 bps - (5 + 10) - 5 safety = 20
        assertEquals("MEXC", buyMexc.buyOn); assertEquals(20.0, buyMexc.netBps, 1e-9);
    }
    @Test public void carryMathAndFilters() {
        Settings s = new Settings();   // fees 10, perp 5, slippage 5, hold 30 days, min volume 20M
        List<Quote> spot = Arrays.asList(q("BINANCE", "BTC", 99.99, 10, 100.01, 10), q("BINANCE", "LOW", 1, 10, 1.001, 10), q("BINANCE", "NEG", 1, 10, 1.001, 10));
        List<Perp> perps = Arrays.asList(
                new Perp("BINANCE", "BTCUSDT", "BTC", 0.0001, 8, 100.2, 1e9),
                new Perp("BINANCE", "LOWUSDT", "LOW", 0.001, 8, 1, 1e6),          // too little volume
                new Perp("BINANCE", "NEGUSDT", "NEG", -0.0001, 8, 1, 1e9),        // negative funding
                new Perp("BINANCE", "1000PEPEUSDT", "1000PEPE", 0.0005, 8, 1, 1e9)); // no matching spot market
        Calc.CarryReport r = Calc.carry(perps, spot, s);
        assertEquals(4, r.considered); assertEquals(1, r.negative); assertEquals(1, r.lowVolume); assertEquals(1, r.noSpot); assertEquals(1, r.rows.size());
        Calc.Carry c = r.rows.get(0);
        assertEquals(10.95, c.aprPct, 1e-9);                    // 0.0001 * 3/day * 365 = 10.95%
        assertEquals(20.0, c.basisBps, 1e-6);                   // mark 100.2 vs mid 100.00
        assertEquals(37.0, c.costBps, 1e-6);                    // 2*10 + 2*5 + 5 + 2 bps spot spread
        assertEquals(0.37 / 0.03, c.breakevenDays, 1e-9);
        assertEquals(0.03 * 30 - 0.37, c.holdNetPct, 1e-9);     // 0.53%
    }
    @Test public void shorterFundingIntervalPaysMoreOften() {
        Settings s = new Settings();
        List<Quote> spot = Arrays.asList(q("BYBIT", "DOGE", 0.0999, 1e6, 0.1001, 1e6));
        Calc.CarryReport r = Calc.carry(Arrays.asList(new Perp("BYBIT", "DOGEUSDT", "DOGE", 0.0001, 4, 0.1, 9e7)), spot, s);
        assertEquals(0.0001 * 6 * 365 * 100, r.rows.get(0).aprPct, 1e-9);
    }
    @Test public void carryRanksByNetOverHolding() {
        Settings s = new Settings();
        List<Quote> spot = Arrays.asList(q("BINANCE", "A", 99.99, 1, 100.01, 1), q("BINANCE", "B", 99.99, 1, 100.01, 1));
        Calc.CarryReport r = Calc.carry(Arrays.asList(new Perp("BINANCE", "AUSDT", "A", 0.0001, 8, 100, 1e9), new Perp("BINANCE", "BUSDT", "B", 0.0003, 8, 100, 1e9)), spot, s);
        assertEquals("B", r.rows.get(0).base);
    }
    @Test public void settingsValidationRejectsNonsense() {
        new Settings().validate();
        Settings s = new Settings(); s.safetyBps = -1;
        try { s.validate(); fail("must reject"); } catch (IllegalArgumentException e) { assertTrue(e.getMessage().contains("Safety")); }
        s = new Settings(); s.refreshSeconds = 0.5;
        try { s.validate(); fail("must reject"); } catch (IllegalArgumentException e) { assertTrue(e.getMessage().contains("Refresh")); }
        s = new Settings(); s.tradeUsdt = Double.NaN;
        try { s.validate(); fail("must reject"); } catch (IllegalArgumentException e) { assertTrue(e.getMessage().contains("Trade size")); }
    }
}
