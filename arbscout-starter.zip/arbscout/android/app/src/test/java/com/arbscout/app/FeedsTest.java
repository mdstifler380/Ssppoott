package com.arbscout.app;

import static org.junit.Assert.*;

import com.arbscout.core.Model.*;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.Test;

public class FeedsTest {
    static final class Fake implements Feeds.Source {
        final Set<String> failing = new HashSet<>(); boolean failPerps; int perpCalls;
        @Override public List<Quote> spot(String ex) throws Exception {
            if (failing.contains(ex)) throw new IOException("HTTP 451 (blocked in your region or by the exchange)");
            return Arrays.asList(new Quote(ex, "X", 100.2, 50, 100.3, 50));
        }
        @Override public List<Perp> perps(String ex) throws Exception {
            perpCalls++;
            if (failPerps) throw new IOException("HTTP 429 (rate limited)");
            return Arrays.asList(new Perp(ex, "XUSDT", "X", 0.0001, 8, 100.25, 1e9));
        }
    }
    static String joined(Feeds.Scan s) { return String.join("\n", s.status); }

    @Test public void allSourcesOkGivesStatusLinesAndBothScans() {
        long[] now = {0}; Feeds f = new Feeds(new Fake(), () -> now[0]);
        Feeds.Scan s = f.refresh(new Settings());
        assertEquals(4, s.spotLive); assertEquals(2, s.perpLive); assertEquals(6, s.status.size());
        assertTrue(joined(s).contains("✓ BINANCE spot") && joined(s).contains("✓ MEXC spot") && joined(s).contains("✓ BYBIT perps"));
        assertEquals(12, s.spreads.compared);          // 4 exchanges -> 12 ordered pairs for the one coin
        assertEquals(2, s.carry.rows.size());          // spot X exists on both perp exchanges
    }
    @Test public void blockedSourceIsReportedAndExcluded() {
        Fake fake = new Fake(); fake.failing.add("OKX"); long[] now = {0};
        Feeds.Scan s = new Feeds(fake, () -> now[0]).refresh(new Settings());
        assertEquals(3, s.spotLive);
        assertTrue(joined(s).contains("✗ OKX spot · HTTP 451") && joined(s).contains("excluded"));
        assertEquals(6, s.spreads.compared);
    }
    @Test public void failedSourceKeepsRecentDataThenDropsIt() {
        Fake fake = new Fake(); long[] now = {0}; Feeds f = new Feeds(fake, () -> now[0]);
        assertEquals(4, f.refresh(new Settings()).spotLive);
        fake.failing.add("OKX"); now[0] = 5_000;
        Feeds.Scan recent = f.refresh(new Settings());
        assertEquals(4, recent.spotLive); assertTrue(joined(recent).contains("using 5 s old data"));
        now[0] = 20_000;
        Feeds.Scan old = f.refresh(new Settings());
        assertEquals(3, old.spotLive); assertTrue(joined(old).contains("excluded"));
    }
    @Test public void fundingIsFetchedOncePerMinuteButAlwaysShown() {
        Fake fake = new Fake(); long[] now = {0}; Feeds f = new Feeds(fake, () -> now[0]);
        f.refresh(new Settings()); assertEquals(2, fake.perpCalls);
        now[0] = 10_000; Feeds.Scan s = f.refresh(new Settings());
        assertEquals(2, fake.perpCalls); assertEquals(2, s.perpLive); assertTrue(joined(s).contains("✓ BINANCE perps"));
        now[0] = 61_000; f.refresh(new Settings()); assertEquals(4, fake.perpCalls);
    }
    @Test public void fundingDataExpiresWhenTheSourceKeepsFailing() {
        Fake fake = new Fake(); long[] now = {0}; Feeds f = new Feeds(fake, () -> now[0]);
        f.refresh(new Settings()); fake.failPerps = true;
        now[0] = 61_000; Feeds.Scan s = f.refresh(new Settings());
        assertTrue(joined(s).contains("✗ BINANCE perps · HTTP 429")); assertEquals(2, s.perpLive);   // 61 s old: still usable
        now[0] = 200_000; assertEquals(0, f.refresh(new Settings()).perpLive);                        // 200 s old: dropped
    }

    @Test public void httpLayerReadsBodiesAndExplainsBlocks() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        for (int code : new int[]{200, 451, 429, 500}) server.createContext("/c" + code, ex -> {
            byte[] body = (code == 200 ? "[{\"ok\":\"héllo\"}]" : "{}").getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(code, body.length); ex.getResponseBody().write(body); ex.close();
        });
        server.start();
        try {
            String base = "http://127.0.0.1:" + server.getAddress().getPort();
            assertEquals("[{\"ok\":\"héllo\"}]", Feeds.get(base + "/c200"));
            assertTrue(message(base + "/c451").contains("HTTP 451") && message(base + "/c451").contains("blocked"));
            assertTrue(message(base + "/c429").contains("rate limited"));
            assertEquals("HTTP 500", message(base + "/c500"));
        } finally { server.stop(0); }
    }
    private static String message(String url) {
        try { Feeds.get(url); } catch (IOException e) { return e.getMessage(); }
        return "no error";
    }
}
