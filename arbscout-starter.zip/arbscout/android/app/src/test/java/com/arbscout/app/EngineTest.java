package com.arbscout.app;

import static org.junit.Assert.*;

import android.content.SharedPreferences;
import com.arbscout.core.Model.*;
import java.io.File;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;

/** The background engine with fake data sources and an in-memory store: scheduling, throttling, reference counting and restart safety. */
public class EngineTest {
    /** A SharedPreferences stand-in that works with the real interface (and the test stub) because it is a dynamic proxy. */
    static SharedPreferences memoryPrefs() {
        final Map<String, Object> m = new ConcurrentHashMap<>();
        final Object editor = Proxy.newProxyInstance(EngineTest.class.getClassLoader(), new Class<?>[]{SharedPreferences.Editor.class}, (p, method, args) -> {
            switch (method.getName()) {
                case "putString": case "putBoolean": case "putInt": m.put((String) args[0], args[1]); return p;
                case "commit": return true;
                case "apply": return null;
                default: return p;
            }
        });
        return (SharedPreferences) Proxy.newProxyInstance(EngineTest.class.getClassLoader(), new Class<?>[]{SharedPreferences.class}, (p, method, args) -> {
            switch (method.getName()) {
                case "getString": case "getBoolean": case "getInt": { Object v = m.get((String) args[0]); return v == null ? args[1] : v; }
                case "edit": return editor;
                default: return null;
            }
        });
    }
    static Feeds.Source spotSource(final CountDownLatch started, final long delayMs) {
        return new Feeds.Source() {
            @Override public List<Quote> spot(String ex) throws Exception {
                if (started != null) started.countDown();
                if (delayMs > 0) Thread.sleep(delayMs);
                return Arrays.asList(new Quote(ex, "X", 100.2, 50, 100.3, 50));
            }
            @Override public List<Perp> perps(String ex) { return Arrays.asList(new Perp(ex, "XUSDT", "X", 0.0001, 8, 100.25, 1e9)); }
        };
    }
    static Engine engine(Feeds.Source spot) throws Exception {
        return new Engine(memoryPrefs(), BackgroundPiecesTest.tempDir(), new Feeds(spot, System::currentTimeMillis),
                new PolyFeed(new PolyFeedTest.Fake(), System::currentTimeMillis, "", text -> { }));
    }
    static final class Count implements Engine.Listener {
        final AtomicInteger spot = new AtomicInteger(), poly = new AtomicInteger();
        @Override public void onSpot(Feeds.Scan scan) { spot.incrementAndGet(); }
        @Override public void onPoly(PolyFeed.Scan scan) { poly.incrementAndGet(); }
    }
    static List<String> events(Engine e) { return Arrays.asList(e.exportFiles(false).get("events.csv").split("\n")); }

    @Test public void scansReachListenersAndTheExportWhileHeld() throws Exception {
        Engine e = engine(spotSource(null, 0)); Count c = new Count(); e.addListener(c); e.setVisible(true); e.acquire("ui");
        long end = System.currentTimeMillis() + 5000;
        while ((c.spot.get() == 0 || c.poly.get() == 0) && System.currentTimeMillis() < end) Thread.sleep(50);
        assertTrue(c.spot.get() >= 1 && c.poly.get() >= 1);
        assertNotNull(e.lastSpot()); assertNotNull(e.lastPoly()); assertTrue(e.notice().title.startsWith("ArbScout · "));
        Map<String, String> files = e.exportFiles(true);
        assertTrue(files.get("status.csv").contains("background_service_running,1")); assertTrue(files.containsKey("paper_trades.csv"));
        e.release("ui");
    }
    @Test public void withTheScreenOffTheBigDownloadsHappenFarLessOften() throws Exception {
        Engine open = engine(spotSource(null, 0)), closed = engine(spotSource(null, 0));
        Settings s = new Settings(); s.spotRefreshSeconds = 5; open.applySettings(s); closed.applySettings(s);
        Count a = new Count(), b = new Count(); open.addListener(a); closed.addListener(b);
        open.setVisible(true); closed.setVisible(false); open.acquire("ui"); closed.acquire("service");
        Thread.sleep(6300);
        open.release("ui"); closed.release("service");
        assertTrue("screen on: " + a.spot.get(), a.spot.get() >= 2);
        assertEquals(1, b.spot.get());                                             // screen off: one scan, then the 2-minute rule holds the next ones back
        assertTrue(b.poly.get() >= 2);                                             // the BTC windows keep their own pace
    }
    @Test public void restartingTheScheduleInTheMiddleOfAScanDoesNotLogAFalseOutage() throws Exception {
        CountDownLatch started = new CountDownLatch(1);
        Engine e = engine(spotSource(started, 1200)); e.setVisible(true); e.acquire("ui");
        assertTrue(started.await(5, TimeUnit.SECONDS));
        e.applySettings(new Settings());                                           // interrupts the waiting scan, as saving settings or reopening the app does
        Thread.sleep(3500);
        for (String line : events(e)) { assertFalse(line, line.contains("SOURCE_DOWN")); assertFalse(line, line.toLowerCase(Locale.US).contains("interrupt")); }
        e.release("ui");
    }
    @Test public void runsWhileAnyoneHoldsItAndStopsWhenTheLastOneLetsGo() throws Exception {
        Engine e = engine(spotSource(null, 0)); Settings s = new Settings(); s.refreshSeconds = 2; e.applySettings(s);
        Count c = new Count(); e.addListener(c); e.acquire("ui"); e.acquire("service");
        e.release("ui");
        int before = c.poly.get(); long end = System.currentTimeMillis() + 4000;
        while (c.poly.get() < before + 2 && System.currentTimeMillis() < end) Thread.sleep(50);
        assertTrue("service alone keeps it running", c.poly.get() >= before + 2);
        e.release("service"); Thread.sleep(400);
        int stopped = c.poly.get(); Thread.sleep(2600);
        assertEquals(stopped, c.poly.get());
        assertEquals(0, e.startedAt());
        String log = events(e).toString();
        assertTrue(log.contains("SCAN_START") && log.contains("SCAN_STOP"));         // session boundaries are in the event log
        assertEquals(1, log.split("SCAN_START", -1).length - 1);                      // a second holder does not start a second session
    }
    @Test public void everyAccountsTradesAreLoggedAndTheExportCarriesTheMarketBackdrop() throws Exception {
        long[] clock = {PolyFeedTest.T + 120_000}; PolyFeedTest.Fake fake = PolyFeedTest.bullish(clock[0], 0.60, 500);
        PolyFeed pf = new PolyFeed(fake, () -> clock[0], "", text -> { }); SharedPreferences prefs = memoryPrefs(); Engine.addStandardRivals(pf, prefs);
        Engine e = new Engine(prefs, BackgroundPiecesTest.tempDir(), new Feeds(spotSource(null, 0), System::currentTimeMillis), pf);
        Settings s = new Settings(); s.refreshSeconds = 2; e.applySettings(s);
        Count c = new Count(); e.addListener(c); e.setVisible(true); e.acquire("ui");                              // paper is off: the first scan only learns the (empty) accounts
        long end = System.currentTimeMillis() + 5000; while (c.poly.get() == 0 && System.currentTimeMillis() < end) Thread.sleep(50);
        e.setPaperOn(true);
        end = System.currentTimeMillis() + 7000;
        while (!events(e).toString().contains("[C] BTC") && System.currentTimeMillis() < end) Thread.sleep(100);
        e.release("ui");
        String log = String.join("\n", events(e));
        assertTrue(log, log.contains("PAPER_OPEN,BTC 5m UP at 0.600"));                                            // account A: no prefix
        assertTrue(log.contains("PAPER_OPEN,[B] BTC 5m UP") && log.contains("PAPER_OPEN,[C] BTC 5m UP"));
        Map<String, String> files = e.exportFiles(false);
        assertTrue(files.get("status.csv").contains("paper_C_open,2")); assertTrue(files.get("paper_trades.csv").split("\n")[0].startsWith("strategy,slug"));
    }
    @Test public void settingsChangesAreSavedAndPaperTradingIsRemembered() throws Exception {
        SharedPreferences prefs = memoryPrefs();
        Engine e = new Engine(prefs, BackgroundPiecesTest.tempDir(), new Feeds(spotSource(null, 0), System::currentTimeMillis), new PolyFeed(new PolyFeedTest.Fake(), System::currentTimeMillis, "", text -> { }));
        Settings s = new Settings(); s.paperStakeUsdt = 25; s.spotRefreshSeconds = 40; e.applySettings(s); e.setPaperOn(true); e.setBackgroundWanted(true);
        Engine again = new Engine(prefs, BackgroundPiecesTest.tempDir(), new Feeds(spotSource(null, 0), System::currentTimeMillis), new PolyFeed(new PolyFeedTest.Fake(), System::currentTimeMillis, "", text -> { }));
        assertEquals(25, again.settings().paperStakeUsdt, 0); assertEquals(40, again.settings().spotRefreshSeconds, 0); assertTrue(again.paperOn()); assertTrue(again.backgroundWanted());
        assertTrue(events(e).toString().contains("PAPER_TRADING_ON") && events(e).toString().contains("SETTINGS_SAVED"));
    }
}
