package com.arbscout.core;

import static org.junit.Assert.*;

import com.arbscout.core.Model.Settings;
import com.arbscout.core.Poly.*;
import java.util.*;
import org.json.JSONException;
import org.junit.Test;

public class PolyTest {
    // ---- parsers ----
    @Test public void marketReadsStringifiedArraysAndFindsOutcomes() throws Exception {
        Market m = Poly.parseMarket("[{\"slug\":\"btc-updown-5m-1800000000\",\"question\":\"Bitcoin Up or Down\",\"outcomes\":\"[\\\"Up\\\", \\\"Down\\\"]\","
                + "\"clobTokenIds\":\"[\\\"111\\\", \\\"222\\\"]\",\"outcomePrices\":\"[\\\"0.5\\\", \\\"0.5\\\"]\",\"closed\":false}]");
        assertEquals("btc-updown-5m-1800000000", m.slug); assertEquals(Arrays.asList("111", "222"), m.tokens);
        assertEquals(0, m.indexOf("up")); assertEquals(1, m.indexOf("DOWN")); assertEquals(-1, m.indexOf("Maybe"));
        assertFalse(m.closed); assertEquals(-1, m.winner);
    }
    @Test public void resolvedMarketReportsItsWinnerOnlyOnceClosed() throws Exception {
        String base = "\"slug\":\"s\",\"outcomes\":[\"Up\",\"Down\"],\"clobTokenIds\":[\"1\",\"2\"],\"outcomePrices\":[\"0\",\"1\"]";   // native arrays also accepted
        assertEquals(1, Poly.parseMarket("[{" + base + ",\"closed\":true}]").winner);
        assertEquals(-1, Poly.parseMarket("[{" + base + ",\"closed\":false}]").winner);
        assertEquals(-1, Poly.parseMarket("[{\"slug\":\"s\",\"outcomes\":\"[\\\"Up\\\",\\\"Down\\\"]\",\"clobTokenIds\":\"[\\\"1\\\",\\\"2\\\"]\",\"outcomePrices\":\"[\\\"0.6\\\",\\\"0.4\\\"]\",\"closed\":true}]").winner);
    }
    @Test public void marketEdgeCases() throws Exception {
        assertNull(Poly.parseMarket("[]"));
        try { Poly.parseMarket("[{\"slug\":\"s\",\"outcomes\":\"[\\\"Up\\\"]\",\"clobTokenIds\":\"[]\"}]"); fail("mismatch"); } catch (JSONException e) { assertTrue(e.getMessage().contains("do not match")); }
        try { Poly.parseMarket("{\"error\":\"rate limited\"}"); fail("error"); } catch (JSONException e) { assertTrue(e.getMessage().contains("rate limited")); }
    }
    @Test public void bookFindsBestPricesWhateverTheOrder() throws Exception {
        Book b = Poly.parseBook("{\"bids\":[{\"price\":\"0.45\",\"size\":\"10\"},{\"price\":\"0.48\",\"size\":\"5\"},{\"price\":\"0.48\",\"size\":\"7\"},{\"price\":\"0.40\",\"size\":\"100\"}],"
                + "\"asks\":[{\"price\":\"0.60\",\"size\":\"3\"},{\"price\":\"0.52\",\"size\":\"20\"},{\"price\":\"0.55\",\"size\":\"1\"},{\"price\":\"0.50\",\"size\":\"0\"}]}");
        assertEquals(0.48, b.bestBid, 1e-12); assertEquals(12, b.bidSize, 1e-12); assertEquals(0.52, b.bestAsk, 1e-12); assertEquals(20, b.askSize, 1e-12);
        Book empty = Poly.parseBook("{\"bids\":[],\"asks\":[]}");
        assertTrue(Double.isNaN(empty.bestAsk) && Double.isNaN(empty.bestBid));
        try { Poly.parseBook("{\"error\":\"No orderbook exists\"}"); fail("error"); } catch (JSONException e) { assertTrue(e.getMessage().contains("No orderbook")); }
    }
    @Test public void eventsKeepOpenOutcomesAndFlagExclusiveOnes() throws Exception {
        String json = "[{\"title\":\"Who wins?\",\"slug\":\"who\",\"negRisk\":true,\"markets\":["
                + "{\"groupItemTitle\":\"A\",\"bestBid\":0.28,\"bestAsk\":0.30,\"active\":true,\"closed\":false},"
                + "{\"groupItemTitle\":\"B\",\"bestBid\":\"0.30\",\"bestAsk\":\"0.35\",\"feeType\":\"crypto_fees\"},"
                + "{\"groupItemTitle\":\"C\",\"bestAsk\":0.99,\"closed\":true},"
                + "{\"groupItemTitle\":\"D\",\"bestAsk\":null,\"bestBid\":null}]},"
                + "{\"title\":\"Single\",\"slug\":\"one\",\"markets\":[{\"bestAsk\":0.5}]},"
                + "{\"title\":\"Ladder\",\"slug\":\"ladder\",\"markets\":[{\"question\":\"By June?\",\"bestAsk\":0.4},{\"question\":\"By Dec?\",\"bestAsk\":0.6}]}]";
        List<Event> ev = Poly.parseEvents(json);
        assertEquals(2, ev.size());                       // the single-market event is dropped
        Event who = ev.get(0);
        assertTrue(who.negRisk); assertEquals(3, who.legs.size());   // closed outcome C removed
        assertEquals("A", who.legs.get(0).name); assertEquals(0.30, who.legs.get(0).ask, 1e-12); assertFalse(who.legs.get(0).fee);
        assertEquals(0.35, who.legs.get(1).ask, 1e-12); assertTrue(who.legs.get(1).fee);
        assertTrue(Double.isNaN(who.legs.get(2).ask));
        assertFalse(ev.get(1).negRisk);
    }
    @Test public void eventsWithPossiblyIncompleteOutcomeListsAreFlagged() throws Exception {
        StringBuilder many = new StringBuilder();
        for (int i = 0; i < 31; i++) many.append(i > 0 ? "," : "").append("{\"groupItemTitle\":\"P").append(i).append("\",\"bestAsk\":0.02}");
        String json = "[{\"title\":\"Fine\",\"negRisk\":true,\"markets\":[{\"bestAsk\":0.5},{\"bestAsk\":0.5},{\"bestAsk\":0.1,\"closed\":true}]},"
                + "{\"title\":\"Pending\",\"negRisk\":true,\"markets\":[{\"bestAsk\":0.5},{\"bestAsk\":0.4,\"active\":false}]},"
                + "{\"title\":\"NotAccepting\",\"negRisk\":true,\"markets\":[{\"bestAsk\":0.5},{\"bestAsk\":0.4,\"acceptingOrders\":false}]},"
                + "{\"title\":\"Augmented\",\"negRisk\":true,\"negRiskAugmented\":true,\"markets\":[{\"bestAsk\":0.5},{\"bestAsk\":0.4}]},"
                + "{\"title\":\"Huge\",\"negRisk\":true,\"markets\":[" + many + "]}]";
        List<Event> ev = Poly.parseEvents(json);
        assertNull(ev.get(0).problem);                                              // a closed (already lost) outcome is fine
        assertTrue(ev.get(1).problem.contains("not open")); assertTrue(ev.get(2).problem.contains("not open"));
        assertTrue(ev.get(3).problem.contains("added later")); assertTrue(ev.get(4).problem.contains("too many"));
    }
    @Test public void marketResolvedStatusCountsEvenIfNotClosed() throws Exception {
        String base = "\"slug\":\"s\",\"outcomes\":[\"Up\",\"Down\"],\"clobTokenIds\":[\"1\",\"2\"],\"outcomePrices\":[\"0\",\"1\"],\"closed\":false";
        Market done = Poly.parseMarket("[{" + base + ",\"umaResolutionStatus\":\"resolved\"}]");
        assertEquals(1, done.winner); assertEquals("resolved", done.uma); assertEquals(Arrays.asList("0", "1"), done.prices);
        assertEquals(-1, Poly.parseMarket("[{" + base + ",\"umaResolutionStatus\":\"proposed\"}]").winner);
    }
    @Test public void outcomeFromCandlesComparesWindowStartAndEnd() {
        long t0 = 1_800_000_000_000L; double[] closes = {100, 101, 102, 101, 100, 99, 98, 99, 100, 101, 102, 103};
        List<Candle> c = candles(closes, t0);
        long start = t0 + 2 * 60000L, end = t0 + 7 * 60000L;      // start = open of candle 2 (= close[1] = 101); end = close of candle 6 (= 98)
        assertEquals("DOWN", PolyCalc.outcome(c, start, end));
        assertEquals("UP", PolyCalc.outcome(c, t0 + 6 * 60000L, t0 + 12 * 60000L));      // 99 -> 103
        assertNull(PolyCalc.outcome(c, start, t0 + 90 * 60000L));                        // window end not covered
        assertNull(PolyCalc.outcome(c, t0 - 60000L, end));
    }
    @Test public void candlesParseOpenAndClose() throws Exception {
        List<Candle> c = Poly.parseCandles("[[1800000000000,\"100.0\",\"101\",\"99\",\"100.5\",\"10\"],[1800000060000,\"100.5\",\"101\",\"99\",\"100.7\",\"10\"],[1800000120000,\"0\",\"0\",\"0\",\"0\",\"0\"]]");
        assertEquals(2, c.size()); assertEquals(1800000060000L, c.get(1).openTimeMs); assertEquals(100.0, c.get(0).open, 1e-12); assertEquals(100.7, c.get(1).close, 1e-12);
    }

    // ---- math ----
    @Test public void feeShapePeaksAtFiftyCents() {
        assertEquals(0.0156, PolyCalc.feeRate(0.5, 1.56), 1e-12);
        assertEquals(0.0156 * 0.4096, PolyCalc.feeRate(0.8, 1.56), 1e-12);
        assertEquals(PolyCalc.feeRate(0.2, 1.56), PolyCalc.feeRate(0.8, 1.56), 1e-12);
        assertEquals(0, PolyCalc.feeRate(0.5, 0), 0);
    }
    @Test public void normalCdfMatchesKnownValues() {
        assertEquals(0.5, PolyCalc.normalCdf(0), 1e-7); assertEquals(0.8413447, PolyCalc.normalCdf(1), 1e-6);
        assertEquals(0.0249979, PolyCalc.normalCdf(-1.96), 1e-6); assertEquals(1.0, PolyCalc.normalCdf(8), 1e-9);
    }
    static List<Candle> candles(double[] closes, long firstOpenMs) {
        List<Candle> out = new ArrayList<>();
        for (int i = 0; i < closes.length; i++) out.add(new Candle(firstOpenMs + i * 60000L, i == 0 ? closes[0] : closes[i - 1], closes[i]));
        return out;
    }
    @Test public void fairProbabilityUsesWindowStartVolatilityAndTimeLeft() {
        long t0 = 1_800_000_000_000L; double[] closes = {100, 100.1, 100, 100.1, 100, 100.1, 100, 100.1, 100.2, 100.3, 100.4, 100.5};
        List<Candle> c = candles(closes, t0);
        long start = t0 + 6 * 60000L, now = t0 + 11 * 60000L + 30_000L, end = now + 90_000L;   // 30 s into the last candle; window ends 1.5 min later
        PolyCalc.Fair f = PolyCalc.fair(c, start, end, now);
        double sum = 0; for (int i = 1; i < closes.length; i++) { double r = Math.log(closes[i] / closes[i - 1]); sum += r * r; }
        double sigma = Math.sqrt(sum / (closes.length - 1)), minutes = (end - now) / 60000.0;
        assertEquals(100.1, f.start, 1e-12);                                  // open of the candle that starts the window = close of the candle before it (closes[5])
        assertEquals(100.5, f.now, 1e-12); assertEquals(sigma, f.sigmaPerMin, 1e-12); assertEquals(1.5, f.minutesLeft, 1e-12);
        double expected = Math.min(0.98, PolyCalc.normalCdf(Math.log(100.5 / 100.1) / (sigma * Math.sqrt(minutes))));
        assertEquals(expected, f.pUp, 1e-12); assertTrue(f.pUp > 0.5);
    }
    @Test public void fairProbabilityIsClampedAndNeedsData() {
        long t0 = 1_800_000_000_000L; double[] up = new double[12], down = new double[12];
        for (int i = 0; i < 12; i++) { up[i] = 100 + (i > 6 ? 10 : 0) + (i % 2) * 0.01; down[i] = 100 - (i > 6 ? 10 : 0) + (i % 2) * 0.01; }
        long start = t0 + 6 * 60000L, end = start + 300_000L, now = t0 + 11 * 60000L;
        assertEquals(0.98, PolyCalc.fair(candles(up, t0), start, end, now).pUp, 0);
        assertEquals(0.02, PolyCalc.fair(candles(down, t0), start, end, now).pUp, 0);
        assertNull(PolyCalc.fair(candles(up, t0), start + 7 * 3600_000L, end, now));         // window start not among the candles
        assertNull(PolyCalc.fair(candles(new double[]{100, 101, 102}, t0), start, end, now)); // too few candles
    }
    @Test public void bestSideSubtractsFeeFromModelProbability() {
        Book up = new Book(0.58, 10, 0.60, 100), down = new Book(0.28, 10, 0.30, 50);
        PolyCalc.Edge e = PolyCalc.best(0.8, up, down, 1.56);
        assertEquals("UP", e.side); assertEquals(0.8 - 0.6 * (1 + PolyCalc.feeRate(0.6, 1.56)), e.edge, 1e-12); assertEquals(0.191373824, e.edge, 1e-9);
        assertTrue(e.evPerDollar() > 0.3);
        assertEquals("DOWN", PolyCalc.best(0.1, up, down, 1.56).side);                       // model says Down is likely: 0.9 vs ask 0.30
        assertEquals("DOWN", PolyCalc.best(0.8, new Book(Double.NaN, Double.NaN, Double.NaN, Double.NaN), down, 1.56).side);
        assertNull(PolyCalc.best(0.8, null, null, 1.56));
    }
    @Test public void priceRangeKeepsLongshotsAndNearCertaintiesOutOfTheComparison() {
        Book cheapUp = new Book(0.04, 10, 0.06, 100), downBook = new Book(0.40, 10, 0.45, 100), sure = new Book(0.96, 10, 0.97, 100), longshot = new Book(0.01, 10, 0.03, 100);
        assertEquals("UP", PolyCalc.best(0.98, cheapUp, downBook, 1.56).side);                   // no range: the 6-cent "edge" wins
        PolyCalc.Edge e = PolyCalc.best(0.98, cheapUp, downBook, 1.56, 0.15, 0.85);
        assertEquals("DOWN", e.side); assertTrue(e.edge < 0);                                    // only the 45-cent side is considered
        assertNull(PolyCalc.best(0.98, sure, longshot, 1.56, 0.15, 0.85));                       // both sides out of range
        assertNotNull(PolyCalc.best(0.98, new Book(0.14, 1, 0.15, 1), null, 1.56, 0.15, 0.85)); // the limits themselves are allowed
    }
    @Test public void buyEveryOutcomeNeedsTheAsksToSumBelowOne() {
        Settings s = new Settings();
        Event cheap = ev("Cheap", true, leg("A", 0.32, false), leg("B", 0.32, false), leg("C", 0.32, false));
        Event dear = ev("Dear", true, leg("A", 0.30, false), leg("B", 0.35, false), leg("C", 0.40, false));
        Event gap = ev("Gap", true, leg("A", 0.30, false), leg("B", Double.NaN, false));
        Event ladder = ev("Ladder", false, leg("A", 0.1, false), leg("B", 0.1, false));
        Event bad = unsafe("Placeholders", leg("A", 0.20, false), leg("B", 0.30, false));                       // list may be missing outcomes
        Event tooGood = ev("TooGood", true, leg("A", 0.30, false), leg("B", 0.30, false), leg("C", 0.30, false));   // 10 cents per dollar: not believable
        PolyCalc.SetReport r = PolyCalc.sets(Arrays.asList(dear, ladder, cheap, gap, bad, tooGood), s);
        assertEquals(6, r.events); assertEquals(5, r.exclusive); assertEquals(1, r.incomplete); assertEquals(1, r.unsafe); assertEquals(1, r.suspect);
        assertEquals(1, r.profitable); assertEquals(2, r.rows.size());
        assertEquals("Cheap", r.rows.get(0).title); assertEquals(0.04, r.rows.get(0).net, 1e-12); assertEquals(-0.05, r.rows.get(1).net, 1e-12);
        s.polyOtherFeePct = 1.0;
        assertEquals(1 - 0.96 * 1.01, PolyCalc.sets(Arrays.asList(cheap), s).rows.get(0).net, 1e-12);
        Event fee = ev("Fee", true, leg("A", 0.5, true), leg("B", 0.45, false));   // 0.5 + 0.45 = 0.95
        assertEquals(1 - (0.5 * (1 + 0.0156) + 0.45 * 1.01), PolyCalc.sets(Arrays.asList(fee), s).rows.get(0).net, 1e-12);
    }
    static Leg leg(String n, double ask, boolean fee) { return new Leg(n, ask, ask - 0.02, fee); }
    static Event ev(String title, boolean neg, Leg... legs) { return new Event(title, title.toLowerCase(), neg, Arrays.asList(legs), null); }
    static Event unsafe(String title, Leg... legs) { return new Event(title, title.toLowerCase(), true, Arrays.asList(legs), "some outcomes are not open for trading"); }
}
