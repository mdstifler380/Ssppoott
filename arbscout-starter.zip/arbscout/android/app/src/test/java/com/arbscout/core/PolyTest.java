package com.arbscout.core;

import static org.junit.Assert.*;

import com.arbscout.core.Model.Settings;
import com.arbscout.core.Poly.*;
import java.util.*;
import org.json.JSONException;
import org.junit.Test;

public class PolyTest {
    // ---- parsers ----
    @Test public void marketReadsStringifiedArraysAndFindsOutcomes() throws Exception {
        Market m = Poly.parseMarket("[{\"slug\":\"btc-updown-5m-1800000000\",\"question\":\"Bitcoin Up or Down\",\"outcomes\":\"[\\\"Up\\\", \\\"Down\\\"]\","
                + "\"clobTokenIds\":\"[\\\"111\\\", \\\"222\\\"]\",\"outcomePrices\":\"[\\\"0.5\\\", \\\"0.5\\\"]\",\"closed\":false}]");
        assertEquals("btc-updown-5m-1800000000", m.slug); assertEquals(Arrays.asList("111", "222"), m.tokens);
        assertEquals(0, m.indexOf("up")); assertEquals(1, m.indexOf("DOWN")); assertEquals(-1, m.indexOf("Maybe"));
        assertFalse(m.closed); assertEquals(-1, m.winner);
    }
    @Test public void resolvedMarketReportsItsWinnerOnlyOnceClosed() throws Exception {
        String base = "\"slug\":\"s\",\"outcomes\":[\"Up\",\"Down\"],\"clobTokenIds\":[\"1\",\"2\"],\"outcomePrices\":[\"0\",\"1\"]";   // native arrays also accepted
        assertEquals(1, Poly.parseMarket("[{" + base + ",\"closed\":true}]").winner);
        assertEquals(-1, Poly.parseMarket("[{" + base + ",\"closed\":false}]").winner);
        assertEquals(-1, Poly.parseMarket("[{\"slug\":\"s\",\"outcomes\":\"[\\\"Up\\\",\\\"Down\\\"]\",\"clobTokenIds\":\"[\\\"1\\\",\\\"2\\\"]\",\"outcomePrices\":\"[\\\"0.6\\\",\\\"0.4\\\"]\",\"closed\":true}]").winner);
    }
    @Test public void marketEdgeCases() throws Exception {
        assertNull(Poly.parseMarket("[]"));
        try { Poly.parseMarket("[{\"slug\":\"s\",\"outcomes\":\"[\\\"Up\\\"]\",\"clobTokenIds\":\"[]\"}]"); fail("mismatch"); } catch (JSONException e) { assertTrue(e.getMessage().contains("do not match")); }
        try { Poly.parseMarket("{\"error\":\"rate limited\"}"); fail("error"); } catch (JSONException e) { assertTrue(e.getMessage().contains("rate limited")); }
    }
    @Test public void bookFindsBestPricesWhateverTheOrder() throws Exception {
        Book b = Poly.parseBook("{\"bids\":[{\"price\":\"0.45\",\"size\":\"10\"},{\"price\":\"0.48\",\"size\":\"5\"},{\"price\":\"0.48\",\"size\":\"7\"},{\"price\":\"0.40\",\"size\":\"100\"}],"
                + "\"asks\":[{\"price\":\"0.60\",\"size\":\"3\"},{\"price\":\"0.52\",\"size\":\"20\"},{\"price\":\"0.55\",\"size\":\"1\"},{\"price\":\"0.50\",\"size\":\"0\"}]}");
        assertEquals(0.48, b.bestBid, 1e-12); assertEquals(12, b.bidSize, 1e-12); assertEquals(0.52, b.bestAsk, 1e-12); assertEquals(20, b.askSize, 1e-12);
        Book empty = Poly.parseBook("{\"bids\":[],\"asks\":[]}");
        assertTrue(Double.isNaN(empty.bestAsk) && Double.isNaN(empty.bestBid));
        try { Poly.parseBook("{\"error\":\"No orderbook exists\"}"); fail("error"); } catch (JSONException e) { assertTrue(e.getMessage().contains("No orderbook")); }
    }
    @Test public void eventsKeepOpenOutcomesAndFlagExclusiveOnes() throws Exception {
        String json = "[{\"title\":\"Who wins?\",\"slug\":\"who\",\"negRisk\":true,\"markets\":["
                + "{\"groupItemTitle\":\"A\",\"bestBid\":0.28,\"bestAsk\":0.30,\"active\":true,\"closed\":false},"
                + "{\"groupItemTitle\":\"B\",\"bestBid\":\"0.30\",\"bestAsk\":\"0.35\",\"feeType\":\"crypto_fees\"},"
                + "{\"groupItemTitle\":\"C\",\"bestAsk\":0.99,\"closed\":true},"
                + "{\"groupItemTitle\":\"D\",\"bestAsk\":null,\"bestBid\":null}]},"
                + "{\"title\":\"Single\",\"slug\":\"one\",\"markets\":[{\"bestAsk\":0.5}]},"
                + "{\"title\":\"Ladder\",\"slug\":\"ladder\",\"markets\":[{\"question\":\"By June?\",\"bestAsk\":0.4},{\"question\":\"By Dec?\",\"bestAsk\":0.6}]}]";
        List<Event> ev = Poly.parseEvents(json);
        assertEquals(2, ev.size());                       // the single-market event is dropped
        Event who = ev.get(0);
        assertTrue(who.negRisk); assertEquals(3, who.legs.size());   // closed outcome C removed
        assertEquals("A", who.legs.get(0).name); assertEquals(0.30, who.legs.get(0).ask, 1e-12); assertFalse(who.legs.get(0).fee);
        assertEquals(0.35, who.legs.get(1).ask, 1e-12); assertTrue(who.legs.get(1).fee);
        assertTrue(Double.isNaN(who.legs.get(2).ask));
        assertFalse(ev.get(1).negRisk);
    }
    @Test public void candlesParseOpenAndClose() throws Exception {
        List<Candle> c = Poly.parseCandles("[[1800000000000,\"100.0\",\"101\",\"99\",\"100.5\",\"10\"],[1800000060000,\"100.5\",\"101\",\"99\",\"100.7\",\"10\"],[1800000120000,\"0\",\"0\",\"0\",\"0\",\"0\"]]");
        assertEquals(2, c.size()); assertEquals(1800000060000L, c.get(1).openTimeMs); assertEquals(100.0, c.get(0).open, 1e-12); assertEquals(100.7, c.get(1).close, 1e-12);
    }

    // ---- math ----
    @Test public void feeShapePeaksAtFiftyCents() {
        assertEquals(0.0156, PolyCalc.feeRate(0.5, 1.56), 1e-12);
        assertEquals(0.0156 * 0.4096, PolyCalc.feeRate(0.8, 1.56), 1e-12);
        assertEquals(PolyCalc.feeRate(0.2, 1.56), PolyCalc.feeRate(0.8, 1.56), 1e-12);
        assertEquals(0, PolyCalc.feeRate(0.5, 0), 0);
    }
    @Test public void normalCdfMatchesKnownValues() {
        assertEquals(0.5, PolyCalc.normalCdf(0), 1e-7); assertEquals(0.8413447, PolyCalc.normalCdf(1), 1e-6);
        assertEquals(0.0249979, PolyCalc.normalCdf(-1.96), 1e-6); assertEquals(1.0, PolyCalc.normalCdf(8), 1e-9);
    }
    static List<Candle> candles(double[] closes, long firstOpenMs) {
        List<Candle> out = new ArrayList<>();
        for (int i = 0; i < closes.length; i++) out.add(new Candle(firstOpenMs + i * 60000L, i == 0 ? closes[0] : closes[i - 1], closes[i]));
        return out;
    }
    @Test public void fairProbabilityUsesWindowStartVolatilityAndTimeLeft() {
        long t0 = 1_800_000_000_000L; double[] closes = {100, 100.1, 100, 100.1, 100, 100.1, 100, 100.1, 100.2, 100.3, 100.4, 100.5};
        List<Candle> c = candles(closes, t0);
        long start = t0 + 6 * 60000L, now = t0 + 11 * 60000L + 30_000L, end = now + 90_000L;   // 30 s into the last candle; window ends 1.5 min later
        PolyCalc.Fair f = PolyCalc.fair(c, start, end, now);
        double sum = 0; for (int i = 1; i < closes.length; i++) { double r = Math.log(closes[i] / closes[i - 1]); sum += r * r; }
        double sigma = Math.sqrt(sum / (closes.length - 1)), minutes = (end - now) / 60000.0;
        assertEquals(100.1, f.start, 1e-12);                                  // open of the candle that starts the window = close of the candle before it (closes[5])
        assertEquals(100.5, f.now, 1e-12); assertEquals(sigma, f.sigmaPerMin, 1e-12); assertEquals(1.5, f.minutesLeft, 1e-12);
        double expected = Math.min(0.98, PolyCalc.normalCdf(Math.log(100.5 / 100.1) / (sigma * Math.sqrt(minutes))));
        assertEquals(expected, f.pUp, 1e-12); assertTrue(f.pUp > 0.5);
    }
    @Test public void fairProbabilityIsClampedAndNeedsData() {
        long t0 = 1_800_000_000_000L; double[] up = new double[12], down = new double[12];
        for (int i = 0; i < 12; i++) { up[i] = 100 + (i > 6 ? 10 : 0) + (i % 2) * 0.01; down[i] = 100 - (i > 6 ? 10 : 0) + (i % 2) * 0.01; }
        long start = t0 + 6 * 60000L, end = start + 300_000L, now = t0 + 11 * 60000L;
        assertEquals(0.98, PolyCalc.fair(candles(up, t0), start, end, now).pUp, 0);
        assertEquals(0.02, PolyCalc.fair(candles(down, t0), start, end, now).pUp, 0);
        assertNull(PolyCalc.fair(candles(up, t0), start + 7 * 3600_000L, end, now));         // window start not among the candles
        assertNull(PolyCalc.fair(candles(new double[]{100, 101, 102}, t0), start, end, now)); // too few candles
    }
    @Test public void bestSideSubtractsFeeFromModelProbability() {
        Book up = new Book(0.58, 10, 0.60, 100), down = new Book(0.28, 10, 0.30, 50);
        PolyCalc.Edge e = PolyCalc.best(0.8, up, down, 1.56);
        assertEquals("UP", e.side); assertEquals(0.8 - 0.6 * (1 + PolyCalc.feeRate(0.6, 1.56)), e.edge, 1e-12); assertEquals(0.191373824, e.edge, 1e-9);
        assertTrue(e.evPerDollar() > 0.3);
        assertEquals("DOWN", PolyCalc.best(0.1, up, down, 1.56).side);                       // model says Down is likely: 0.9 vs ask 0.30
        assertEquals("DOWN", PolyCalc.best(0.8, new Book(Double.NaN, Double.NaN, Double.NaN, Double.NaN), down, 1.56).side);
        assertNull(PolyCalc.best(0.8, null, null, 1.56));
    }
    @Test public void buyEveryOutcomeNeedsTheAsksToSumBelowOne() {
        Settings s = new Settings();
        Event cheap = ev("Cheap", true, leg("A", 0.30, false), leg("B", 0.30, false), leg("C", 0.30, false));
        Event dear = ev("Dear", true, leg("A", 0.30, false), leg("B", 0.35, false), leg("C", 0.40, false));
        Event gap = ev("Gap", true, leg("A", 0.30, false), leg("B", Double.NaN, false));
        Event ladder = ev("Ladder", false, leg("A", 0.1, false), leg("B", 0.1, false));
        PolyCalc.SetReport r = PolyCalc.sets(Arrays.asList(dear, ladder, cheap, gap), s);
        assertEquals(4, r.events); assertEquals(3, r.exclusive); assertEquals(1, r.incomplete); assertEquals(1, r.profitable); assertEquals(2, r.rows.size());
        assertEquals("Cheap", r.rows.get(0).title); assertEquals(0.1, r.rows.get(0).net, 1e-12); assertEquals(-0.05, r.rows.get(1).net, 1e-12);
        s.polyOtherFeePct = 1.0;
        assertEquals(1 - 0.9 * 1.01, PolyCalc.sets(Arrays.asList(cheap), s).rows.get(0).net, 1e-12);
        Event fee = ev("Fee", true, leg("A", 0.5, true), leg("B", 0.45, false));
        assertEquals(1 - (0.5 * (1 + 0.0156) + 0.45 * 1.01), PolyCalc.sets(Arrays.asList(fee), s).rows.get(0).net, 1e-12);
    }
    static Leg leg(String n, double ask, boolean fee) { return new Leg(n, ask, ask - 0.02, fee); }
    static Event ev(String title, boolean neg, Leg... legs) { return new Event(title, title.toLowerCase(), neg, Arrays.asList(legs)); }
}
