package com.arbscout.app;

import static org.junit.Assert.*;

import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import java.io.IOException;
import java.util.*;
import org.junit.Test;

public class PolyFeedTest {
    static final long T = 1_800_000_000_000L;   // divisible by 900 s, so the 5m and 15m windows both start here

    static final class Fake implements PolyFeed.Source {
        final Map<String, String> markets = new HashMap<>(), closedMarkets = new HashMap<>(), books = new HashMap<>();
        String candles = "[]", events = "[]"; boolean failCandles, failEvents, samePageEverywhere; int eventCalls, marketCalls, failEventsAtOffset = -1;
        @Override public String events(int offset, int limit) throws Exception {
            eventCalls++;
            if (failEvents || offset == failEventsAtOffset) throw new IOException("HTTP 403 (blocked in your region or by the exchange)");
            return offset == 0 || samePageEverywhere ? events : "[]";
        }
        final Map<String, Integer> callsBySlug = new HashMap<>();
        @Override public String market(String slug) throws Exception { marketCalls++; callsBySlug.merge(slug, 1, Integer::sum); return markets.getOrDefault(slug, "[]"); }
        int closedCalls;
        @Override public String closedMarket(String slug) throws Exception { closedCalls++; return closedMarkets.containsKey(slug) ? closedMarkets.get(slug) : markets.getOrDefault(slug, "[]"); }
        @Override public String book(String token) throws Exception { String b = books.get(token); if (b == null) throw new IOException("HTTP 404"); return b; }
        @Override public String candles() throws Exception { if (failCandles) throw new IOException("boom"); return candles; }
    }
    static String slug(int minutes, long startMs) { return "btc-updown-" + minutes + "m-" + startMs / 1000; }
    static String market(String slug, boolean closed, String prices) {
        return "[{\"slug\":\"" + slug + "\",\"question\":\"Bitcoin Up or Down\",\"outcomes\":\"[\\\"Up\\\",\\\"Down\\\"]\",\"clobTokenIds\":\"[\\\"" + slug + "-U\\\",\\\"" + slug + "-D\\\"]\","
                + "\"outcomePrices\":\"" + prices + "\",\"closed\":" + closed + "}]";
    }
    static String book(double ask, double size) { return "{\"bids\":[{\"price\":\"" + (ask - 0.02) + "\",\"size\":\"100\"}],\"asks\":[{\"price\":\"" + ask + "\",\"size\":\"" + size + "\"}]}"; }
    /** 62 one-minute candles ending at the minute containing nowMs; flat around 100000 then a last close of lastClose. */
    static String candles(long nowMs, double lastClose) {
        long minute = nowMs / 60000 * 60000; StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < 62; i++) {
            double close = i == 61 ? lastClose : 100000 + (i % 2) * 5, open = i == 0 ? 100000 : 100000 + ((i - 1) % 2) * 5;
            if (i > 0) b.append(',');
            b.append('[').append(minute - (61 - i) * 60000L).append(",\"").append(open).append("\",\"0\",\"0\",\"").append(close).append("\",\"1\"]");
        }
        return b.append(']').toString();
    }
    /** 62 candles ending at the minute containing nowMs; the candle opening at startMs opens at startOpen and the last minute of the window closes at endClose. */
    static String candlesFor(long nowMs, double startOpen, double endClose, long startMs, long endMs) {
        long minute = nowMs / 60000 * 60000; StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < 62; i++) {
            long open = minute - (61 - i) * 60000L; double o = open == startMs ? startOpen : 100000, c = open == endMs - 60000L ? endClose : 100000;
            if (i > 0) b.append(',');
            b.append('[').append(open).append(",\"").append(o).append("\",\"0\",\"0\",\"").append(c).append("\",\"1\"]");
        }
        return b.append(']').toString();
    }
    /** Both windows listed, Up cheap relative to a model that sees BTC well above the window's start. */
    static Fake bullish(long now, double upAsk, double upSize) {
        Fake f = new Fake(); f.candles = candles(now, 100300);
        for (int m : new int[]{5, 15}) {
            String s = slug(m, now / (m * 60000L) * (m * 60000L));
            f.markets.put(s, market(s, false, "[\\\"0.5\\\",\\\"0.5\\\"]"));
            f.books.put(s + "-U", book(upAsk, upSize)); f.books.put(s + "-D", book(0.45, 500));
        }
        return f;
    }
    static PolyFeed feed(Fake f, long[] clock, List<String> saves, String saved) { return new PolyFeed(f, () -> clock[0], saved, saves::add); }

    @Test public void scannerWorksButPaperOffNeverTrades() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500);
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), false);
        assertEquals(2, s.windows.size()); assertEquals("BTC 5m", s.windows.get(0).label);
        assertEquals(slug(5, T), s.windows.get(0).slug); assertEquals(slug(15, T), s.windows.get(1).slug);
        assertNotNull(s.windows.get(0).edge); assertEquals("UP", s.windows.get(0).edge.side); assertTrue(s.windows.get(0).edge.edge > 0.3);
        assertEquals(0, s.ledger.stats().open); assertNull(s.windows.get(0).position);
    }
    @Test public void paperEntersOncePerWindowAndSaves() {
        long[] now = {T + 120_000}; List<String> saves = new ArrayList<>(); PolyFeed pf = feed(bullish(now[0], 0.60, 500), now, saves, "");
        PolyFeed.Scan a = pf.refresh(new Settings(), true);
        assertEquals(2, a.ledger.stats().open); Ledger.Position p = a.windows.get(0).position;
        assertEquals("UP", p.side); assertEquals(0.60, p.price, 1e-12); assertEquals(10, p.stake, 1e-12);
        now[0] += 5_000; assertEquals(2, pf.refresh(new Settings(), true).ledger.stats().open);   // no second entry in the same window
        assertEquals(1, saves.size()); assertTrue(saves.get(0).startsWith("LEDGER1") && saves.get(0).contains("UP"));
    }
    @Test public void atTheStartOfAWindowTheModelKnowsNothingSoItDoesNotTradeUnlessAskedTo() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.40, 500);              // Up asked at 40 cents
        f.candles = candles(now[0], 100000);                                          // price still at the window's start: the model says 50%
        for (int m : new int[]{5, 15}) { String s = slug(m, T); f.books.put(s + "-D", book(0.65, 500)); }
        PolyFeed.Scan guarded = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), true);
        assertEquals(0.5, guarded.windows.get(0).fair.pUp, 0.02);
        assertNull(guarded.windows.get(0).edge); assertEquals(0, guarded.ledger.stats().open);
        assertTrue(guarded.windows.get(0).note.contains("needs 55%"));
        Settings old = new Settings(); old.paperMinModelPct = 0;                      // the previous behaviour: a 10-point "edge" over the market's 40 cents
        PolyFeed.Scan before = feed(f, now, new ArrayList<>(), "").refresh(old, true);
        assertEquals(2, before.ledger.stats().open); assertEquals("UP", before.windows.get(0).position.side);
    }
    @Test public void paperEntryRecordsWhatTheModelAndMarketLookedLike() {
        long[] now = {T + 120_000}; PolyFeed.Scan s = feed(bullish(now[0], 0.60, 500), now, new ArrayList<>(), "").refresh(new Settings(), true);
        String c = s.windows.get(0).position.context;
        for (String part : new String[]{"start=", "now=", "sigmaPctPerMin=", "secondsLeft=180", "pUp=0.980", "askUp=0.6000", "askDown=0.4500", "edgePts=", "feePct="}) assertTrue(part + " in " + c, c.contains(part));
        assertFalse(c.contains("|")); assertFalse(c.contains("\n"));
    }
    @Test public void eventsListIsDownloadedLessOftenWhenAskedTo() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.setEventsEveryMs(600_000);
        pf.refresh(new Settings(), false); assertEquals(3, f.eventCalls);
        now[0] += 120_000; pf.refresh(new Settings(), false); assertEquals(3, f.eventCalls);      // two minutes later: not yet
        now[0] += 500_000; pf.refresh(new Settings(), false); assertEquals(6, f.eventCalls);      // past ten minutes
    }
    @Test public void entryRulesExplainWhyTheyDoNotTrade() {
        long[] now = {T + 120_000};
        PolyFeed.Scan thin = feed(bullish(now[0], 0.60, 5), now, new ArrayList<>(), "").refresh(new Settings(), true);       // 5 shares can't fill a 10 USDT stake
        assertEquals(0, thin.ledger.stats().open); assertTrue(thin.windows.get(0).note.contains("thin"));
        PolyFeed.Scan flat = feed(bullish(now[0], 0.97, 500), now, new ArrayList<>(), "").refresh(new Settings(), true);      // market already agrees with the model
        assertEquals(0, flat.ledger.stats().open); assertTrue(flat.windows.get(0).note.contains("favour"));   // only the 45-cent Down side is in range and the model gives it 2%
        Settings strict = new Settings(); strict.paperMinEdgePts = 45;
        assertEquals(0, feed(bullish(now[0], 0.60, 500), now, new ArrayList<>(), "").refresh(strict, true).ledger.stats().open);
        long[] late = {T + 290_000};
        PolyFeed.Scan end = feed(bullish(late[0], 0.60, 500), late, new ArrayList<>(), "").refresh(new Settings(), true);
        assertTrue(end.windows.get(0).note.contains("too close")); assertNotNull(end.windows.get(1).position);   // 15m still has time
    }
    @Test public void settlesFromPolymarketsRealResultAndOnlyWhenResolved() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T);
        now[0] = T + 300_000 + 25_000;                                           // 5m window over, still unresolved
        f.markets.put(s5, market(s5, false, "[\\\"0.9\\\",\\\"0.1\\\"]"));
        PolyFeed.Scan waiting = pf.refresh(new Settings(), true);
        assertEquals(2, waiting.ledger.stats().open);
        now[0] += 65_000;                                                         // a minute later, resolved: Up won
        f.markets.put(s5, market(s5, true, "[\\\"1\\\",\\\"0\\\"]"));
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(1, st.wins); assertEquals(1, st.open); assertTrue(st.pnl > 6);
        int calls = f.marketCalls; now[0] += 5_000; pf.refresh(new Settings(), true);
        assertTrue(f.marketCalls - calls <= 2);                                   // a settled window is not polled again
    }
    @Test public void officialResultCanComeFromTheFinishedMarketLookup() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T); f.markets.put(s5, "[]"); f.closedMarkets.put(s5, market(s5, true, "[\\\"1\\\",\\\"0\\\"]"));   // the plain lookup hides it
        now[0] = T + 330_000;
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(1, st.wins); assertEquals(0, st.estimated);
    }
    @Test public void resolvedStatusSettlesEvenWhileTheMarketIsNotMarkedClosed() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T); f.markets.put(s5, market(s5, false, "[\\\"0\\\",\\\"1\\\"]").replace("\"closed\":false", "\"closed\":false,\"umaResolutionStatus\":\"resolved\""));
        now[0] = T + 330_000;
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(0, st.wins);
    }
    @Test public void silentPolymarketIsExplainedThenBackedByBinanceAfterTenMinutes() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);                                        // two UP positions: 5m and 15m
        String s5 = slug(5, T), s15 = slug(15, T);
        now[0] = T + 300_000 + 9 * 60_000L; f.candles = candlesFor(now[0], 100000, 100005, T, T + 300_000);
        PolyFeed.Scan nine = pf.refresh(new Settings(), true);
        assertEquals(0, nine.ledger.stats().settled);                            // 9 minutes: still waiting
        assertTrue(nine.settleNotes.get(s5).contains("has not published a result")); assertTrue(nine.settleNotes.get(s5).contains("closed=false"));
        now[0] = T + 300_000 + 11 * 60_000L; f.candles = candlesFor(now[0], 100000, 100005, T, T + 300_000);   // end >= start: Up won
        Ledger.Stats up = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, up.settled); assertEquals(1, up.wins); assertEquals(1, up.estimated); assertEquals(1, up.open);   // the 15m window has only just ended
        assertTrue(pf.refresh(new Settings(), true).ledger.find(s5).estimated); assertNull(pf.refresh(new Settings(), true).settleNotes.get(s5));
    }
    @Test public void binanceEstimateCanAlsoBeALoss() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        now[0] = T + 300_000 + 11 * 60_000L; f.candles = candlesFor(now[0], 100000, 99990, T, T + 300_000);   // ended below the start: Down won, our UP loses
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(0, st.wins); assertEquals(-10, st.pnl, 1e-9); assertEquals(1, st.estimated);
    }
    @Test public void settlementIsCheckedOnlyOnceAMinuteAndTheFinishedLookupOnlyWhenNeeded() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T); int before = f.callsBySlug.getOrDefault(s5, 0);
        now[0] = T + 330_000; pf.refresh(new Settings(), true);                    // 30 s after the 5m window ended: first look
        assertEquals(before + 1, (int) f.callsBySlug.get(s5));
        now[0] += 30_000; pf.refresh(new Settings(), true);                        // 30 s later: too soon
        assertEquals(before + 1, (int) f.callsBySlug.get(s5));
        now[0] += 35_000; pf.refresh(new Settings(), true);                        // 65 s after the first look: allowed again
        assertEquals(before + 2, (int) f.callsBySlug.get(s5));
        assertEquals(0, f.closedCalls);                                            // the plain lookup found the market, so the finished-market lookup was never needed
    }
    @Test public void losingTradeCostsTheWholeStake() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T); f.markets.put(s5, market(s5, true, "[\\\"0\\\",\\\"1\\\"]")); now[0] = T + 330_000;
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(0, st.wins); assertEquals(-10, st.pnl, 1e-9);
    }
    @Test public void ledgerSurvivesARestartWithoutReEntering() {
        long[] now = {T + 120_000}; List<String> saves = new ArrayList<>(); Fake f = bullish(now[0], 0.60, 500);
        feed(f, now, saves, "").refresh(new Settings(), true);
        PolyFeed again = feed(f, now, new ArrayList<>(), saves.get(saves.size() - 1));
        assertEquals(2, again.refresh(new Settings(), true).ledger.stats().open);
        again.resetLedger(); assertEquals(0, again.refresh(new Settings(), false).ledger.stats().open);
        assertEquals(0, feed(f, now, new ArrayList<>(), "garbage").refresh(new Settings(), false).ledger.stats().open);   // damaged save starts empty
    }
    @Test public void failuresAreReportedNotFatal() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); f.failCandles = true; f.failEvents = true;
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), true);
        String all = String.join("\n", s.status);
        assertTrue(all.contains("✗ BINANCE candles") && all.contains("✗ POLYMARKET events · HTTP 403"));
        assertEquals(0, s.ledger.stats().open); assertEquals("no BTC price data", s.windows.get(0).note);
        Fake empty = new Fake(); empty.candles = candles(now[0], 100000);
        PolyFeed.Scan none = feed(empty, now, new ArrayList<>(), "").refresh(new Settings(), true);
        assertTrue(none.windows.get(0).note.contains("waiting for Polymarket"));
    }
    @Test public void oneFailedEventsPageDoesNotHideTheOthers() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); f.failEventsAtOffset = 20;
        f.events = "[{\"title\":\"Cheap\",\"slug\":\"cheap\",\"negRisk\":true,\"markets\":[{\"bestAsk\":0.32},{\"bestAsk\":0.32},{\"bestAsk\":0.32}]}]";
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), false);
        assertEquals(1, s.sets.profitable);
        String all = String.join("\n", s.status);
        assertTrue(all.contains("✓ POLYMARKET events") && all.contains("2 of 3 pages loaded"));
    }
    @Test public void sameEventOnTwoPagesIsCountedOnce() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); f.samePageEverywhere = true;
        f.events = "[{\"title\":\"Cheap\",\"slug\":\"cheap\",\"negRisk\":true,\"markets\":[{\"bestAsk\":0.32},{\"bestAsk\":0.32},{\"bestAsk\":0.32}]}]";
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), false);
        assertEquals(1, s.sets.events); assertEquals(1, s.sets.profitable);
    }
    @Test public void longshotsAndNearCertaintiesAreNeverBought() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.06, 500);            // Up at 6 cents: the model says 98%, the market says 6%
        PolyFeed.Scan lot = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), true);
        assertEquals(0, lot.ledger.stats().open);                                   // the 45-cent Down side is in range but the model gives it 2%
        assertNull(lot.windows.get(0).edge); assertTrue(lot.windows.get(0).note.contains("favour"));
        Settings wide = new Settings(); wide.paperMinCents = 5;                      // widening the range allows it again
        assertEquals(2, feed(f, now, new ArrayList<>(), "").refresh(wide, true).ledger.stats().open);
        for (int m : new int[]{5, 15}) { String s = slug(m, T); f.books.put(s + "-U", book(0.97, 500)); f.books.put(s + "-D", book(0.03, 500)); }
        PolyFeed.Scan sure = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), true);
        assertNull(sure.windows.get(0).edge); assertTrue(sure.windows.get(0).note.contains("between 15 and 85 cents")); assertEquals(0, sure.ledger.stats().open);
    }
    static PolyFeed withRivals(Fake f, long[] now) { PolyFeed pf = feed(f, now, new ArrayList<>(), ""); Engine.addStandardRivals(pf, EngineTest.memoryPrefs()); return pf; }
    static int open(PolyFeed.Scan s, String id) { return (id.equals("A") ? s.ledger : s.rivals.get(id)).stats().open; }

    @Test public void rivalAccountsTradeTheSameWindowsUnderTheirOwnRules() {
        long[] now = {T + 120_000};
        PolyFeed.Scan strong = withRivals(bullish(now[0], 0.60, 500), now).refresh(new Settings(), true);       // the model says 98% Up and Up is asked at 60 cents
        assertEquals(2, open(strong, "A")); assertEquals(2, open(strong, "B")); assertEquals(2, open(strong, "C"));
        Fake f = bullish(now[0], 0.40, 500); f.candles = candles(now[0], 100000);                                // price still at the start: the model says 50%; Up asked at 40 cents
        for (int m : new int[]{5, 15}) f.books.put(slug(m, T) + "-D", book(0.65, 500));
        PolyFeed.Scan flat = withRivals(f, now).refresh(new Settings(), true);
        assertEquals(0, open(flat, "A")); assertEquals(2, open(flat, "B")); assertEquals(0, open(flat, "C"));    // only the rule without a model filter takes the cheap coin flip
        assertEquals("UP", flat.rivals.get("B").all().get(0).side); assertEquals(0.40, flat.rivals.get("B").all().get(0).price, 1e-12);
        assertEquals("no model filter (the rule before 1.6)", flat.rivalLabels.get("B"));
    }
    @Test public void rivalAccountsOnlyTradeWhenPaperTradingIsOn() {
        long[] now = {T + 120_000};
        PolyFeed.Scan off = withRivals(bullish(now[0], 0.60, 500), now).refresh(new Settings(), false);
        assertEquals(0, open(off, "A")); assertEquals(0, open(off, "B")); assertEquals(0, open(off, "C"));
    }
    @Test public void oneSettlementLookupPerWindowSettlesEveryAccount() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = withRivals(f, now);
        pf.refresh(new Settings(), true);                                                                          // A, B and C all hold the 5m and 15m windows
        String s5 = slug(5, T); int before = f.callsBySlug.getOrDefault(s5, 0);
        f.markets.put(s5, market(s5, true, "[\\\"1\\\",\\\"0\\\"]")); now[0] = T + 330_000;
        PolyFeed.Scan after = pf.refresh(new Settings(), true);
        assertEquals(before + 1, (int) f.callsBySlug.get(s5));                                                     // one lookup, not three
        for (String id : new String[]{"A", "B", "C"}) {
            Ledger.Stats st = (id.equals("A") ? after.ledger : after.rivals.get(id)).stats();
            assertEquals(id, 1, st.settled); assertEquals(id, 1, st.wins); assertEquals(id, 1, st.open);
        }
    }
    @Test public void rivalAccountsAreSavedRestoredAndResetTogether() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); List<String> savedB = new ArrayList<>();
        PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.addRival("B", "b", s -> { Settings c = s.copy(); c.paperMinModelPct = 0; return c; }, "", savedB::add);
        pf.refresh(new Settings(), true);
        assertEquals(1, savedB.size()); assertTrue(savedB.get(0).startsWith("LEDGER1") && savedB.get(0).contains("btc-updown-5m-"));
        PolyFeed again = feed(f, now, new ArrayList<>(), "");
        again.addRival("B", "b", s -> s, savedB.get(0), t -> { });                                                 // restored after a restart
        assertEquals(2, open(again.refresh(new Settings(), false), "B"));
        again.resetLedger();
        PolyFeed.Scan cleared = again.refresh(new Settings(), false);
        assertEquals(0, open(cleared, "A")); assertEquals(0, open(cleared, "B"));
        PolyFeed damaged = feed(f, now, new ArrayList<>(), ""); damaged.addRival("B", "b", s -> s, "garbage", t -> { });
        assertEquals(0, open(damaged.refresh(new Settings(), false), "B"));                                        // a damaged save starts empty
    }
    @Test public void eventsAreScannedEveryThirtySeconds() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500);
        f.events = "[{\"title\":\"Cheap\",\"negRisk\":true,\"markets\":[{\"groupItemTitle\":\"A\",\"bestAsk\":0.32},{\"groupItemTitle\":\"B\",\"bestAsk\":0.32},{\"groupItemTitle\":\"C\",\"bestAsk\":0.32}]}]";
        PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        PolyFeed.Scan a = pf.refresh(new Settings(), false);
        assertEquals(1, a.sets.profitable); assertEquals(3, f.eventCalls);                    // three small pages per scan
        now[0] += 10_000; pf.refresh(new Settings(), false); assertEquals(3, f.eventCalls);
        now[0] += 25_000; pf.refresh(new Settings(), false); assertEquals(6, f.eventCalls);
    }
}
