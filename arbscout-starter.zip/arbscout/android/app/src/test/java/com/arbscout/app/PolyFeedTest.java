package com.arbscout.app;

import static org.junit.Assert.*;

import com.arbscout.core.Ledger;
import com.arbscout.core.Model.Settings;
import java.io.IOException;
import java.util.*;
import org.junit.Test;

public class PolyFeedTest {
    static final long T = 1_800_000_000_000L;   // divisible by 900 s, so the 5m and 15m windows both start here

    static final class Fake implements PolyFeed.Source {
        final Map<String, String> markets = new HashMap<>(), books = new HashMap<>();
        String candles = "[]", events = "[]"; boolean failCandles, failEvents; int eventCalls, marketCalls;
        @Override public String events() throws Exception { eventCalls++; if (failEvents) throw new IOException("HTTP 403 (blocked in your region or by the exchange)"); return events; }
        @Override public String market(String slug) throws Exception { marketCalls++; return markets.getOrDefault(slug, "[]"); }
        @Override public String book(String token) throws Exception { String b = books.get(token); if (b == null) throw new IOException("HTTP 404"); return b; }
        @Override public String candles() throws Exception { if (failCandles) throw new IOException("boom"); return candles; }
    }
    static String slug(int minutes, long startMs) { return "btc-updown-" + minutes + "m-" + startMs / 1000; }
    static String market(String slug, boolean closed, String prices) {
        return "[{\"slug\":\"" + slug + "\",\"question\":\"Bitcoin Up or Down\",\"outcomes\":\"[\\\"Up\\\",\\\"Down\\\"]\",\"clobTokenIds\":\"[\\\"" + slug + "-U\\\",\\\"" + slug + "-D\\\"]\","
                + "\"outcomePrices\":\"" + prices + "\",\"closed\":" + closed + "}]";
    }
    static String book(double ask, double size) { return "{\"bids\":[{\"price\":\"" + (ask - 0.02) + "\",\"size\":\"100\"}],\"asks\":[{\"price\":\"" + ask + "\",\"size\":\"" + size + "\"}]}"; }
    /** 62 one-minute candles ending at the minute containing nowMs; flat around 100000 then a last close of lastClose. */
    static String candles(long nowMs, double lastClose) {
        long minute = nowMs / 60000 * 60000; StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < 62; i++) {
            double close = i == 61 ? lastClose : 100000 + (i % 2) * 5, open = i == 0 ? 100000 : 100000 + ((i - 1) % 2) * 5;
            if (i > 0) b.append(',');
            b.append('[').append(minute - (61 - i) * 60000L).append(",\"").append(open).append("\",\"0\",\"0\",\"").append(close).append("\",\"1\"]");
        }
        return b.append(']').toString();
    }
    /** Both windows listed, Up cheap relative to a model that sees BTC well above the window's start. */
    static Fake bullish(long now, double upAsk, double upSize) {
        Fake f = new Fake(); f.candles = candles(now, 100300);
        for (int m : new int[]{5, 15}) {
            String s = slug(m, now / (m * 60000L) * (m * 60000L));
            f.markets.put(s, market(s, false, "[\\\"0.5\\\",\\\"0.5\\\"]"));
            f.books.put(s + "-U", book(upAsk, upSize)); f.books.put(s + "-D", book(0.45, 500));
        }
        return f;
    }
    static PolyFeed feed(Fake f, long[] clock, List<String> saves, String saved) { return new PolyFeed(f, () -> clock[0], saved, saves::add); }

    @Test public void scannerWorksButPaperOffNeverTrades() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500);
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), false);
        assertEquals(2, s.windows.size()); assertEquals("BTC 5m", s.windows.get(0).label);
        assertEquals(slug(5, T), s.windows.get(0).slug); assertEquals(slug(15, T), s.windows.get(1).slug);
        assertNotNull(s.windows.get(0).edge); assertEquals("UP", s.windows.get(0).edge.side); assertTrue(s.windows.get(0).edge.edge > 0.3);
        assertEquals(0, s.ledger.stats().open); assertNull(s.windows.get(0).position);
    }
    @Test public void paperEntersOncePerWindowAndSaves() {
        long[] now = {T + 120_000}; List<String> saves = new ArrayList<>(); PolyFeed pf = feed(bullish(now[0], 0.60, 500), now, saves, "");
        PolyFeed.Scan a = pf.refresh(new Settings(), true);
        assertEquals(2, a.ledger.stats().open); Ledger.Position p = a.windows.get(0).position;
        assertEquals("UP", p.side); assertEquals(0.60, p.price, 1e-12); assertEquals(10, p.stake, 1e-12);
        now[0] += 5_000; assertEquals(2, pf.refresh(new Settings(), true).ledger.stats().open);   // no second entry in the same window
        assertEquals(1, saves.size()); assertTrue(saves.get(0).startsWith("LEDGER1") && saves.get(0).contains("UP"));
    }
    @Test public void entryRulesExplainWhyTheyDoNotTrade() {
        long[] now = {T + 120_000};
        PolyFeed.Scan thin = feed(bullish(now[0], 0.60, 5), now, new ArrayList<>(), "").refresh(new Settings(), true);       // 5 shares can't fill a 10 USDT stake
        assertEquals(0, thin.ledger.stats().open); assertTrue(thin.windows.get(0).note.contains("thin"));
        PolyFeed.Scan flat = feed(bullish(now[0], 0.97, 500), now, new ArrayList<>(), "").refresh(new Settings(), true);      // market already agrees with the model
        assertEquals(0, flat.ledger.stats().open); assertTrue(flat.windows.get(0).note.contains("edge"));
        Settings strict = new Settings(); strict.paperMinEdgePts = 45;
        assertEquals(0, feed(bullish(now[0], 0.60, 500), now, new ArrayList<>(), "").refresh(strict, true).ledger.stats().open);
        long[] late = {T + 290_000};
        PolyFeed.Scan end = feed(bullish(late[0], 0.60, 500), late, new ArrayList<>(), "").refresh(new Settings(), true);
        assertTrue(end.windows.get(0).note.contains("too close")); assertNotNull(end.windows.get(1).position);   // 15m still has time
    }
    @Test public void settlesFromPolymarketsRealResultAndOnlyWhenResolved() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T);
        now[0] = T + 300_000 + 25_000;                                           // 5m window over, still unresolved
        f.markets.put(s5, market(s5, false, "[\\\"0.9\\\",\\\"0.1\\\"]"));
        PolyFeed.Scan waiting = pf.refresh(new Settings(), true);
        assertEquals(2, waiting.ledger.stats().open);
        now[0] += 25_000;                                                         // resolved: Up won
        f.markets.put(s5, market(s5, true, "[\\\"1\\\",\\\"0\\\"]"));
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(1, st.wins); assertEquals(1, st.open); assertTrue(st.pnl > 6);
        int calls = f.marketCalls; now[0] += 5_000; pf.refresh(new Settings(), true);
        assertTrue(f.marketCalls - calls <= 2);                                   // a settled window is not polled again
    }
    @Test public void losingTradeCostsTheWholeStake() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        pf.refresh(new Settings(), true);
        String s5 = slug(5, T); f.markets.put(s5, market(s5, true, "[\\\"0\\\",\\\"1\\\"]")); now[0] = T + 330_000;
        Ledger.Stats st = pf.refresh(new Settings(), true).ledger.stats();
        assertEquals(1, st.settled); assertEquals(0, st.wins); assertEquals(-10, st.pnl, 1e-9);
    }
    @Test public void ledgerSurvivesARestartWithoutReEntering() {
        long[] now = {T + 120_000}; List<String> saves = new ArrayList<>(); Fake f = bullish(now[0], 0.60, 500);
        feed(f, now, saves, "").refresh(new Settings(), true);
        PolyFeed again = feed(f, now, new ArrayList<>(), saves.get(saves.size() - 1));
        assertEquals(2, again.refresh(new Settings(), true).ledger.stats().open);
        again.resetLedger(); assertEquals(0, again.refresh(new Settings(), false).ledger.stats().open);
        assertEquals(0, feed(f, now, new ArrayList<>(), "garbage").refresh(new Settings(), false).ledger.stats().open);   // damaged save starts empty
    }
    @Test public void failuresAreReportedNotFatal() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500); f.failCandles = true; f.failEvents = true;
        PolyFeed.Scan s = feed(f, now, new ArrayList<>(), "").refresh(new Settings(), true);
        String all = String.join("\n", s.status);
        assertTrue(all.contains("✗ BINANCE candles") && all.contains("✗ POLYMARKET events · HTTP 403"));
        assertEquals(0, s.ledger.stats().open); assertEquals("no BTC price data", s.windows.get(0).note);
        Fake empty = new Fake(); empty.candles = candles(now[0], 100000);
        PolyFeed.Scan none = feed(empty, now, new ArrayList<>(), "").refresh(new Settings(), true);
        assertTrue(none.windows.get(0).note.contains("waiting for Polymarket"));
    }
    @Test public void eventsAreScannedEveryThirtySeconds() {
        long[] now = {T + 120_000}; Fake f = bullish(now[0], 0.60, 500);
        f.events = "[{\"title\":\"Cheap\",\"negRisk\":true,\"markets\":[{\"groupItemTitle\":\"A\",\"bestAsk\":0.3},{\"groupItemTitle\":\"B\",\"bestAsk\":0.3},{\"groupItemTitle\":\"C\",\"bestAsk\":0.3}]}]";
        PolyFeed pf = feed(f, now, new ArrayList<>(), "");
        PolyFeed.Scan a = pf.refresh(new Settings(), false);
        assertEquals(1, a.sets.profitable); assertEquals(1, f.eventCalls);
        now[0] += 10_000; pf.refresh(new Settings(), false); assertEquals(1, f.eventCalls);
        now[0] += 25_000; pf.refresh(new Settings(), false); assertEquals(2, f.eventCalls);
    }
}
