# ArbScout

An Android app that scans public exchange data for two kinds of arbitrage and shows what is left **after fees**.
It is read-only: no API keys, no accounts, no orders.

## Build the APK from your phone

1. Create a new, empty GitHub repository (a fresh one avoids clashes with older projects).
2. **Add file → Create new file**, name it `.github/workflows/build-android.yml`, paste the contents of `build-android.yml`, commit.
3. **Add file → Upload files**, upload `arbscout-starter.zip` (do not unzip it) to the repository root, commit.
4. Open the **Actions** tab → **Build ArbScout APK**. When it turns green, open the run and download **ArbScout-Android-APK** under *Artifacts*.
5. Unzip the download and install `app-debug.apk` (allow installs from your browser or files app when asked).

The APK is uploaded before tests and lint run, so a failing check never blocks the download; the run just shows red.

## The three tabs

**Spreads** compares best bid/ask for every USDT coin listed on two or more of Binance, Bybit, OKX and MEXC.
It buys at one exchange's ask, sells at another's bid, and subtracts both fees plus a safety margin. Books thinner than your minimum depth and spreads larger than a believable limit (halted coins, stale quotes, shared tickers) are hidden, and counted so you can see what was removed.
It needs balances already held on both exchanges; transfers are not modeled.

**Carry** ranks funding-rate cash-and-carry: buy the coin on spot and short its perpetual on the same exchange (Binance or Bybit), collecting funding while positive. Costs counted: spot and perp fees both ways, the spot bid/ask spread and a slippage allowance. Shows APR, break-even days and net over your holding period. Funding can fall or turn negative and a short can be liquidated in a sharp rally; net figures assume today's rate continues.

**Settings** holds your own fees and filters. Defaults are typical entry-level taker fees, not your tier.

## Honest expectations

Cross-exchange spreads between liquid coins almost never cover two taker fees, so "0 profitable" is the normal reading and means the app is working. Funding carry is the scan that more often shows positive numbers, because it earns a rate over time rather than a one-off gap, but it carries risks the table cannot show. Prices are snapshots taken seconds apart; this is a research tool, not advice, and nothing here guarantees a profit.

If an exchange blocks your region (HTTP 451/403) the status lines say so and the app carries on with the others; spreads need at least two responding.

## Verification status

Run in the authoring sandbox (JDK 21) against stand-ins for the Android classes: 21 JUnit tests (parsers for each exchange's reply shape, fee and carry arithmetic with hand-computed expectations, filters, source-failure and staleness handling, HTTP error handling against a local server) all pass, and a deliberately injected arithmetic fault was caught.
**Not run:** the real Gradle build, lint, the tests under Gradle, and the app on a phone. Parsers follow each exchange's documented reply format but were not run against live servers (no network in the sandbox); if an exchange changed its format, that source shows an error line instead of crashing the rest.
