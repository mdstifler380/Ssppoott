# ArbScout

An Android app that scans public exchange data for two kinds of arbitrage and shows what is left **after fees**.
It is read-only: no API keys, no accounts, no orders.

## Build the APK from your phone

1. Create a new, empty GitHub repository (a fresh one avoids clashes with older projects).
2. **Add file → Create new file**, name it `.github/workflows/build-android.yml`, paste the contents of `build-android.yml`, commit.
3. **Add file → Upload files**, upload `arbscout-starter.zip` (do not unzip it) to the repository root, commit.
4. Open the **Actions** tab → **Build ArbScout APK**. When it turns green, open the run and download **ArbScout-Android-APK** under *Artifacts*.
5. Unzip the download and install `app-debug.apk` (allow installs from your browser or files app when asked).

The APK is uploaded before tests and lint run, so a failing check never blocks the download; the run just shows red.

## The four tabs

**Spreads** compares best bid/ask for every USDT coin listed on two or more of Binance, Bybit, OKX and MEXC.
It buys at one exchange's ask, sells at another's bid, and subtracts both fees plus a safety margin. Books thinner than your minimum depth and spreads larger than a believable limit (halted coins, stale quotes, shared tickers) are hidden, and counted so you can see what was removed.
It needs balances already held on both exchanges; transfers are not modeled.

**Carry** ranks funding-rate cash-and-carry: buy the coin on spot and short its perpetual on the same exchange (Binance or Bybit), collecting funding while positive. Costs counted: spot and perp fees both ways, the spot bid/ask spread, a slippage allowance, and a negative basis (perpetual priced below spot gives that gap back when the two converge; a premium is not counted as a gain). Shows APR, break-even days and net over your holding period. Funding can fall or turn negative and a short can be liquidated in a sharp rally; net figures assume today's rate continues.

**Poly** is a read-only Polymarket scanner with a fake-money paper account. It does not connect a wallet and never places a real order.
- *Live BTC windows:* for the current 5- and 15-minute "Bitcoin Up or Down" markets it reads the real order books and compares them with a simple model built from Binance 1-minute candles (probability that the price ends above where the window started, from current volatility and time left). Polymarket settles these on Chainlink's BTC/USD, not Binance, so near the start price the two can disagree; the model is a plain random walk and ignores sudden jumps.
- *Paper account:* switch it on and the app "buys" the better side at the real best ask, fee included, whenever the model's edge is at least your threshold (default 6 points), the ask is between 15 and 85 cents (adjustable: the model is least reliable on longshots and near-certainties, and its probabilities are floored at 2%, so any ask under 2 cents would look like an edge), the book can fill your stake, and at least 20 seconds remain. It settles from Polymarket's real result (and says why, on each open trade, if that result is not available yet; if Polymarket still has not published one after 10 minutes, the trade is settled from Binance prices instead and marked with *). It shows P&L, win rate, and the model's average win chance beside the actual win rate, which is the number that tells you whether the model has any skill. With only a handful of trades the win rate is uncertain by tens of points; resolving a 5-point gap takes several hundred settled trades. It only trades while the app is open on screen.
- *Buy every outcome:* in events where exactly one outcome wins, one share of each costs the sum of the asks and pays $1. The tab lists the cheapest sets after fees. Sizes are not checked. A set that looks cheap is nearly always an event whose outcome list is incomplete (candidates not yet open, outcomes that can be added later, very long lists), so those events are excluded, and any "profit" above 5 cents per dollar is hidden as implausible. Both counts are shown.
- Polymarket added taker fees to its short crypto markets in 2026 specifically to remove simple price-lag profits, and bots already dominate them. Treat a paper account that ends in profit with suspicion until it has hundreds of settled trades, and remember real fills are slower and worse than paper ones. Polymarket is not available in every country; check yours before opening an account.

**Settings** holds your own fees and filters. Defaults are typical entry-level taker fees, not your tier. The Polymarket fee default (1.56% at 50 cents, shrinking toward the edges) is an estimate from public reports of the fee schedule: set the real one.

## Running in the background and exporting data (version 1.4)

On the **Settings** tab, **Run in background** starts a foreground service, the same mechanism a VPN app uses. A notification stays in the panel showing how many sources are working, the best spread and carry candidate, the paper account (open, settled, won, P&L), the time of the last update, how long it has been running and roughly how much data it has read. **Stop** in the notification ends it. While it runs, scanning and paper trading continue with the screen off or the app closed.

- Android asks permission to show notifications the first time. Without it the service still runs but you will not see the panel.
- It holds a wake lock (renewed every scan) so the CPU does not sleep, which costs battery. **Allow unrestricted battery use** opens Android's battery screen; on some phones (Xiaomi, Huawei, Samsung, OnePlus and others) you must also allow background activity or auto-start for the app, or the system may still stop it.
- With the screen closed, the big spot and perpetual price downloads slow to every 2 minutes and the huge Polymarket events list to every 10 minutes, to save data and battery. The BTC windows and paper trading keep their normal refresh. With the screen open everything refreshes at your chosen interval.
- It does not start by itself after a phone restart; open the app once.

**Export data (ZIP of CSV files)** builds a ZIP, saves it to your Downloads folder and opens the share sheet. It contains `status.csv` (run state, data used, source status lines, counters), `settings.csv`, `spreads.csv`, `carry.csv`, `poly_windows.csv`, `paper_trades.csv` (every paper trade with its entry details, result, P&L and whether Polymarket or a Binance estimate settled it), `buy_every_outcome.csv`, `snapshots.csv` (one row per minute for roughly the last 50 hours) and `events.csv` (source outages and recoveries, paper trades opened and settled, service start and stop, settings changes), plus a `README.txt` describing them.

## Honest expectations

Cross-exchange spreads between liquid coins almost never cover two taker fees, so "0 profitable" is the normal reading and means the app is working. Funding carry is the scan that more often shows positive numbers, because it earns a rate over time rather than a one-off gap, but it carries risks the table cannot show. Prices are snapshots taken seconds apart; this is a research tool, not advice, and nothing here guarantees a profit.

If an exchange blocks your region (HTTP 451/403) the status lines say so and the app carries on with the others; spreads need at least two responding.

## Verification status

Run in the authoring sandbox (JDK 21) against stand-ins for the Android classes: 77 JUnit tests (parsers for each exchange's reply shape, fee, carry and Polymarket arithmetic with hand-computed expectations, the paper ledger, entry and settlement rules, filters, source-failure and staleness handling, HTTP error handling against a local server) all pass, and deliberately injected faults in the arithmetic, the settlement mapping, the Binance fallback, the edge threshold, the fee handling, the incomplete-event exclusion, the basis cost, the entry price range, the events paging, CSV quoting, the rolling history, the restart-replay guard and outage detection were each caught. A smoke run of the real engine against a fake Android context confirmed that it scans, notifies listeners, logs events, builds the export and notification text, restarts on a settings change and stops when released.
**Confirmed on GitHub:** the real Gradle build produces the APK and lint passes. **Not yet confirmed:** the unit tests under Gradle (a first attempt failed only because one test used a desktop-only HTTP server class; now replaced), the background service, status notification, permission prompts and export-and-share on a real phone (these depend on the Android version and phone maker), and the Poly tab, which was written from Polymarket's public documentation and third-party descriptions of its API without being run against the live servers (no network in the sandbox). If a Polymarket request fails or changes format, the Poly tab shows an error line and the other tabs keep working. Parsers follow each exchange's documented reply format but were not run against live servers (no network in the sandbox); if an exchange changed its format, that source shows an error line instead of crashing the rest.
